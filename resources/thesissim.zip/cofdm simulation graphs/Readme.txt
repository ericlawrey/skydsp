Each directory contains the set of scripts used for each of the 
simulation plots for OFDM. The excel files contain the original
data used and are in Excel 97 format. Note: some of these are old 
so will not have the most recent graphs. 

Eric Lawrey 19th October 1997