simcdma.m allows a set of CDMA parameters to be simulated, such
as BER verse number of users, etc. All the graphs used in the
thesis were generated using this script. The output from this script
is a Result.txt file which is a comma delimited spread sheet compatible
file.

simcdma.m also has all the settings for the CDMA link parameters.

Eric Lawrey 19th October 1997