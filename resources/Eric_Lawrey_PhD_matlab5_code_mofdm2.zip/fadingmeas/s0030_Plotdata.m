%This script plots the measured space-frequency propagation measurements
%made in the ECE building. 
clear all
scriptnum = 's0030_';	%Text added to start of all plots to track which
%								 script generates which plots.
d = 'cal_data';	%Directory of the data
figsdir = 'figs';
if exist([pwd filesep figsdir],'dir') == 0
   mkdir(figsdir);
end

%This script sets up a list of all the measured data sets. Each data set
%is a wideband radio channel characterisation measurement. 
%s - 			filenames of the data sets
%descript - description of the data set
%Xloc, Yloc, Zloc - location of the transmitter im metres, origin in is
%				Room 209. See TXRXlayout.gif
%Xrx,Yrx,Zrx - location of the start of the receiver.
PlotList = [1:8 10 11];	%List of files to plot (with of the files listed in s)
%PlotList = 7;
%rm206ceiling_c is 
Plot3dsurface = 0;			%Flags to indicate which plots to plot 
Plot2dsurface = 0;
PlotContour = 0;
PlotFreqFading = 0;
PlotTimeFading = 0;
PlotFading = 0;			%PLot cumulative fading distribution of each data set independently
PlotCombFade = 0;
PlotDivFading = 1;		%Plot the fading distribution with diversity, must be set to 1 if DivPlotFlag = 1
DivPlotFlag = 1;			%Plot diversity comparison
PlotPLDist = 0;			%Plot the average pathloss verses distance for all the 
%                        data sets
TimeFadingList = [6];	%List of files from s to make a time fading plot of
FreqIndex = [220];		%Frequency (index i.e. 1 - 512) to perform the time fading

FreqFadingList = [7];	%List of files from s to make a frequency fading plot of
TimeIndex = [100];		%Time (index i.e. 1 - 240) to perform the frequency fading
SaveFlag = 0;				%0 - dont save plotted figures, 1 - save plotted figures
s = cell(1);						%Filenames of the data to plot
s{1} = 'rm120ceiling_c';
s{2} = 'rm209ceiling_c';
s{3} = 'rm122chair_c';
s{4} = 'rm210ceiling_abovetrack2_c';
s{5} = 'rm210chair_c';
s{6} = 'rm210ceiling_c';
s{7} = 'rm207ceiling_c';
s{8} = 'rm206chair_c';
s{9} = 'rm206ceiling_c';
s{10} = 'rm205chair_c';
s{11} = 'rm205ceiling_c';
%Desciptions of each of the plots
descript{1} = 'Ceiling of Room 120 to Room 210, Position 7';
descript{2} = 'Ceiling of Room 209 to Room 210, Position 6';
descript{3} = 'Bench height (0.9m) of Room 122 to Room 210, Position 8';
descript{4} = 'Ceiling of Room 210 above centre of receiver track, Position 5';
descript{5} = 'Bench height (0.9m) of Room 210 to Room 210, Position 4';
descript{6} = 'Ceiling of Room 210 to Room 210, Position 4';
descript{7} = 'Ceiling of Room 207 to Room 210, Position 3';
descript{8} = 'Bench height (0.9m) of Room 206 to Room 210, Position 2';
descript{9} = 'Ceiling of Room 206 to Room 210, Position 2';
descript{10} = 'Bench height (0.9m) of Room 205 to Room 210, Position 1';
descript{11} = 'Ceiling of Room 205 to Room 210, Position 1';
Xloc = [6.3, 5.3, 15.9, 16.6, 24.6, 24.6, 23.4, 31.5, 31.5, 35.9, 35.9];
Yloc = [7.95, 1.2, 6.3, 7.9, 7.2, 7.2, 14.2, 14.7, 14.7, 14.7, 14.7];
Zloc = [-0.4, 2.6, -2.1, 2.6, 0.9, 2.6, 2.6, 0.9, 2.6, 0.9, 2.6];
%Receiver location
Xrx = 16.6;
Yrx = 8.9-2.4; 		%This is the start location
Zrx = 1.3;
LOS = [0 0 0 1 1 1 0 0 0 0 0];			%Flag to indicate if data is LOS
Position = {'7 C,floor 1', '6 C', '8 B,floor 1', '5 C', '4 B', '4 C', '3 C', '2 B', '2 C', '1 B', '1 C'};
Yrx = Yrx+1.2;			%Set the Rx location to be the mid point of the receiver movement
%since the receiver was moved 2.4m adding 1.2m makes it midway
if PlotCombFade
   figure(7)
   clf
end

hd = [];
SepStepList = [5];
DivPower = [];
DivPowerB = [];
DataTot = [];
MeanPow = zeros(1,length(PlotList));
txrx = zeros(1,length(PlotList));
for l = 1:length(PlotList) %length(s)
   k = PlotList(l);
   disp(['Plotting ' int2str(k) ' of ' int2str(length(s))]);
   eval(['load 'd '\' s{k}]);
   %calculate the transmission distances   
   txrxdist = sqrt((Xrx-Xloc(k))^2+(Zrx-Zloc(k))^2+(Zrx-Zloc(k))^2);
   txrx(l) = txrxdist;
   
   MeanPow(l) = 10*log10(mean(10.^(Data(:)/10)));
   %Smooth the data using a 5 tap 2D filter
   Ftaps = 1;
   Ftaps2 = ceil(Ftaps/2);
   lf = Ftaps2;
   hf = 511-Ftaps2+1;
   %figure(1);
   sz=get(0,'ScreenSize');
   set(gcf,'position',[sz(1) sz(2)+28 sz(3) sz(4)-96]);
   B = blackmn2(Ftaps,Ftaps);
   B = B/sum(sum(B));
   DataLin = 10.^(Data/10);
   Dataf = filter2(B,DataLin);
   
   ind = Ftaps:NumFiles-Ftaps+1;
   Dataf2 = 10*log10(Dataf(lf+1:hf-1,ind));
   Xf2 = X(ind);
   Ff2 = F(lf+1:hf-1);	%Crop the data to remove transient effects from
   %							 the smoothing filter
   
   %====================================
   % 3D Surface plot (mountains)
   %====================================
   if Plot3dsurface
      figure(1)   
      surf(Xf2,Ff2,Dataf2);
      shading interp;
      lighting phong;
      camlight left
      colormap(hot.^0.4);
      xlabel('Distance moved (cm)');
      ylabel('Frequency (MHz)');
      zlabel('Rx Power (dBm)');
      title(descript{k});
      axis tight
      setplotstyle	
      if SaveFlag
         savefig([figsdir '\' scriptnum s{k} '_3D'],'jpg');
      end
      
      
   end
   %====================================
   % 2D Surface plot
   %====================================
   if Plot2dsurface
      figure(2)
      clf
      sz=get(0,'ScreenSize');
      set(gcf,'position',[sz(1) sz(2)+28 sz(3) sz(4)-96]);
      pcolor(Xf2,Ff2,-Dataf2);
      shading interp;
      %max(Dataf2
      c = caxis;
      caxis([c(1) c(1)+30])
      c = coppernew(0.9).^0.8;
      %colormap(c(end:-1:1,:));
      colormap(clip(c(end:-1:1,:)*1.3,0,1))
      %colormap(coppernew(0.9));
      sn = sprintf('%.1f',txrxdist);
      xlabel(['Distance moved (cm), mean tx-rx distance : ' sn 'm']);
      ylabel('Frequency (MHz)');
      title(descript{k});
      cb = colorbar('vert');
      ax = gca;
      axes(cb);
      hold on
      hm = plot([-1 1],-[MeanPow(l) MeanPow(l)],'k:');
      hold off
      set(cb,'ydir','reverse');
      cb_ylabel=get(cb,'ylabel');
      set(cb_ylabel,'string',['Path Loss (dB), Mean: ' num2str(-MeanPow(l),3) ' dB']);
      axes(ax);
      setplotstyle(1.5,0.8)
      %Add the mean power as a contour (The 1000 is added so that contour interprets
      %the vector correctly
      hold on
      [c,h] = contour(Xf2,Ff2,-Dataf2,[-MeanPow(l) 1000],'k:');
      hold off
      if SaveFlag
         savefig([figsdir '\' scriptnum s{k} '_surf'],'jpg');
      end
      
   end
   %====================================
   % Contour Plots
   %====================================
   DataLin = 10.^(Dataf2/10);
   DataNorm = 10*log10(DataLin/mean(mean(DataLin))+eps);   
   if PlotContour
      figure(3);
      v = -20:5:5;
      
      [c,h]=contour(Xf2,Ff2,DataNorm,v);
      set(h,'linewidth',2)
      clabel(c,h,'fontsize',16)
      xlabel('Distance (cm)');
      ylabel('Frequency (MHz)');
      title(descript{k});
      setplotstyle
      if SaveFlag
         savefig([figsdir '\' scriptnum s{k} '_contour'],'jpg');
      end
      
   end
   %====================================
   % Frequency Fading Plots
   %====================================
   if PlotFreqFading
      ind = find(FreqFadingList==k);
      if ~isempty(ind)
         figure(4);
         FreqData = DataNorm(:,FreqIndex(ind));
         plot(Ff2,FreqData)
         xlabel('Frequency (MHz)');
         ylabel('Normalised Power (dB)')
         axis tight
         setplotstyle
         if SaveFlag
            savefig([figsdir '\' scriptnum s{k} '_freqfade'],'jpg');
         end
         
      end
   end
   
   %====================================
   % Time Fading Plots
   %====================================
   if PlotTimeFading
      ind = find(TimeFadingList==k);
      if ~isempty(ind)
         figure(5);
         TimeData = DataNorm(TimeIndex(ind),:);
         Freq = Ff2(TimeIndex);
         plot(Xf2,TimeData)
         xlabel('Distance (cm)')
         ylabel('Normalised Power (dB)')
         s2 = sprintf('%3.0f',Freq)
         title([descript{k} ', (' s2 'MHz)']);
         axis tight
         setplotstyle
         if SaveFlag
            savefig([figsdir '\' scriptnum s{k} '_timefade'],'jpg');
         end
      end
   end
   
   %====================================
   % Fading Distribution Plots
   %====================================
   if PlotFading
      %DataMean = 10*log10(mean(mean((10.^(Data/10)))));
      %DataNorm = Data-DataMean;
      r = 10*log10(abs(randn(1,500000)));
      x2 = linspace(0,1,length(r));
      figure(6)
      s1 = sort(r);
      medianPow = s1(end/2);
      hr = semilogy(s1-medianPow,x2);	%plot Rayleigh fading
      hold on
      x3 = linspace(0,1,length(Data(:)));
      s1 = sort(Data(:));
      
      medianPow = s1(end/2);
      hd = semilogy(s1-medianPow,x3,'r');
      hold off
      xlabel('Received Signal Strength (dB about median)');
      ylabel('% Prob. Rx. Signal Strength < Abscissa');
      legend([hr, hd],'Rayleigh Fading','Measured',2);
      title([descript{k} ' Mean Pow: ' num2str(MeanPow(l),3) ' dB']);
      axis([-30 10 0.001 1]);
      setplotstyle
      grid on
      set(hd,'linewidth',4);
      legend
      set(gca,'yticklabel',[1e-3 1e-2 1e-1 1]*100)
      
      if SaveFlag
         savefig([figsdir '\' scriptnum s{k} '_cumdist']);
      end
   end
   
   %====================================
   % Diversity Fading Distribution Plots
   %====================================
   if PlotDivFading
      SepStep = SepStepList(1);
      dist1 = 1:3:(size(Data,2)-SepStep);
      dist2 = (SepStep+1):3:size(Data,2);
      %dist1 = 1:SepStep:(size(Data,2)-SepStep);
      %dist2 = (SepStep+1):SepStep:size(Data,2);
      s1 = sort(Data(:));
      medianPow = s1(end/2);
      %medianLin = 10.^(medianPow/10);
      DataLin = 10.^((Data-medianPow)/10);
      DataTot = [DataTot 10*log10(DataLin)];
      DivPower = [DivPower 10*log10(DataLin(:,dist1)+DataLin(:,dist2))];
      
      Diversity = 4;
      CutOut = Diversity*SepStep;
      Index = 1:3:size(Data,2)-CutOut;
      DivOffset = ((0:Diversity-1)*SepStep)';
      %IndexMat = repmat(Index,Diversity,1)+repmat(DivOffset,1,length(Index));
      Acc = zeros(size(DataLin,1),length(Index));
      for k = 1:Diversity
         Acc = Acc+DataLin(:,Index+DivOffset(k));
      end
      DivPowerB = [DivPowerB 10*log10(Acc)];    
   end
   
   
   %====================================
   % Combined Fading Distribution Plots
   %====================================
   if PlotCombFade
      %DataMean = 10*log10(mean(mean((10.^(Data/10)))));
      %DataNorm = Data-DataMean;
      figure(7)
      hold on
      x3 = linspace(0,1,length(Data(:)));
      s1 = sort(Data(:));
      medianPow = s1(end/2);
      hd(l) = semilogy(s1-medianPow,x3,'r');
      
   end
      if SaveFlag == 0
%         pause
      end
	drawnow   
end
if PlotCombFade
   r = 10*log10(abs(randn(1,500000)));
   x2 = linspace(0,1,length(r));
   figure(7)
   s1 = sort(r);
   medianPow = s1(end/2);
   hr = semilogy(s1-medianPow,x2);	%plot Rayleigh fading
   
   hold off
   xlabel('Received Signal Strength (dB about median)');
   ylabel('% Prob. Rx. Signal Strength < Abscissa');
   legend([hr, hd(1)],'Rayleigh Fading','Measured',2);
   axis([-30 10 0.001 1]);
   setplotstyle
   grid on
   set(hr,'linewidth',3);
   set(hd,'linewidth',1);
   legend
   set(gca,'yscale','log');
   set(gca,'box','on')
   set(gca,'yticklabel',[1e-3 1e-2 1e-1 1]*100)
   if SaveFlag
      savefig([figsdir '\' scriptnum s{k} '_cumdistComb']);
   end
end

if DivPlotFlag
figure(8)
clf

%===============================
% Rayleigh fading simulation 
%===============================
Diversity = [ 1, 2, 4];
N = 200e3;
r = zeros(length(Diversity),N);
for k = 1:length(Diversity)
   D = Diversity(k);
   for d = 1:D
      r(k,:) = r(k,:)+ abs(randn(1,N));
   end
   r(k,:) = 10*log10(r(k,:));
end

x3 = linspace(0,1,N);
s1 = sort(r.');
medianPow = s1(end/2,:);
h = [];
for k = 1:length(Diversity)
   hd1 = semilogy(s1(:,k)-medianPow(k),x3,'r');
   h = [h hd1];
   hold on
end

hold on

%=====================================
%   Measured diversity results
%=====================================
x3 = linspace(0,1,length(DivPowerB(:)));
s1 = sort(DivPowerB(:));
medianPow = s1(end/2);
hd3 = semilogy(s1-medianPow,x3,'b');

x3 = linspace(0,1,length(DivPower(:)));
s1 = sort(DivPower(:));
medianPow = s1(end/2);
hold on
hd2 = semilogy(s1-medianPow,x3,'b');

%hd = semilogy(s1,x3,'b') %-medianPow,x3,'b');


%hd3 = semilogy(s1,x3,'g') %-medianPow,x3,'b');

x3 = linspace(0,1,length(DataTot(:)));
s1 = sort(DataTot(:));
medianPow = s1(end/2);
hd1 = semilogy(s1-medianPow,x3,'b');

xlabel('Received Signal Strength (dB about median)');
ylabel('% Prob. Rx. Signal Strength < Abscissa');
legendstr = {'Measured','Rayleigh'};
legend([hd1 h(1)],legendstr,2);
title(['Separation : ' num2str(X(SepStep+1)) 'cm']);
axis([-28 4 0.001 1]);
xt = [-28:2:4];
set(gca,'xtick',xt);
s = num2str(xt.');
s(2:2:end,:) = ' '*ones(length(2:2:size(s,1)),size(s,2));
set(gca,'xticklabel',s);
setplotstyle
grid on
%plotm([h hd1 hd2 hd3],[0.002 0.04]); 
set(gca,'yticklabel',[1e-3 1e-2 1e-1 1]*100)
hold off   
set([hd1,hd2,hd3],'linewidth',3);
set(h,'linewidth',1.5);
legend
text(-24.5, 0.012, 'No Diversity','fontsize',22)
text(-19.5, 0.0023, 'Diversity 2','fontsize',22)
text(-6, 0.0023, 'Diversity 4','fontsize',22)
if SaveFlag
   savefig([figsdir '\' scriptnum s{k} '_cumdistdiv']);
end
end

if PlotPLDist
   H = findobj('tag','plotpldist');
   if isempty(H)
      figure
   else
      figure(H)
      clf
   end
   
L = find(LOS(PlotList));
N = find(~LOS(PlotList));
hl = plot(txrx(L),MeanPow(L),'bs');
hold on
hn = plot(txrx(N),MeanPow(N),'md');
WaveLen = 3e8/1005e6;
alpha = [2 2.5 3];
D = linspace(min(txrx),max(txrx),100);
PL = 10*log10((WaveLen./(4*pi*repmat(D,length(alpha),1))).^(repmat(alpha.',1,length(D))));
hd = plot(D,PL.');
hold off
legend([hl,hn,hd.'],'Meas. LOS','Meas. NLOS',['\alpha=' num2str(alpha(1))],['\alpha=' num2str(alpha(2))],...
   ['\alpha=' num2str(alpha(3))]);
set(hl,'markersize',16,'MarkerFaceColor','b')
set(hn,'markersize',16,'MarkerFaceColor','m')
setplotstyle(1.5,1,12)
axis tight
grid on
plotm(hd,50)
set(hl,'markersize',16,'MarkerFaceColor','b')
set(hn,'markersize',16,'MarkerFaceColor','m')
xlabel('Transmission Distance (m)');
ylabel('Path Gain (dB)')
S = cell(1,length(PlotList));
for k = 1:length(PlotList)
   S{k} = Position{PlotList(k)};
end
h = text(txrx+0.35,MeanPow,S,'fontsize',20);
set(gcf,'tag','plotpldist');
if SaveFlag
   savefig([figsdir '\' scriptnum s{k} '_pathloss_vs_dist']);
end
end
