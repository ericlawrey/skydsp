%This script plots the measured space-frequency propagation measurements
%made in the ECE building. 
clear all
scriptnum = 's0030_';	%Text added to start of all plots to track which
%								 script generates which plots.
d = 'cal_data';	%Directory of the data
figsdir = 'figs';
if exist([pwd filesep figsdir],'dir') == 0
   mkdir(figsdir);
end

%This script sets up a list of all the measured data sets. Each data set
%is a wideband radio channel characterisation measurement. 
%s - 			filenames of the data sets
%descript - description of the data set
%Xloc, Yloc, Zloc - location of the transmitter im metres, origin in is
%				Room 209. See TXRXlayout.gif
%Xrx,Yrx,Zrx - location of the start of the receiver.
PlotList = [1:8 10, 11];	%List of files to plot (with of the files listed in s)
SaveFlag = 0;				%0 - dont save plotted figures, 1 - save plotted figures
s = cell(1);						%Filenames of the data to plot
s{1} = 'rm120ceiling_c';
s{2} = 'rm209ceiling_c';
s{3} = 'rm122chair_c';
s{4} = 'rm210ceiling_abovetrack2_c';
s{5} = 'rm210chair_c';
s{6} = 'rm210ceiling_c';
s{7} = 'rm207ceiling_c';
s{8} = 'rm206chair_c';
s{9} = 'rm206ceiling_c';
s{10} = 'rm205chair_c';
s{11} = 'rm205ceiling_c';

hd = [];
SepStepList = [1:10 11:2:45];
PercentFadeList = [30 10 3 1 0.3 0.1]/100;	%Percentages to find the fading depth
FadingDepth = zeros(length(SepStepList),length(PercentFadeList),3);

for m = 1:length(SepStepList)
   DivPower = [];
	DivPowerB = [];
	DataTot = [];
   disp(['Calculating Diversity Step of : ' num2str(SepStepList(m)) ]);
   for l = 1:length(PlotList) %length(s)
      k = PlotList(l);
      disp(['Plotting ' int2str(k) ' of ' int2str(length(s))]);
      eval(['load 'd '\' s{k}]);
      
      SepStep = SepStepList(m);
      dist1 = 1:2:(size(Data,2)-SepStep);
      dist2 = (SepStep+1):2:size(Data,2);
      %dist1 = 1:SepStep:(size(Data,2)-SepStep);
      %dist2 = (SepStep+1):SepStep:size(Data,2);
      s1 = sort(Data(:));
      medianPow = s1(end/2);
      %medianLin = 10.^(medianPow/10);
      DataLin = 10.^((Data-medianPow)/10);
      DataTot = [DataTot 10*log10(DataLin)];
      DivPower = [DivPower 10*log10(DataLin(:,dist1)+DataLin(:,dist2))];
      
      Diversity = 4;
      CutOut = Diversity*SepStep;
      Index = 1:2:size(Data,2)-CutOut;
      DivOffset = ((0:Diversity-1)*SepStep)';
      %IndexMat = repmat(Index,Diversity,1)+repmat(DivOffset,1,length(Index));
      Acc = zeros(size(DataLin,1),length(Index));
      for k = 1:Diversity
         Acc = Acc+DataLin(:,Index+DivOffset(k));
      end
      DivPowerB = [DivPowerB 10*log10(Acc)];    
   end
   for n = 1:length(PercentFadeList)
   %Diversity of 4
   x3 = linspace(0,1,length(DivPowerB(:)));
   s1 = sort(DivPowerB(:));
   medianPow = s1(end/2);
   s1 = s1-medianPow;
   FadingDepth(m,n,1) = s1(round(PercentFadeList(n)*length(s1)));
   
   %Diversity of 2
   x3 = linspace(0,1,length(DivPower(:)));
   s1 = sort(DivPower(:));
   medianPow = s1(end/2);
   s1 = s1-medianPow;
   FadingDepth(m,n,2) = s1(round(PercentFadeList(n)*length(s1)));
   
   x3 = linspace(0,1,length(DataTot(:)));
   s1 = sort(DataTot(:));
   medianPow = s1(end/2);
   %hd1 = semilogy(s1-medianPow,x3,'r');
   s1 = s1-medianPow;
   FadingDepth(m,n,3) = s1(round(PercentFadeList(n)*length(s1))); %x3(max(find(s1<PercentFadeList(m))));
   end
end
figure(1)
 hd = plot(SepStepList,FadingDepth(:,2:end,1))
   xlabel('Separation between antennas (cm)');
   ylabel('Fading Depth');
   %legend([hd1 hd2 hd3],'No diversity','Diversity: 2','Diversity: 4',2);
   title(['Diversity: 4, Frequency: 1005 MHz']);
   %axis([-30 12 0.001 1]);
   LegendList = [num2str((PercentFadeList(2:end)')*100) repmat('%',length(PercentFadeList(2:end)),1)];
   legend(hd,LegendList,4)
   setplotstyle
   grid on
   plotm(hd,3)
   set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 15 20 25 30 40]);
   set(gca,'xscale','log')
   ylim([-20 -2]);
   set(gca,'ytick',[-20:2:-2]);
   if SaveFlag
      savefig([figsdir '\' scriptnum s{k} '_sepdiv4']);
   end
   figure(2)
    hd = plot(SepStepList,FadingDepth(:,2:end,2))
   xlabel('Separation between antennas (cm)');
   ylabel('Fading Depth (dB from median)');
   %legend([hd1 hd2 hd3],'No diversity','Diversity: 2','Diversity: 4',2);
   title(['Diversity: 2, Frequency: 1005 MHz']);
   %axis([-30 12 0.001 1]);
   LegendList = [num2str((PercentFadeList(2:end)')*100) repmat('%',length(PercentFadeList(2:end)),1)];
   legend(hd,LegendList,4)
   setplotstyle
   grid on
   plotm(hd,3)
      set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 15 20 25 30 40]);
   set(gca,'xscale','log')
   ylim([-24 -4]);
   set(gca,'ytick',[-24:2:-4]);
   xlim([1 45])
   if SaveFlag
      savefig([figsdir '\' scriptnum s{k} '_sepdiv2']);
   end