Diversity = [ 1, 2, 4];
N = 50e3;
r = zeros(length(Diversity),N);
for k = 1:length(Diversity)
   D = Diversity(k);
   for d = 1:D
      r(k,:) = r(k,:)+ abs(randn(1,N));
   end
   r(k,:) = 10*log10(r(k,:));
end

x3 = linspace(0,1,N);
s1 = sort(r.');
medianPow = s1(end/2,:);
h = [];
for k = 1:length(Diversity)
   hd1 = semilogy(s1(:,k)-medianPow(k),x3,'r');
   h = [h hd1];
   hold on
end
hold off
xlabel('Received Signal Strength (dB about median)');
ylabel('% Prob. Rx. Signal Strength < Abscissa');
%legend([hr, hd(1)],'Rayleigh Fading','Measured',2);
axis([-30 10 0.001 1]);
setplotstyle
grid on
