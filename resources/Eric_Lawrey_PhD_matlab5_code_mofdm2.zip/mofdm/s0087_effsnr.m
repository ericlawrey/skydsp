%This script plots the spectral efficiency of a single user adaptive modulation scheme
%as a function of the average SNR of a fading channel. The channel used for these measurements
%was 'rm206chair_c'. The simulation used for generating the results was d0059_singleuser_SNR, which
%is run by calling s0059_aofdm.
%The BER threshold of this simulation was 2e-6 and the delay by one update, and the update rate was
%50 per wavelength travelled.

SNR = [3 6 9 12 15 18 21 24 27 30 33 36 39 42];
%Modulation schemes used : [1 2 4 6]
SpecEff = [0.0073 0.0929 0.343 0.726 1.244 1.893 2.629 3.47 4.29 4.96 5.44 5.71 5.86 5.93];
BER = [1.33e-5 7.83e-5 6.6e-6 5.73e-6 6.38e-6 8.29e-6 1.25e-5 1.85e-5 2.1e-5 2.04e-5 2.19e-5 2.14e-5 2.41e-5 1.97e-5];

%Modulation schemes used : [1 2 3 4 5 6]
SpecEff2 = [0.0073 0.0929 0.343 0.777 1.393 2.147 2.985 3.845 4.606 5.188 5.57 5.784 5.896 5.952];
BER2 = [1.33e-5 7.83e-6 6.65e-6 6.75e-6 7.76e-6 1.02e-5 1.55e-5 2.31e-5 2.96e-5 3.7e-5 4.21e-5 4.72e-5 4.56e-5 3.33e-5];

%Modulation schemes used : [1 2 3 4 5 6 7 8 9 10]
SpecEff3 = [0.0073 0.0929 0.343 0.777 1.393 2.147 2.985 3.884 4.824 5.791 6.78 7.731 8.549 9.162]
BER3 = [1.33e-5 7.83e-6 6.65e-6 6.75e-6 7.76e-6 1.02e-5 1.55e-5 2.33e-5 2.98e-5 3.62e-5 4.01e-5 4.38e-5 4.62e-5 4.75e-5];
      
h= plot(SNR,SpecEff, SNR, SpecEff2, SNR, SpecEff3);
xlabel('Average SNR (dB)');
ylabel('Spectral efficiency (b/s/Hz)')
title('Coherent QAM Single User Adaptive Modulation');
legend(h,'Mods: [1 2 4 6] b/s/Hz','Mods: [1 2 3 4 5 6] b/s/Hz', 'Mods: [1 2 3 4 5 6 7 8 9 10] b/s/Hz' ,2)
setplotstyle
plotm(h,[0.3 0.7])
axis tight
grid on
