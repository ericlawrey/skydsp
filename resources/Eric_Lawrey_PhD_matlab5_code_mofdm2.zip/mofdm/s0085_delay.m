%This script plots the effect of delay on the BER for an adaptive modulation system
%These results were obtained using d0059_delay simulated with s0059_aofdm
%

%Results from Data set 1, rm120ceiling_c

DistScale = 0.00201;	%Distance in wavelengths for 1 unit of delay
Delay = [0 5 10 15 20 25 30 35 40 45 50 55 65 75 85 95 105 120 135 150]*DistScale; %(units of wavelengths)
BER = [2.21e-6 3.65e-6 7.58e-6 1.758e-5 4.05e-5 8.82e-5 0.000174 0.0003135,...
      0.000514 0.000784 0.001126 0.00154 0.002559 0.003793 0.00519 0.00674,...
      0.00842 0.01109 0.0139 0.0166];
%Data for fileindex 8, 'rm206chair_c'
Delay8 = [0 5 10 15 20 25 30 35 40 45 50 55 65 75 85 95 105 120 135 150]*DistScale;
BER8 = [2.1547e-006 3.2241e-006 5.9601e-006 1.2703e-005 2.8398e-005 6.2475e-005 ,...
         0.00012905 0.00023976 0.000401 0.00061456 0.00087946 0.0011935 0.0019775,...
         0.0029186 0.0039887  0.005176 0.0064877 0.0086048 0.010744 0.01275];
   
%Data for FileIndex 4 'rm210ceiling_abovetrack2_c'
Delay4 = [0 5 10 15 20 25 30 35 40 45 50 55 65 75 85 95 105 120 135 150]*DistScale;
BER4 = [ 2.1755e-006 3.8319e-006 9.1966e-006 2.5095e-005 6.3784e-005  0.00014154,...
         0.0002716  0.00046124  0.00072562   0.0010618   0.0014766   0.0019672,...
         0.0031362   0.0044829   0.0059359   0.0074841    0.009101     0.01148,...
         0.013552    0.015375];
%
Delay4_30dB = [0 5 10 15 20 25 30 35 40 45 50 55 65 75 85 95 105 120 135 150]*DistScale
BER4_30dB = [2.2573e-006  1.069e-005 3.7116e-005  0.00010079  0.00021501  0.00038271,...
      0.00060298  0.00086334   0.0011582   0.0014645   0.0017858   0.0021045   0.0027239 ,...
      0.003258   0.0036703   0.0039958   0.0042597   0.0045289   0.0046486    0.004737];
%   h = semilogy(Delay,BER, Delay8, BER8,'r',Delay4,BER4,'g');
   h = loglog(Delay,BER4,'r', Delay4_30dB, BER4_30dB,'b');
xlabel('Delay (wavelengths)')
ylabel('BER')
title('BER threshold 1x10^-^6, Mod. Update Rate: 50 per wavelength') 
axis([0.01 0.3 1e-6 1e-1]);
legend(h,'SNR: 17 dB','SNR: 30 dB')
grid on
setplotstyle
plotm(h,[0.05 0.3])
set(gca,'xticklabel',['0.01';' 0.1'])
savefig('s0085_delay')