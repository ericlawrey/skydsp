function BestMinAlloc = MaxMinAlloc(WeightFactor,Ncarrier,Ntrials)
%Allocate carriers so that the minimum throughput for each user is
%maximised. This will improve quality of service.
%
% WeightFactor is the fitness of each carrier for each user, with
%    one user per column.
% Ncarriers is a vector of the number of carrier for each user
%
% Ntrials Number of Trials to run.

BestTotalAlloc = [];
BestMinAlloc = [];

BestTotal = 0;
BestTotalMin = 0;

BestMin = 0;
BestMinTotal = 0;
%BestMinList = [];
%BestMinK = [];
%CarrierList = cell(Ncarrier);
%for k = 1:length(Ncarrier)
%   CarrierList = [CarrierList ones(1,Ncarrier(k))*k];
%end
%CarrierList
s = [0 cumsum(Ncarrier)];
for l = 1:Ntrials;
   r = randperm(size(WeightFactor,1));
   for k = 1:length(Ncarrier)
      CarrSNR(k) = sum(WeightFactor(r(s(k)+1:s(k+1)),k));
   end
   
   
   %alloc = CarrierList(r);	%ceil(r/NcarriersEach);
   %I = sub2ind(size(WeightFactor),1:size(WeightFactor,1),alloc);
   %SNR = WeightFactor(I);
 %  totalSNR = sum(SNR);
   %for k = 1:size(WeightFactor,2)
   %   CarrSNR(k) = sum(SNR(find(alloc==k)));
   %end
   minSNR = mean(CarrSNR);
%   if ((totalSNR>BestTotal)|((totalSNR==BestTotal)&(minSNR>BestTotalMin)))
%	      BestTotalAlloc = alloc;
%   	   BestTotal = totalSNR;%
%			BestTotalMin = minSNR;      
%         disp(['Best Total: ' num2str(BestTotal) ', Min: ' num2str(minSNR)]); % , ', Alloc: ' num2str(BestTotalAlloc)])
%         drawnow   
%   end
if ((minSNR>BestMin)) %|((minSNR==BestMin)&(totalSNR>BestMinTotal)))
   alloc = cell(1,length(Ncarrier));
   for a = 1:length(Ncarrier)
      alloc{a} = sort(r(s(a)+1:s(a+1)));
   end
   
      	BestMinAlloc = alloc;
         BestMin = minSNR;
         BestMinTotal = sum(CarrSNR);
%         BestMinList = [BestMinList minSNR];
%         BestMinK = [BestMinK l];
%         disp(['Best Min: ' num2str(BestMin) ', Total: ',num2str(BestMinTotal)]); %, ', Alloc: ' num2str(BestMinAlloc)])
%   		drawnow      
   end
   %if rem(k,10)==0
   %   disp(['Calculated ' num2str(k)])
   %end
         
end
%disp('test')

