load s0059_BER_track_fix3
BERList_fix = BERList;
VelList_fix = VelList;
SysDataFix = SysData;

load s0059_BER_track2
legendstr = {['Adapt, Margin 0 dB, ' num2str(SysData(1),4) ' Mbps'],['Adapt, Margin 2 dB, ' num2str(SysData(2),4) ' Mbps'],...
      ['Fixed, Margin 0 dB, ' num2str(SysDataFix(1),4) ' Mbps'],['Fixed, Margin 2 dB, ' num2str(SysDataFix(2),4) ' Mbps']};
Dist = VelList/TrackingRate/0.298;	%Find the dist as a fraction of the wavelength
h = semilogy(Dist,BERList,Dist,BERList_fix);
plotm(h,1)
legend(h,legendstr,4)

xlabel('Distance between Tracking (Fraction of wavelength)');
ylabel('Bit Error Rate')
title('Adaptive Modulation allocation threshold BER of 1x10^-^5')
setplotstyle(1.5,1,15)
grid on
set(gca,'xtick',[0:0.02:0.18])
xlim([0 0.165])
savefig('s0061_ber_track_div1')