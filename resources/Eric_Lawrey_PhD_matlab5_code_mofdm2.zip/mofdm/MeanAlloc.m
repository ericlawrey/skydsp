function Alloc = MeanAlloc(WeightFactor,Ncarrier,CurrentSNR)
%WeightFactor is matrix with one user per column, with each column
%being the SNR of the subcarriers for that user.
%Ncarrier is the number of subcarriers that are to be allocated
%to that user. The subcarriers are allocated in order from best to
%worst based on the average SNR (WeightFactor). The user with lowest average
%SNR is allocated first.
if nargin==3
	[Y,I] = sort(CurrentSNR);
else
   if size(WeightFactor,2)>1
   	mn = mean(WeightFactor);
   	[Y,I] = sort(mn);
	else
   	I = 1;
   end
end   
c = 1:size(WeightFactor,1)';
Alloc = cell(1,size(WeightFactor,2));
%I = I(end:-1:1);
for k = 1:length(I)
   w = WeightFactor(:,I(k));
   c2 = c(:);
   [Y,I2] = sort(w);
   Nc = min(Ncarrier(I(k)),length(I2));
   I3 = I2(end-Nc+1:end);
   Alloc{I(k)} = c2(I3)';
   WeightFactor(I3,:) = [];
   c(I3) = [];
end

   
   
   