%S0065_BERTHEORY Script to calculate expected BER from adaptive modulation
%This script calculates the expected BER for an adaptive modulation scheme,
%given a set BER threshold. If we allocate based on a BER threshold of X,
%e.g. X=1e-5, then we find that if the adaptive scheme tracks very quickly 
%the BER is lower than this threshold, in fact it is closer to 1.3e-6. This
%script calculates the expected value based on theory.

B = 1e-2;	%BER threshold
M = 1:10;	%Set of modulation schemes, Bits/Hz for QAM
I = 300;		%Number of steps in the integration
S = snrthresh(B,M);
for k = 1:length(S)-1
   %Find the BER between the SNR thresholds used for allocation
   b = (snr2ber(linspace(S(k),S(k+1),300),M(k)));
   %Replace all the NaNs caused by very low BER with 0
   ind = find(isnan(b));
   b(ind) = 0;
   BM(k) = mean(b);
end
MeanBER = mean(BM)
S2 = snrthresh(MeanBER,M);
EffMargin = mean(S2-S)