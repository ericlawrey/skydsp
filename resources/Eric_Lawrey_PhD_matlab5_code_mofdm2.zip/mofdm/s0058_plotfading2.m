load ..\fadingmeas\cal_data\rm205chair_c


Plottype = 2;			%Plottype = 1, Plot each distance measurement of the frequency response
%Plottype = 2, plot successive increases in the system bandwidth, using subplots
DataNorm = normdata(Data);

AvFrm = 1;	%Number of frames to average before writting to an image
%				useful for showing the data at high speed
UpdateDelay = 1;
Ncarr = 30;
width = 640;
height = 480;
xoff = 1;
yoff = 29;
lowlimit = -25;
scale = width/500;
fontsize = 12*scale;
dotsize = 35*scale;
ringsize = 12*scale;
linewidth = 3*scale;
polylinewidth = 1.5*scale;
barlinewidth = 5*scale;
axislinewidth = 1.8*scale;
markerline = 1.2*scale;
fontweight = 'bold';
OptType = 3;		%Maximise the worst case carrier power

setplotsize(width,height)
NarrowBW = round(size(Data,1)*0.2);
Axis = [min(F) max(F) -25 10];

IFreqFixed = round(size(Data,1)/2);
FullBandColour = [0.8 0.8 0.8];	%Colour of th full spectrum
FullBandLowLimit = -25;
k = 1;
AFHcarrs = repmat(1:Ncarr,UpdateDelay,1);

distlist = 1:1:size(Data,2);
for k = 1:length(distlist) %1:1:size(Data,2)/10
   dist = distlist(k);
   hf = figure(1);
   clf
   subplot(2,1,1);
   
   set(hf,'color',[1,1,1]);
   PowData = DataNorm(:,dist);
   plotarea(F,PowData,FullBandColour,FullBandLowLimit,polylinewidth)
   hold on
   axis(Axis)
   %===========================================
   %Calculate for a Fixed Frequency User Allocation Scheme
   %===========================================
   car_index = alloccarrs(PowData,Ncarr,1,OptType);
   cmin = min(PowData(car_index));
   cmean = mean(10.^(PowData(car_index)/10));
   cmax = max(PowData(car_index));
   FixedMin = cmin; 
	FixedMean = 10*log10(cmean);
   FixedMax = cmax;
   C = [1 0 0];
   hpos = 0;
   width = 0.1;
   plotbar(FixedMin,width,hpos,barlinewidth,C);
   plotbar(FixedMax,width,hpos,barlinewidth,C);
   plotcarr(car_index,F,PowData,C,lowlimit,polylinewidth);
   
   %===========================================
   %Calculate for a Comb User Allocation Scheme
   %===========================================
   car_index = alloccarrs(PowData,Ncarr,2,OptType);
   cmin = min(PowData(car_index));
   cmean = mean(10.^(PowData(car_index)/10));
   cmax = max(PowData(car_index));
   CombMin = cmin; 
	CombMean = 10*log10(cmean);
   CombMax = cmax;
   C = [0 0 1];
   hpos = 1;
   width = 0.1;
   axis(Axis);
   plotbar(CombMin,width,hpos,barlinewidth,C);
   plotbar(CombMax,width,hpos,barlinewidth,C);
   plotcarr(car_index,F,PowData,C,lowlimit,polylinewidth,C);
  
   axis(Axis);
   
   
   d = sprintf('%3d',round(dist*1.015));
   set(gca,'fontsize',fontsize,'linewidth',axislinewidth,'fontweight',fontweight);
   title(['Distance Travelled: ' d ' (cm)']);
   ylabel('Rx Power (dB)');
   xlabel('Frequency (MHz)'); 
   
   %===========================================
   
   subplot(2,1,2);
  
   set(hf,'color',[1,1,1]);
   plotarea(F,PowData,FullBandColour,FullBandLowLimit,polylinewidth)
   axis(Axis)
   hold on
   
   %===========================================
   %Calculate for a Single Group Frequency User Allocation Scheme
   %===========================================
   car_index = alloccarrs(PowData,Ncarr,3,OptType);
   index = mod(k,UpdateDelay)+1;

	car_index_delayed = AFHcarrs(index,:);
	AFHcarrs(index,:) = car_index;
   cmin = min(PowData(car_index_delayed));
   cmean = mean(10.^(PowData(car_index_delayed)/10));
   cmax = max(PowData(car_index_delayed));
   FixedMin = cmin; 
	FixedMean = 10*log10(cmean);
   FixedMax = cmax;
   C = [1 0.5 0];
   hpos = 0;
   width = 0.1;
   plotbar(FixedMin,width,hpos,barlinewidth,C);
   plotbar(FixedMax,width,hpos,barlinewidth,C);
   plotcarr(car_index_delayed,F,PowData,C,lowlimit,polylinewidth);
   
   %===========================================
   %Calculate for a Single Group User Allocation Scheme (Narrow Bandwidth)
   %===========================================
   Pmid = ceil(size(DataNorm,1)/2);
   Pmin = round(Pmid-floor(NarrowBW-1)/2);
   Pmax = round(Pmid+floor(NarrowBW-1)/2);
   PowData2 = DataNorm(Pmin:Pmax,dist);
   Fn = F(Pmin:Pmax);
   car_index = alloccarrs(PowData2,Ncarr,3,OptType,[],2);
   cmin = min(PowData2(car_index));
   cmean = mean(10.^(PowData2(car_index)/10));
   cmax = max(PowData2(car_index));
   CombMin = cmin; 
	CombMean = 10*log10(cmean);
   CombMax = cmax;
   C = [0 1 0];
   hpos = 1;
   width = 0.1;
   axis(Axis);
   plotbar(CombMin,width,hpos,barlinewidth,C);
   plotbar(CombMax,width,hpos,barlinewidth,C);
   plotcarr(car_index,Fn,PowData2,C,lowlimit+1,polylinewidth);
   plot([Fn(1) Fn(1)],[lowlimit +10],'g','linewidth',markerline);
   plot([Fn(length(Fn)) Fn(length(Fn))],[lowlimit +10],'g','linewidth',markerline);
   axis(Axis);

	set(gca,'fontsize',fontsize,'linewidth',axislinewidth,'fontweight',fontweight); 
   ylabel('Rx Power (dB)');
   xlabel('Frequency (MHz)');  
     
   drawnow
   f2 = getframe(gcf);
   if AvFrm > 1
      
	   f = double(f2.cdata)/248;
   	if mod(k,AvFrm) == 1
	      fav = f;
   	else
	      fav = fav +f;
   	end
   
   	if mod(k,AvFrm) == 0 
         fav = fav/AvFrm;
         s = '0000';
         s2 = int2str(k/AvFrm);
         s((end-length(s2)+1):end) = s2;
	      filename = ['movie\f' s '.tif'];
		   imwrite(fav,filename,'tif','compression','packbits');	
      end
   else
      s = '0000';
         s2 = int2str(k);
         s((end-length(s2)+1):end) = s2;
      	filename = ['movie\f' s '.tif'];
		   imwrite(f2.cdata,filename,'tif','compression','packbits');
   end
end   
	
  
   
   
   



