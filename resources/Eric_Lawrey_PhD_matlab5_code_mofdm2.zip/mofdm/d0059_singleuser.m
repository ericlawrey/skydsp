DistribList = [0.9 0.98 0.995 0.999];	%Estimate the Tracking Error at these distribution points
VelList = 3;	%[1,2,4,6,8,10,12,14,16,18,20,22,24];		%Vector of velocities to run the test over. 
%                 This is for checking the effect of velocity on the tracking error.
AllocScheme = 2;				%Allocation scheme (0) - Adaptive User Allocation
%									(1) - Random Frequency
%									(2) - Fixed Group of carriers (i.e. FDM)
%									(3) - Time Division Multiplexing (Allocates new modulation each time slot)
%									(4) - Comb pattern (not implemented)
AdaptModFlag = 0;				%(1) - Use adaptive modulation, i.e. allocate the modulation scheme
%									based on the SNR of the channel
%									(0) - Use a fixed modulation scheme
ModScheme = 2;					%Modulation Scheme to use if adaptive modulation isn't used
%									i.e. if AdaptModFlag = 0; ModScheme is the bits/Hz/sec to use
%  								which is coherent qam, i.e. ModScheme = 4, then mod scheme is 16QAM
BERThresh = 2e-6;				%BER threshold to use for deciding on the SNR required for each modulation scheme
BERrange = [-6 -1];			%Range to show on the BER plot in 10^(BERrange), this is applied to caxis
SNRReq = 33.5;					%SNR to aim for, for the power control
SavePlotFlag = 0;				%(1) - Save figures (0) - Don't
PlotFlag = 0;					%1 - Generate all plots, 0 - only display summary, no plots   
%PostFix = '_TDMA_PC';		%Add This to the end of the saved figure filename
PostFix = '_fix_2bits_17dB';		%Add This to the end of the saved figure filename
EstimationError = [];
EstErrorFlag = 0;				%Estimate the error in the tracking, by looking at the difference
%									between the measure points and the interpolated times between.
EstCaxis = [-6 6];			%Caxis for estimation error plot, range to show in dB
Nusers = 1;					%Number of users in the cell.
TrackingRate = 500;			%Tracking rate in Hz.
SymbolPerTrack = 10;			%round(UserVelocity(1))*2;
SymbolRate = SymbolPerTrack*TrackingRate;	%Symbol rate, the BER is evaluated for each symbol.
TrackingDelay = 10;			%Delay between measurement and user allocation update, in symbols
Ncarriers = 200;				%Number of carriers used in the system
CarrGroup = 1;					%Allocate by groups of carriers
SystemBW = 65;					%System Bandwidth in MHz;
UserBW = [floor(Ncarriers/Nusers)*ones(1,Nusers)];
%[1 1 1 1 1 1 1 1 1 1]*CarrGroup*floor(Ncarriers/Nusers); %	%Number of carriers used by each user
Ntrials = 100;					%Number of trials to search for user allocation
PowControlFlag = 1;			%(1) Use simple power control to make the mean SNR of all users the same.
%									(0) no power control, have user power set by TxPow variable

MaxPower = 100;					%Maximum transmitted power when using power control (dBm).

Pathloss = 0;					%The data is rescaled to so that the mean pathloss to the users, set this to
%									zero for normal scaling. A different pathloss can be specified for each user.
%									Pathloss should be 1 in length or Nusers in length.

TxPow = 0*ones(1,Nusers);		%Transmitter Power in dBm, if PowControlFlag = 0;

RxNF = 7;						%Receiver Noise Figure (dB)
AntTemp = 300;					%Antenna Temperature (Kelvin)
CarrierBW = (SystemBW/Ncarriers);	%Carrier Bandwidth (MHz);
Thresh = 12;					%Threshold to try and maintain the SNR, by using adaptive bandwidth, only used
%									for AllocScheme==0
Thresh2 = 6;					%User SNR must be at least Thresh2 dB above Thresh before free carriers are allocated
%									to them. Only used for AllocScheme==0
Margin = 0;						%When deciding on the modulation scheme, allocated based on a margin of Margin in dB
Degradation = 1;				%Degradation in the SNR (dB) when calculating the BER, this is compensate for other effects
%									not included in the simulation, such as imperfect channel characterisation, frequency
%									errors, etc
FreqImagFlag = 1;				%Create an image showing the frequencies used by each user (1) - Create image, (0) - don't
Ntrials = 10;					%Number of trials to get the user allocation correct
NtrialsUser1 = 10;			%Number of trials for the adaptive bandwidth for when the number of users == 1
NumDataSamps = 1000;			%Number of samples from the data files to use. Change this number to change the
%									amount of distance simulated. This is useful for some plots which become too
%									cluttered if too much data is simulated. Set NumDataSamps to a large number
%									to use all the data samples available in the data set
Ntaps = 1;				%Number of filter coefficient to use, when applying filtering to the measured data
%							before any user allocation schemes are applied. The filtering is applied before
%							the data is interpolated. [Taps in Time, Taps in Freq]
%							if no filtering is required set Ntaps = 1;
FiltBlur = [0.6 1.5];	%Amount of blurring, standard deviation of the gaussian 2D filter applied to the
%							data in units of samples. [StdDev in Time, StdDev in Freq].
%							FiltBlur is ignored if Ntaps = 1;
ModList = [1:6];		%List of modulation schemes to use in bits/Hz/sec for coherent QAM

Diversity = 1;			%Number of Receivers used to power combine the signal. This diversity is simulated
%							by combining multiple data sets. For a diversity of 2, the second data set is normalised 
%							in power to match the base data set, then the two are added together (in linear).
%							There are only 10 data sets available and so using a diversity of 2 restrict the number
%							of users to 5. A diversity of 3 only allows 3 users, etc.
Xaxis = 1;				%1 - Display xaxis as a function of distance. 0 - Display as a function of time
SNRPlotFlag = 1;		%1 - plot the channel SNR, only works for a single user, 0 - don't plot SNR
SNRplotRange = [5 25];	%Range for the SNR plot in dB, sets the caxis for the SNR plot
%rand('seed',12934)
rand('seed',12234934)