function plotcarr(car_index,Freq,Pow,C,lowlimit,linewidth,EdgeC)
%This function draws the carriers as filled polygons similar to a bar plot
if nargin < 7
   EdgeC = [0 0 0];	%Black edge on the fills
end

car_index = sort(car_index); %Make sure the indexes are ascending order

FreqStep = Freq(2)-Freq(1);
if length(car_index) == 1
   F = [ Freq(car_index) Freq(car_index)+FreqStep];
   P = [ Pow(car_index) Pow(car_index)];
   plotarea(F,P,C,lowlimit,linewidth)
else
   
   

   indexs = [car_index(1)];
   for k = 2:length(car_index)
      Idiff = car_index(k)-car_index(k-1);
      %If there is a gap draw the fill, also draw the last fill
      if (Idiff > 1)|(k == length(car_index))
         %There is a Gap in the carriers therefore plot previous segment as a
         %filled area
         
         %If there is only one carrier, draw it from 0 to +1 bins around the carrier
         if length(indexs) == 1
            F = [ Freq(indexs) Freq(indexs)+FreqStep];
            P = [ Pow(indexs) Pow(indexs)];
         
            plotarea(F,P,C,lowlimit,linewidth,EdgeC)
         else
            plotarea(Freq(indexs),Pow(indexs),C,lowlimit,linewidth,EdgeC)
         end
         %Reset the grouping
         indexs = [];
         
      end

      indexs = [indexs car_index(k)];
   end
end