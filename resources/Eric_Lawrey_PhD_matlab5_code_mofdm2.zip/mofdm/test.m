u = [15 12 5 1 9 20 30 25; 20 25 30 28 20 5 0 5; 8 0 13 25 4 12 9 3; 30 40 45 28 20 10 15 8]';
Nusers = 50;
NcarriersEach = 10;
Carrier = Nusers*NcarriersEach;
rand('seed',19872987)
u = rand(Carrier,Nusers);
rand('seed',sum(clock));
BestTotalAlloc = [];
BestMinAlloc = [];

BestTotal = 0;
BestTotalMin = 0;

BestMin = 0;
BestMinTotal = 0;
%BestMinList = [];
%BestMinK = [];
for l = 1:500;
   r = randperm(size(u,1));
   alloc = ceil(r/NcarriersEach);
   I = sub2ind(size(u),1:size(u,1),alloc);
   SNR = u(I);
   totalSNR = sum(SNR);
   for k = 1:size(u,2)
      CarrSNR(k) = sum(SNR(find(alloc==k)));
   end
   minSNR = min(CarrSNR);
   if ((totalSNR>BestTotal)|((totalSNR==BestTotal)&(minSNR>BestTotalMin)))
	      BestTotalAlloc = alloc;
   	   BestTotal = totalSNR;
			BestTotalMin = minSNR;      
         disp(['Best Total: ' num2str(BestTotal) ', Min: ' num2str(minSNR)]); % , ', Alloc: ' num2str(BestTotalAlloc)])
         drawnow   
   end
   if ((minSNR>BestMin)|((minSNR==BestMin)&(totalSNR>BestMinTotal)))
      	BestMinAlloc = alloc;
         BestMin = minSNR;
         BestMinTotal = totalSNR;
         BestMinList = [BestMinList minSNR];
         BestMinK = [BestMinK l];
         disp(['Best Min: ' num2str(BestMin) ', Total: ',num2str(totalSNR)]); %, ', Alloc: ' num2str(BestMinAlloc)])
   		drawnow      
   end
   %if rem(k,10)==0
   %   disp(['Calculated ' num2str(k)])
   %end
         
end

