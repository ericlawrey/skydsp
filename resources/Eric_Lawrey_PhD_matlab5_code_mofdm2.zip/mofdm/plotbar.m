function plotbar(Y,width,hpos,linewidth,C)
%Plots a horizontal bar on the current plot or height Y
%width - width of the line (fraction of plot width)
%hpos - horizontal position of the line (fraction of plot)
%linewidth - linewidth of the horizontal line
%C - colour of the line
a = axis;
axis manual

scaledwidth = (a(2)-a(1))*width;
scaledpos = (a(2)-a(1))*hpos+a(1);
lxmin  = scaledpos-scaledwidth/2;
lxmax  = scaledpos+scaledwidth/2;
h = line([lxmin lxmax], [Y Y]);
set(h,'linewidth',linewidth,'color',C);
axis(a);

