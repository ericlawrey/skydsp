function C = bluegreen(m);
G = gray(m);
GB = (cos(G(:,3).^1.8*pi*2)/2+0.5).*(linspace(0.5, 1,m).');
G2 = [1-((1-(G(:,1).^2)).^3), G(:,2).^0.5, GB];
C = G2;