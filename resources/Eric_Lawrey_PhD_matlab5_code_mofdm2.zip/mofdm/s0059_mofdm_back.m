%This script simulates adaptive user allocation, and adaptive bandwidth allocation and adaptive
%modulation. This simulation does not take into account problems associated with obtaining the
%channel response, the information tranfer required to actually perform the user allocation schemes
%problems caused by distortion, non-orthogonal effects.
%This simulation uses the frequency response measurements taken around the ECE building at
%James Cook University.
%
% Copyright Eric Lawrey April 2001


tic
DistribList = [0.9 0.98 0.995 0.999];	%Estimate the Tracking Error at these distribution points
VelList = 5;	%[1,2,4,6,8,10,12,14,16,18,20,22,24];		%Vector of velocities to run the test over. This is for checking the effect of
%						velocity on the tracking error.
EstList = zeros(length(VelList),length(DistribList));
BERList = zeros(1,length(VelList));
for V = 1:length(VelList)
   ReloadFlag = 1;				%(1) - Reload the Channel Data, not required if run before and
   %									the velocity, number of users and number of carrier haven't changed
   disp(['Velocity : ' num2str(VelList(V)) 'm/s, ' num2str(V) ' of ' num2str(length(VelList)) ]);
   %if ReloadFlag
   %   clear all
   %   ReloadFlag = 1;
   
   %end
   AllocScheme = 2;				%Allocation scheme (0) - Adaptive User Allocation
   %									(1) - Random Frequency
   %									(2) - Fixed Group of carriers (i.e. FDM)
   %									(3) - Time Division Multiplexing
   %									(4) - Comb pattern (not implemented)
   AdaptModFlag = 0;				%(1) - Use adaptive modulation, i.e. allocate the modulation scheme
   %									based on the SNR of the channel
   %									(0) - Use a fixed modulation scheme
   ModScheme = 2;					%Modulation Scheme to use if adaptive modulation isn't used
   %									i.e. if AdaptModFlag = 0; ModScheme is the bits/Hz/sec to use
   %  								which is coherent qam, i.e. ModScheme = 4, then mod scheme is 16QAM
   BERThresh = 2e-6;		%BER threshold to use for deciding on the SNR required for each modulation scheme
   BERrange = [-6 -1];		%Range to show on the BER plot in 10^(BERrange), this is applied to caxis
   SNRReq = 17.41;					%SNR to aim for, for the power control
   disp('test')
   %   MaxMod = 10;			%Maximum modulation scheme	in Bits/Hz/sec
   SavePlotFlag = 1;					%(1) - Save figures (0) - Don't
   PlotFlag = 1;		%1 - Generate all plots, 0 - only display summary, no plots   
   PostFix = '_fix_2bits_17dB';						%Add This to the end of the saved figure filename
   EstimationError = [];
   EstErrorFlag = 1;				%Estimate the error in the tracking, by looking at the difference
   %									between the measure points and the interpolated times between.
   EstCaxis = [-6 6];			%Caxis for estimation error plot, range to show in dB
   Nusers = 1;							%Number of users in the cell.
   UserVelocity = VelList(V)*ones(1,Nusers); %[1 10 3 8 4 6 2 8 3 6];		%Velocity of the users in metres/sec
   TrackingRate = 500;				%Tracking rate in Hz.
   SymbolPerTrack = 10;	%round(UserVelocity(1))*2;
   SymbolRate = SymbolPerTrack*TrackingRate;	%Symbol rate, the BER is evaluated for each symbol.
   TrackingDelay = 10;				%Delay between measurement and user allocation update, in symbols
   Ncarriers = 200;					%Number of carriers used in the system
   CarrGroup = 1;						%Allocate by groups of carriers
   SystemBW = 65;						%System Bandwidth in MHz;
   UserBW = 200; %[floor(Ncarriers/Nusers)*ones(1,Nusers)];
   %[1 1 1 1 1 1 1 1 1 1]*CarrGroup*floor(Ncarriers/Nusers); %	%Number of carriers used by each user
   Ntrials = 100;						%Number of trials to search for user allocation
   PowControlFlag = 1;	%(1) Use simple power control to make the mean SNR of all users the same.
   %							(0) no power control, have user power set by TxPow variable
   
   MaxPower = 100;			%Maximum transmitted power.
   
   Pathloss = 0;		%The data is rescaled to so that the mean pathloss to the users, set this to
   %							zero for normal scaling. A different pathloss can be specified for each user.
   %							Pathloss should be 1 in length or Nusers in length.
   
   if (ReloadFlag)
      TxPow = 25*ones(1,Nusers);		%Transmitter Power in dBm, if PowControlFlag = 0;
   end
   
   %TxPow = [10.9698  -10.6048   -8.3240  -17.2581    1.9020   25.1698    1.4155 10.8018];
   RxNF = 7;							%Receiver Noise Figure (dB)
   AntTemp = 300;						%Antenna Temperature (Kelvin)
   CarrierBW = (SystemBW/Ncarriers);	%Carrier Bandwidth (MHz);
   Thresh = 12;		%Threshold to try and maintain the SNR, by using adaptive bandwidth, only used
   %						for AllocScheme==0
   Thresh2 = 6;		%User SNR must be at least Thresh2 dB above Thresh before free carriers are allocated
   %						to them. Only used for AllocScheme==0
   Margin = 0;			%When deciding on the modulation scheme, allocated based on a margin of Margin in dB
   Degradation = 1;	%Degradation in the SNR (dB) when calculating the BER, this is compensate for other effects
   %						not included in the simulation, such as imperfect channel characterisation, frequency
   %						errors, etc
   FreqImagFlag = 1;		%Create an image showing the frequencies used by each user (1) - Create image, (0) - don't
   Ntrials = 10;			%Number of trials to get the user allocation correct
   NtrialsUser1 = 10;		%Number of trials for the adaptive bandwidth for when the number of users == 1
   NumDataSamps = 1000;	%Number of samples from the data files to use. Change this number to change the
   %							amount of distance simulated. This is useful for some plots which become too
   %							cluttered if too much data is simulated. Set NumDataSamps to a large number
   %							to use all the data samples available in the data set
   Ntaps = [3 5];		%Number of filter coefficient to use, when applying filtering to the measured data
   %							before any user allocation schemes are applied. The filtering is applied before
   %							the data is interpolated. [Taps in Time, Taps in Freq]
   %							if no filtering is required set Ntaps = 1;
   FiltBlur = [0.6 1.5];	%Amount of blurring, standard deviation of the gaussian 2D filter applied to the
   %							data in units of samples. [StdDev in Time, StdDev in Freq].
   %							FiltBlur is ignored if Ntaps = 1;
   ModList = [1:6];		%List of modulation schemes to use in bits/Hz/sec for coherent QAM
   
   Diversity = 1;			%Number of Receivers used to power combine the signal. This diversity is simulated
   %							by combining multiple data sets. For a diversity of 2, the second data set is normalised 
   %							in power to match the base data set, then the two are added together (in linear).
   %							There are only 10 data sets available and so using a diversity of 2 restrict the number
   %							of users to 5. A diversity of 3 only allows 3 users, etc.
   Xaxis = 1;				%1 - Display xaxis as a function of distance. 0 - Display as a function of time
   SNRPlotFlag = 1;		%1 - plot the channel SNR, only works for a single user, 0 - don't plot SNR
   SNRplotRange = [5 25];	%Range for the SNR plot in dB, sets the caxis for the SNR plot
   %rand('seed',12934)
   rand('seed',12234934)
   if length(UserBW)~=Nusers
      error('UserBW must have only Nusers number of elements in it, it does not');
   end
   if Xaxis == 1
      Xlb = 'Distance (m)';
   else
      Xlb = 'Time (sec)';
   end
   
   if ReloadFlag
      %Noise Floor of the Receiver in dBm, normalised to a single carrier.
      NoiseFloor = 10*log10(1.38e-23*CarrierBW*1e6*AntTemp)+30+RxNF;
      %===================================
      % List of the available data files
      %===================================
      DataDirectory = '../fadingmeas/cal_data/';
      DataFiles = {'rm120ceiling_c', 'rm209ceiling_c', 'rm122chair_c', 'rm210ceiling_abovetrack2_c',...
            'rm210chair_c', 'rm210ceiling_c', 'rm207ceiling_c', 'rm206chair_c', ...
            'rm205chair_c', 'rm205ceiling_c'};
      if Diversity*Nusers>length(DataFiles)
         error('Diversity too large, not enough data files')
      end
      
      %Pick random data sets for each user, make sure it is unique
      DataFileIndex = randperm(length(DataFiles));	
      DataFileIndex = DataFileIndex(1:Nusers*Diversity);
      DataFileIndex = 8;
      %================================================
      % Load the data into a cell array
      %================================================
      ChanData = {};
      ChanFreq = {};
      ChanDist = {};
      MaxTime = [];
      MinFreq = [];
      MaxFreq = [];
      if PowControlFlag
         TxPow = zeros(1,Nusers);
      end
      if Diversity>1
         UserVelocity2 = reshape(repmat(UserVelocity,Diversity,1),1,Nusers*Diversity);
      else
         UserVelocity2 = UserVelocity;
      end
      
      %======================================================
      %		Load all the file separately
      %======================================================
      %This allows the maximum length of the simulation to be established, and the frequency range.
      %This allows compensation for combining data sets of different sizes.
      for k = 1:Nusers*Diversity
         Filename = [DataDirectory DataFiles{DataFileIndex(k)}];
         load(Filename);
         if (length(Ntaps) == 1)&(Ntaps == 1)
            ChanData{k} = Data;
            ChanFreq{k} = F;
            ChanDist{k} = X-min(X);
         else
            %Filter the measured Data
            ChanData{k} = 10*log10(filter2(gauss2d(Ntaps,FiltBlur),10.^(Data/10)));
            %Trim the Data back to remove end effects of the filter
            ChanData{k} = ChanData{k}(ceil(Ntaps(2)/2)+2:end,ceil(Ntaps(1)/2)+2:end);
            ChanFreq{k} = F(ceil(Ntaps(2)/2)+2:end);
            ChanDist{k} = X(ceil(Ntaps(1)/2)+2:end);
            ChanDist{k} = ChanDist{k} - min(ChanDist{k});	%Make sure we start at distance zero
         end   
         %Find the maximum simulation time for each user based on the data set and the
         %velocity of the user
         MaxTime(k) = (min(max(ChanDist{k}),NumDataSamps)/100)/UserVelocity2(k);	
         MinFreq(k) = min(ChanFreq{k});
         MaxFreq(k) = max(ChanFreq{k});
         if PowControlFlag
            %Use the mean pathloss over the entire data set to set the power control. This
            %is non causal but very simple. It is fair to say that the average power of each
            %user only changes relatively slowly, and so this could have been estimated
            %reasonably accurately using previous data in reality.
            TxPow(k) = min(-10*log10(mean(mean(10.^(Data/10))))+NoiseFloor+10*log10(Ncarriers/Nusers)+...
               SNRReq,MaxPower);
            if AllocScheme==3
               TxPow(k) = TxPow(k)+10*log10(Nusers);	%The users only transmit 1/Nusers of the time 
               %													so boost the power to make the average the same
            end
         end
      end
      
      %=====================================================
      %			Combine data sets for DIVERSITY
      %=====================================================
      if Diversity>1
         for k = 1:Diversity:Nusers*Diversity
            DataIndex = ((k-1)/Diversity+1);
            
            if Pathloss(DataIndex)>0
               MeanPow = 10.^(-Pathloss/10);
               ChanData2{DataIndex} = zeros(size(ChanData{k}));	%Select base data set and make linear scale
               StartInd = 0;
            else
               ChanData2{DataIndex} = 10.^(ChanData{k}/10);	%Select base data set and make linear scale
               MeanPow = mean(mean(ChanData2{DataIndex})); 	%Find the mean power of the base data set
               StartInd = 1;
            end
            
            for d = StartInd:Diversity-1
               LinData = 10.^(ChanData{k+d}/10);			%Get diversity data set, and make linear
               MP = mean(mean(LinData));						%Find the mean power of the diversity set
               sz = min(size(LinData),size(ChanData2{DataIndex}));
               %Combine the data over the area of the smaller data set. The freq and time range scaling
               %will ensure that the simulation does not go out of this set.
               ChanData2{DataIndex}(1:sz(1),1:sz(2)) = ChanData2{DataIndex}(1:sz(1),1:sz(2))+...
                  LinData(1:sz(1),1:sz(2))/MP*MeanPow;
            end
            ChanFreq2{DataIndex} = ChanFreq{k};
            ChanDist2{DataIndex} = ChanDist{k};
            ChanData2{DataIndex} = 10*log10(ChanData2{DataIndex});
            
         end
         
         ChanData = ChanData2;
         ChanFreq = ChanFreq2;
         ChanDist = ChanDist2;
         
         clear ChanData2 LinData ChanFreq2 ChanDist2
         TxPow = TxPow(1:Diversity:end);
      else
         
         for k = 1:Nusers
            if length(Pathloss) == Nusers
               PL = Pathloss(k);
            else
               if length(Pathloss) == 1
                  PL = Pathloss;
               else
                  error('Pathloss length is not 1 or Nusers');
               end
            end
            
            if Pathloss>0
               LinData = 10.^(ChanData{k}/10);			%Get diversity data set, and make linear
               MP = mean(mean(LinData));						%Find the mean power of the diversity set
               MeanPow = 10.^(-Pathloss/10);
               ChanData{k} = ChanData{k}-10*log10(MP)+10*log10(MeanPow);	%Select base data set and make linear scale
            end               
         end
      end
      
      
      %TxPow
      %====================================
      %	Find the symbol locations
      %====================================
      SimTime = min(MaxTime);							%Find the length of the simulation in seconds
      MaxUserDist = UserVelocity.*SimTime;		%This is the distance travel by the user in the simulation (metres)
      Nsymbols = floor(SimTime.*SymbolRate)-TrackingDelay+1;		%Number of symbols in the simulation
      SymbStepDist = UserVelocity/SymbolRate;
      MaxUserDist = (Nsymbols-1).*SymbStepDist+TrackingDelay*SymbStepDist;		%Recalculate to take into account rounding
      SymbDist = zeros(Nsymbols,Nusers);			%Initialise distance array, one user per column
      Offset = TrackingDelay.*SymbStepDist;
      for k = 1:Nusers
         SymbDist(:,k) = (Offset(k):SymbStepDist(k):MaxUserDist(k))';
      end
      
      %====================================
      %	Find the measurement locations
      %====================================
      
      %NsimSteps = floor(SimTime.*TrackingRate);	%Number of steps in the simulation
      %MaxUserDist = UserVelocity.*SimTime;		%This is the distance travel by the user in the simulation (metres)
      %UserDist = zeros(NsimSteps,Nusers);			%Initialise distance array, one users per column
      %for k = 1:Nusers
      %   UserDist(:,k) = linspace(0,MaxUserDist(k),NsimSteps)';
      %end
      UserDist = SymbDist(1:SymbolPerTrack:end,:);
      UserDist = UserDist-repmat(Offset,size(UserDist,1),1);
      NsimSteps = size(UserDist,1);
      %================================================
      % Find the range of the measurement frequencies
      %================================================
      %All transmissions should use a common sets of frequencies, thus we should pick a range
      %to fit all simulation data, and should have a bandwidth of SystemBW
      FreqLow = max(MinFreq);
      FreqHigh = FreqLow+SystemBW;
      if FreqHigh > min(MaxFreq)
         %One of the data sets in too narrow in bandwidth to support this system bandwidth
         %so give an error message
         error(['Data set to narrow in bandwidth to support system BW of ' num2str(SystemBW) ' MHz']);
      end
      %Calculate the frequencies of the carriers
      SystemFreq = linspace(FreqLow,FreqHigh,Ncarriers)';
      %=============================================================
      % Resample the data at the chosen frequencies and distances
      %=============================================================
      MeasData = {};		%Data at the adaptive user allocation measurement locations
      for k = 1:Nusers
         %Interpolate the data, convert it to linear first, then back to log scale
         MeasData{k} = 10*log10(max(interp2(ChanDist{k}/100,ChanFreq{k},10.^(ChanData{k}/10),UserDist(:,k)',...
            SystemFreq,'linear*'),0));
         disp(['Interpolating to find Characterisation ' num2str(k) ' of ' num2str(Nusers)])
         drawnow
      end
      
      %=============================================================
      % Resample the data at the chosen frequencies and distances
      %=============================================================
      SymbData = {};		%Data at the adaptive user allocation measurement locations
      for k = 1:Nusers
         if k == 9
            disp('Test Point')
         end
         
         %Interpolate the data, convert it to linear first, then back to log scale
         SymbData{k} = 10*log10(max(interp2(ChanDist{k}/100,ChanFreq{k},10.^(ChanData{k}/10),SymbDist(:,k)',...
            SystemFreq,'linear*'),0))';
         disp(['Interpolating to find Symbol Power ' num2str(k) ' of ' num2str(Nusers)])
         drawnow
      end
   end
   clear ChanData		%Free up some memory
   %===========================================
   %  Allocate users to carriers
   %===========================================
   UserColours = {[1 0 0],[0 1 0],[0 0 1],[0.9 0.9 0],[0 0.9 0.9],[0.9 0 0.9],[0.5 0.5 0.5],...
         [0.7 0.2 0.2],[0.2 0.7 0.2],[0.2 0.2 0.7]};
   SNR = zeros(SymbolPerTrack*(NsimSteps-1),Nusers);
   SNRMap = zeros(SymbolPerTrack*(NsimSteps-1),Ncarriers);
   SNRActMap = SNRMap;
   UserBWsymb = SNR;
   if FreqImagFlag
      FreqImagR = ones(size(SNR,1),Ncarriers);
      FreqImagG = ones(size(SNR,1),Ncarriers);
      FreqImagB = ones(size(SNR,1),Ncarriers);
   end
   %EstimationError = zeros(NsimSteps,Nusers);
   UserBW2 = zeros(NsimSteps-1,Nusers);
   if ~AdaptModFlag
      %Fixed Modulation scheme so make the ModMap a constant 
      ModMap = ones(size(SNRMap))*ModScheme;
   else
      ModMap = SNRMap;  
   end
   
   UserDataRate  = zeros(SymbolPerTrack*(NsimSteps-1),Nusers);
   for k = 1:NsimSteps-1
      if rem(k,50) == 0
         disp(['Calculating Simulation Step: ' num2str(k) ' of ' num2str(NsimSteps)])
      end
      %Initally find the SNR for a single group of carriers
      MeasSNR = zeros(Ncarriers/CarrGroup,Nusers);
      for l = 1:Nusers
         MeasSNR(:,l) = (MeasData{l}((round(CarrGroup/2)):CarrGroup:end,k))+TxPow(l)-NoiseFloor-10*log10(CarrGroup);	
         %Calculate the received SNR in dB
      end
      if k == 8
         disp('pause');
      end
      switch AllocScheme
      case 0
         if Nusers == 1
            UserBW2(k) = UserBW;
            %MeasSNR(:) = (MeasData{1}((round(CarrGroup/2)):CarrGroup:end,k))+TxPow(1)-NoiseFloor-10*log10(UserBW);
            MeasSNR(:) = (MeasData{1}((round(CarrGroup/2)):CarrGroup:end,k))+TxPow(1)-NoiseFloor-10*log10(UserBW2(k));
            I = min(length(find(MeasSNR<Thresh)),UserBW-1); %Number of carrier groups which were below the SNR threshold
            %We reduce the userBW
            
            for r = 1:NtrialsUser1
               if 1
                  [Y,ik] = sort(MeasSNR);
                  MeanPeakSNR = min(Y(end-ik+1:end));
                  I = max(UserBW-max(round(UserBW2(k)*(10.^((MeanPeakSNR-Thresh)/10))),1),0);
               else
                  
                  
                  SNRrise = 10*log10((UserBW2(k)/(UserBW-I)));
                  
                  I2 = min(length(find(MeasSNR+SNRrise<(Thresh))),UserBW-1);	%Number of carrier groups which were below the SNR threshold
                  I = round((I2+I*4)/5);
               end
               UserBW2(k) = UserBW-I*CarrGroup;	%This reduces BW will mean that more power is allocated to the good
               %carriers so check again
               MeasSNR(:) = (MeasData{1}((round(CarrGroup/2)):CarrGroup:end,k))+TxPow(1)-NoiseFloor-10*log10(UserBW2(k));
               I = min(length(find(MeasSNR<Thresh)),UserBW-1);
            end
            [Y,I] = sort(MeasSNR);
            BestMinAlloc = {};
            BestMinAlloc{1} = I(end-UserBW2(k)+1:end)';
            %BestMinAlloc = MeanAlloc(MeasSNR,UserBW/CarrGroup);
         else
            %======================================
            %        Adaptive Modulation
            %======================================
            %   BestMinAlloc = MaxMinAlloc(MeasSNR,UserBW/CarrGroup,Ntrials);
            BestMinAlloc = MeanAlloc(MeasSNR,UserBW/CarrGroup);
            %BestMinAlloc = RandAlloc(size(MeasSNR,1),UserBW/CarrGroup);
            
            %for ck = 1:Nusers
            %BestMinAlloc{ck} = ((ck-1)*UserBW(ck)+1):(ck*UserBW(ck));
            UserBW2(k,:) = UserBW;%floor(Ncarriers/Nusers); %UserBW;
            for r = 1:Ntrials,
               if (r == 4)&(k==9)
                  disp('pause2')
               end
               
               ReAllocFlag = 0;
               FreeCarriers = 0;
               UserSNR = zeros(1,Nusers);
               for l = 1:Nusers
                  MeasSNR(:,l) = (MeasData{l}((round(CarrGroup/2)):CarrGroup:end,k))+TxPow(l)-NoiseFloor-10*log10(UserBW2(k,l));
                  warning off
                  %If no carriers are allocated make the UserSNR NaN
                  if isempty(BestMinAlloc{l})
                     UserSNR(l) = NaN;
                  else
                     UserSNR(l) = min(MeasSNR(BestMinAlloc{l},l));
                  end
                  
                  warning on
                  if UserSNR(l)<Thresh
                     UserBW3 = floor((UserBW2(k,l)/(10.^((Thresh-UserSNR(l))/10)))/CarrGroup)*CarrGroup;
                     ReAllocFlag = 1;
                     FreeCarriers = FreeCarriers + UserBW2(k,l)-UserBW3;
                     UserBW2(k,l) = UserBW3;
                  end
               end
               if ReAllocFlag
                  I = find(UserSNR>Thresh+Thresh2);
                  [Y2,I2] = sort(UserSNR(I));
                  %Add the free carriers to users which have a SNR above the threshold
                  if ~isempty(Y2)
                     %If there are no users above the threshold than this means that no more carriers
                     %can be used in the system due to power limits
                     
                     %Number of Extra groups of carriers that each User can handle
                     NumGroupHandle = floor(floor(UserBW2(k,I(I2)).*(10.^((Y2-Thresh-Thresh2)/10)-1))/CarrGroup);
                     
                     I3 = find(cumsum(NumGroupHandle*CarrGroup)<FreeCarriers);	%Index of the users which will get more carriers
                     RemainCarrs = FreeCarriers;
                     for k1 = 1:min(length(I3)+1,length(NumGroupHandle))
                        ExtraCarrs = floor(min(NumGroupHandle(k1)*CarrGroup,RemainCarrs)/CarrGroup)*CarrGroup;
                        UserBW2(k,I(I2(k1))) = UserBW2(k,I(I2(k1)))+ ExtraCarrs;
                        RemainCarrs = RemainCarrs-ExtraCarrs;
                     end
                     
                     %Add the free carriers to the user which is just above the threshold
                     %      UserBW2(k,I(I2(1))) = UserBW2(k,I(I2(1)))+FreeCarriers;
                     BestMinAlloc = MeanAlloc(MeasSNR,UserBW2(k,:)/CarrGroup);
                  else        
                     break
                  end
                  %r
               else
                  if r==1
                     BestMinAlloc = MeanAlloc(MeasSNR,UserBW2(k,:)/CarrGroup);
                  end
                  if r>=2
                     break
                  end
                  
               end
            end
         end
      case 1
         %============================================================
         %              Random Carrier Allocation
         %============================================================
         BestMinAlloc = RandAlloc(size(MeasSNR,1),UserBW/CarrGroup);
         UserBW2(k,:) = UserBW;
      case 2
         %============================================================
         %              Fixed Group of Carriers
         %============================================================
         CUBW = [0 cumsum(UserBW/CarrGroup)];
         for ku = 1:Nusers
            BestMinAlloc{ku} = CUBW(ku)+1:CUBW(ku+1);
         end
         UserBW2(k,:) = UserBW;
      case 3
         %============================================================
         %					Time Division Multiplexing
         %============================================================
         BestMinAlloc = cell(1,Nusers);
         Islot = rem(k,Nusers)+1;
         BestMinAlloc{Islot} = 1:Ncarriers;
         UserBW2(k,:) = zeros(1,Nusers);
         UserBW2(k,Islot) = Ncarriers;
      otherwise
         error('Unimplemented User Allocation Scheme')
      end
      %	r
      %   BestMinAlloc;
      %   for k3 = 1:length(BestMinAlloc)
      %      if isempty(BestMinAlloc{k3})
      %         disp('Ran Out of Carriers')
      %      end
      %   end
      
      %end
      
      I = (k-1)*SymbolPerTrack+1:k*SymbolPerTrack;
      Alloc = {};
      
      %Find the SNR thresholds for each modulation scheme, so that the BER is below the
      %threshold (BERThresh)
      SNRThresh = [snrthresh(BERThresh,ModList) Inf];
      
      for l = 1:Nusers
         if (k == 975)&(l==9)
            disp('stop')
         end
         Offset = round(CarrGroup/2);
         %BestMinAlloc{l};
         %Now we need to map these to the delayed symbol data.
         Alloc{l} = reshape(repmat(BestMinAlloc{l}*CarrGroup,CarrGroup,1),1,CarrGroup*size(BestMinAlloc{l},2));
         Alloc{l} = Alloc{l}+repmat(-CarrGroup+1:0,1,size(BestMinAlloc{l},2));
         
         if isempty(Alloc{l})
            %If the user was not allocated any carriers, than the SNR is NaN
            SNR(I,l) = NaN;
         else
            
            %Find the SNR of the channel characterisation. i.e. the SNR of the channel at user allocation
            SNRM = (MeasData{l}((BestMinAlloc{l}-1)*CarrGroup+Offset,k)+TxPow(l)-NoiseFloor-10*log10(UserBW2(k,l)))';	
            
            %ModSNR = repmat(SNRM,1,
            %Find the SNR of the channel for points in between the user allocation, in frequency and time.
            M = (SymbData{l}(I,Alloc{l})')'+TxPow(l)-NoiseFloor-10*log10(UserBW2(k,l));
            
            SNRMrep = reshape(repmat(SNRM,CarrGroup,1),1,length(Alloc{l}));
            if AdaptModFlag
               for m1 = 1:length(SNRThresh)-1
                  Imod = find(((SNRMrep-Margin)>SNRThresh(m1))&((SNRMrep-Margin)<SNRThresh(m1+1)));
                  ModMap(I,Alloc{l}(Imod)) = ModList(m1);
               end
            end
            %ModMap(I,Alloc{l}) = max(min(floor((repmat(SNRMrep,length(I),1)-7-Margin)/3),MaxMod),0);
            SNRMap(I,Alloc{l}) = repmat(SNRMrep,length(I),1);
            SNRActMap(I,Alloc{l}) = M;
            UserDataRate(I,l) = sum(ModMap(I,Alloc{l})'*CarrierBW)';
            SNR(I,l) = mean(M')';
            %plot(M)
            %pause
            %if EstErrFlag
            %   Error = repmat(SNRM,size(M,1),1)-(M);
            %   Etemp = Error(2:end,:);
            %Record all the Estimation Errors, giving no regard for each user
            %plot(sort(Etemp));
            %pause
            %   EstimationError = [EstimationError Etemp(:)'];
            
            %end
         end
         
         UserBWsymb(I,l) = UserBW2(k,l);
         
         if sum(abs(SNR(I,l)) == Inf)
            plot(SymbData{l}(I,BestMinAlloc{l}))
            disp(['SNR of a user is Inf at l:' num2str(l),' k:' num2str(k),', Probably a simulation bug'])         
         end
      end
      if FreqImagFlag
         for l = 1:Nusers
            FreqImagR(I,Alloc{l}) = UserColours{l}(1);
            FreqImagG(I,Alloc{l}) = UserColours{l}(2);
            FreqImagB(I,Alloc{l}) = UserColours{l}(3);
         end
      end
   end
   SymbTime = linspace(0,SimTime,Nsymbols);
   if Xaxis == 1
      SymbTime = SymbTime*VelList(V);	%Convert SymbTime data to distance
   end
   
   MeasTime = linspace(0,SimTime,NsimSteps-1);
   
   if PlotFlag
      figure(1)
      if FreqImagFlag
         sz= size(FreqImagR');
         
         A = zeros(sz(1),sz(2),3);
         A(:,:,1) = FreqImagR';
         A(:,:,2) = FreqImagG';
         A(:,:,3) = FreqImagB';
         image(SymbTime,SystemFreq,A)
      end
      xlabel(Xlb);
      ylabel('Frequency (MHz)');
      set(gca,'ydir','normal');
      setplotstyle
      
      if SavePlotFlag
         savefig(['s0059_freqimag' PostFix],'jpg');
      end
      
      figure(2)
      ST = SymbTime(1:size(SNR,1));
      h = plot(ST,SNR);
      for k = 1:Nusers
         set(h(k),'color',UserColours{k})
      end
      setplotstyle
      ylabel('Mean SNR for Each User (dB)')
      xlabel(Xlb);
      if SavePlotFlag
         savefig(['s0059_SNR' PostFix]);
      end   
      
      figure(3)
      UDR = UserDataRate;
      h = stairs(ST,UDR);
      ylabel('User Data Rate (Mbps)')
      Ind = find(UDR==0);
      QOS = (1-(length(Ind)/length(UDR(:))))*100;
      if AllocScheme == 3
         %Time Division Multiplexing, so take this into account
         QOS = QOS*Nusers;
      end
      for k = 1:Nusers
         set(h(k),'color',UserColours{k})
      end
      
      title(['Percentage Time User Data > 0 Mbps, for all users : ' num2str(QOS,4) '%']);
      xlabel(Xlb);
      setplotstyle
      
      if SavePlotFlag
         savefig(['s0059_userdata' PostFix]);
      end
      
      figure(4)
      %   SysData = sum((UserBWsymb.*max(min(floor((SNR-7-Margin)/3),10),0)*CarrierBW)')
      if Nusers>1
      	SysData = num2str(mean(sum(UserDataRate')),4);
	   else
      	SysData = num2str(mean(UserDataRate'),4);
   	end
      if Nusers>1
         h = stairs(ST,sum(UserDataRate'));
         title(['Average System Throughput: ' num2str(SysData,4) ' Mbps']);
      else
         h = stairs(ST,UserDataRate');
         title(['Average System Throughput: ' num2str(SysData,4) ' Mbps']);
      end
      
      xlabel(Xlb)
      ylabel('Total System Data Rate (Mbps)');
      
      setplotstyle
      if SavePlotFlag
         savefig(['s0059_sysdata' PostFix]);
      end
      figure(5)
      h = plot(ST,UserBWsymb*CarrierBW);
      xlabel(Xlb)
      ylabel('User BW (MHz)');
      for k = 1:Nusers
         set(h(k),'color',UserColours{k})
      end
      setplotstyle
      if SavePlotFlag
         savefig(['s0059_userbw' PostFix]);
      end
      figure(6)
      G = hot(max(ModList)).^0.9;
      G(1,:) = [0 0 0.4];
      pcolor(SymbTime(1:size(ModMap,1)),SystemFreq,ModMap'); shading flat
      colormap(G);
      xlabel(Xlb)
      ylabel('Frequency (MHz)')
      caxis([0 max(ModList)]);
      hc = colorbar('vert');
      h_ylb = get(hc,'ylabel');
      set(h_ylb,'string','Modulation (bits/Hz/sec)');
      setplotstyle
      if SavePlotFlag
         savefig(['s0059_modmap' PostFix]);
      end
      if EstErrorFlag
         EstimationError = SNRActMap-SNRMap;
         figure(7)
         pcolor(SymbTime(1:size(EstimationError,1)),SystemFreq,EstimationError'); shading flat
         b = bone;
         c = copper;
			colormap([b(1:end/2,:); c(end/2+1:end,:)])
         %colormap(jet);
         caxis(EstCaxis)
         xlabel(Xlb)
         ylabel('Frequency (MHz)')
         hc = colorbar('vert');
         h_ylb = get(hc,'ylabel');
         set(h_ylb,'string','Estimation Error (dB)');
         setplotstyle
         if SavePlotFlag
            savefig(['s0059_EstErr' PostFix]);
         end
         [Y,I] = sort(EstimationError(:));
         
         EstError = zeros(size(DistribList));
         for k = 1:length(DistribList)
            EstError(k) = Y(round(DistribList(k)*length(Y)));
         end
         EstList(V,:) = EstError;
         EstError
         if length(VelList)>1
            save s0059_temp EstList VelList TrackingRate
         end
      end
      figure(8)
   end
   BER = snr2ber(SNRActMap-Degradation,ModMap);
   if PlotFlag
      pcolor(SymbTime(1:size(BER,1)),SystemFreq,log10(BER')); shading flat
      c = jet;
      c(1,:) = [1 1 1];
      colormap(c);
      caxis(BERrange);
      hc = colorbar('vert');
      h_ylb = get(hc,'ylabel');
      set(h_ylb,'string','Log 10 of BER');
      xlabel(Xlb)
      ylabel('Frequency (MHz)')
   end
   
   Err = (ModMap.*BER);		%Number of errors
   Ind = find(isnan(Err));
   Err(Ind) = zeros(size(Ind));
   OverallBER = sum(sum(Err))/sum(sum(ModMap));
   
   if length(VelList)>1
      BERList(V) = OverallBER;
   end
   if PlotFlag 
      
      
      titlestr = ['BER: ' num2str(OverallBER,3)];
      if ~AdaptModFlag
         titlestr = [titlestr ', Mod Eff: ' num2str(ModScheme) 'bits/Hz/s'];
      else
         titlestr = [titlestr ', Mod Eff: ' num2str(str2num(SysData)/SystemBW,4) 'bits/Hz/s'];
      end
      
      if PowControlFlag
         titlestr = [titlestr ', Mean SNR: ' num2str(SNRReq) 'dB'];
      end
      
      title(titlestr)
      setplotstyle(2,1.1)
      b = bone;
      colormap(b(end:-1:1,:).^0.5);
      
      
      if SavePlotFlag
         savefig(['s0059_BER' PostFix],'jpg');
      end
      if SNRPlotFlag&(Nusers==1)
   	   figure(9)
         pcolor(SymbTime(1:size(SNRMap,1)),SystemFreq',SNRMap'); shading flat
         colormap(jet)
         caxis(SNRplotRange);
		   hc = colorbar('vert');
      	h_ylb = get(hc,'ylabel');
      	set(h_ylb,'string','SNR (dB)');
	      xlabel(Xlb)
   	   ylabel('Frequency (MHz)')
         setplotstyle(2,1.1)
         set(gcf,'position',[4 27 1024 601]);
         colormap(bone)
         if SavePlotFlag
         	savefig(['s0059_SNR' PostFix],'jpg');
      	end
		end
   end
   disp(['Overall Simulation BER : ' num2str(OverallBER)])
   if Nusers>1
      SysData = num2str(mean(sum(UserDataRate')),4);
   else
      SysData = num2str(mean(UserDataRate'),4);
   end
   disp(['Average System Throughput: ' num2str(SysData) ' Mbps'])
end
toc