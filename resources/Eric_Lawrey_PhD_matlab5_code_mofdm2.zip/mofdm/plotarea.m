function h = plotarea(X,Y,C,lowlimit,linewidth,EdgeC)
%PLOTAREA plots a area fill below the plot
%This function is nearly the same as area, except that
%the colour of the area fill can be easily set.
%plotarea(X,Y)
%
%h = plotarea(X,Y,C,lowlimit,linewidth,EdgeC)
%C 		 - colour of the fill [R, G, B], 0<=R,G,B<=1
%				The default is Gray [0.5 0.5 0.5]
%lowlimit - area between lowlimit and Y is filled
%				the default is lowlimit = 0;
%linewidth - width of the line around the area fill
%				The default is 1.0
%EdgeC	-	Edge Color of the fill, default is black

if nargin < 6
   EdgeC = [0 0 0];
end

if nargin < 5
   linewidth = 1;
end
if nargin < 4
   lowlimit = 0;
end
if nargin < 3
   C = [0.5 0.5 0.5];
end

%Make X and Y row vectors
if size(X,1)>size(X,2)
   X = X';
end

if size(Y,1)>size(Y,2)
   Y = Y';
end
%([X(1) X X(length(X))])
%([lowlimit Y lowlimit])
ha = fill([X(1) X X(length(X))],[lowlimit Y lowlimit],C,'linewidth',linewidth,'edgecolor',EdgeC);

if nargout == 1
   h = ha
end