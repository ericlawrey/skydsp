function BERinterp = snr2ber(SNR,ModEff)
%SNR2BER Find the BER for a particular SNR for coherent modulation
% BER = snr2ber(SNR,ModEff)
% This assumes perfect timing, and synchronisation. These results are
% from previously simulated results stored in s0041_coh_qam. 
%
% The BER is only valid down to approximately 1e-6. The simulation is 
% valid for EBNR down to -6dB, thus the lower limit for the SNR depends 
% on the modulation scheme. For 8 bits/Hz this limit is 3dB. Below this 
% limit linear extrapolation is used. This appears to be reasonably good 
% to -6dB. The error rate is capped at a BER of 0.5
%
% BER below the simulation threshold (about 1e-6) will return a NaN.
%
% ModEff is the modulation spectral efficiency in bit/s/Hz. 
%  ModEff  Modulation
%    1       BPSK
%    2       QPSK
%    3       8QAM
%    4       16QAM
%    5       32QAM
%       etc
% ModEff can vary from 1 to 12. The bit mapping for even modulation schemes
% i.e. ModEff is even, use gray coding to minimise the BER. Odd order modulation
% schemes are a cross shape. Use DATA2IQMAP(ModEff) to see the IQ diagram of the
% modulation scheme used in the simulation to obtain the BER.
%
% If ModEff is a matrix than SNR should be a matrix of the same size
%
% See DATA2IQMAP, IQ2DATA, SNRTHRESH
%
% Copyright Eric Lawrey June 2001

% 5/6/01 Improved the commenting for the function and added the cross reference for
% DATA2IQMAP, and fixed it up so that the IQ plotting in DATA2IQMAP matches the
% ModEff numbers.


load s0041_coh_qam
ModBitsHz = log2(Nconstellation(ModNumberList));

if length(ModEff(:))>1
   if size(ModEff)~=size(SNR)
      error('ModEff must be the same size as SNR, if they are both vectors or matrices')
   end
   ModList = unique(ModEff(:));
   BERinterp = zeros(size(SNR));
   %Use a recursive alogorithm to minimise code duplication
   for k = 1:length(ModList)
      DataIndex = find(ModEff==ModList(k));
      BERinterp(DataIndex) = snr2ber(SNR(DataIndex),ModList(k));
   end
else
   ModIndex = find(ModEff==ModBitsHz);
   if isempty(ModIndex)
      if ModEff == 0
         BERinterp = NaN*ones(size(SNR));
         return
      else    
         error(['No Modulation found to match given Modulation Efficiency (' num2str(ModEff) ')']);
      end
   end
   if length(ModIndex)>2
      error('Duplicate Modulation scheme found (This shouldn''t happen)');
   end
   
   EBNR = SNR-10*log10(ModBitsHz(ModIndex));
   BER = BERall(:,ModIndex);
   I = find(BER>0);
   EBNRI = EBNRdB(I);
   BERinterp = 10.^(interp1(EBNRI,log10(BER(I)),EBNR,'linear'));
   IlowEBNR = find(EBNR<min(EBNRI));
   if length(IlowEBNR)>0
      P = polyfit(EBNRI(1:2),BER(1:2)',1);
      BERinterp(IlowEBNR) = min(polyval(P,EBNR(IlowEBNR)),0.5);
   end
end

