function SNR = SNRThresh(BER,Mod)
%SNRTHRESH Finds the minimum SNR that will keep the BER below a given threshold
% SNR = SNRThresh(BERThresh,Mod)
% BERThresh is the BER threshold.
%
% Mod is the modulation scheme in Bits/Hz/Sec for coherent QAM modulation. The
% valid range is from 1 (BPSK) to 12 (4096QAM).
% Use DATA2IQMAP(Mod) to see the IQ plot for the modulation scheme.
%
% SNR is the Signal to Noise Ratio in dB required to ensure that the
% BER is less than BERThresh.
%
% See also SNR2BER, DATA2IQMAP, IQ2DATA
%
% Copyright Eric Lawrey June 2001

%Load Simulation file.
if ~exist('s0041_coh_qam.mat','file')
   error('SNRTHRESH needs the s0041_coh_qam.mat file for calculations');
end

load s0041_coh_qam
ModBitsHz = log2(Nconstellation(ModNumberList));
ModIndex = zeros(size(Mod));
for k = 1:length(Mod)
ModI = find(Mod(k)==ModBitsHz);
if isempty(ModIndex)
   error(['No Modulation found to match given Modulation Efficiency (' num2str(ModEff) ')']);
end
ModIndex(k) = ModI;
end

NumMods = length(ModIndex);
SNR = zeros(length(BER),NumMods);
for k = 1:NumMods
   warning off
   Ber = log10(BERall(:,ModIndex(k)));
   ind = find(Ber>-7);		%Trim the BER to ensure that the waveform is monotonic
   Ber2 = Ber(ind);
   SNRdB = EBNRdB(ind)+10*log10(Mod(k));
   SNR(:,k) = interp1(Ber2,SNRdB,log10(BER),'linear')';
   warning on
end


