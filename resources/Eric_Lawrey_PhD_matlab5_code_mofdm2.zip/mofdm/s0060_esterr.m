%This script plots the estimation error verses velocity, for a 10 user
%system, with no power control, mean user allocation scheme, 70MHz bandwidth
%and a tracking rate of 500Hz. Results were derived from s0059_mofdm
%For 120 carriers.
load s0059_group		%Estimation Error for Grouped carriers
%load s0059_backup3	%Estimation Error for Adaptive Allocation
%order = 1;			%Apply polyfit to the data of this order.
%p = zeros(size(EstList,2),order+1);
%SmoothEstErr = zeros(size(EstList));
%M = 10;
%for k = 1:size(EstList,2)
%   p(k,:) = polyfit(VelList(1:M),EstList((1:M),k)',order);
%   SmoothEstErr(:,k) = polyval(p(k,:),VelList)';
%end
%h_s = plot(VelList,SmoothEstErr);
%hold on
%h_e = plot(VelList,EstList,'o');
%hold off
h_s = plot(VelList,EstList);
legendstr = {'90%','98%','99.5%','99.9%'};
markerlist = {'none','o','x','^','d','s'};
colourlist = {'r',[0 0.8 0],'b','k','m','c','y'};
for k = 1:length(h_s)
   set(h_s(k),'marker',markerlist{k},'color',colourlist{k});
end
title(['Tracking rate: ' num2str(TrackingRate) ' Hz, Mean Carrier Freq: 1.005 GHz'])
setplotstyle(1.5,1,15)
grid on
set(gca,'xtick',0:1:20,'ytick',0:1:11)
xlabel('Velocity of Transmitter (m/s)');
ylabel('Tracking Error (dB)');
legend(h_s,legendstr,2)
ylim([0 11.5]);
savefig('s0060_EstErrVel_group')



