function alloc = RandAlloc(NSysCarrier,NUserCarrier)
s = [0 cumsum(NUserCarrier)];
r = randperm(NSysCarrier);
alloc = cell(1,length(NUserCarrier));
for a = 1:length(NUserCarrier)
   alloc{a} = sort(r(s(a)+1:s(a+1)));
end
   