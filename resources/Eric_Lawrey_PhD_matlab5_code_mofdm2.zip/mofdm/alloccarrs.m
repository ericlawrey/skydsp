function car_index = alloccarrs(FreqData,Ncarr,HopType,OptAlgor, PrevAlloc,GroupSize)
%This function returns the indexes of the carriers allocated
%car_index = alloccarrs(FreqData,Ncarr,HopType,OptAlgor,PrevAlloc,GroupSize)
%FreqData: 	This is the rx power for each carrier
%Ncarr:		Number of carriers to be allocated to the user
%HopType:	1 - Fixed Single Group Frequency
%				For fixed frequency are allocated in the middle of the 
%				band initally
%				2 - Comb of carriers
%				3 - Single Group Adaptive Frequency Hopping
%				4 - Multi-group Adaptive Frequency Hopping
%				Carriers are broken into groups corresponding to the GroupSize
%				if Ncarr is not a multiple of the GroupSize, the last Group
%				will be Trimmed in length
%OptAlgor	Carrier allocation optimisation
%				1 - Maximise the mean power, this assumes the input is in dB
%				2 - Maximise the mean power, this assumes the input is linear power
%				3 - Maximise the worst case carrier power
%				4 - Maximise the maximum carrier power
%				Default = 1
%PrevAlloc:	index of carriers previously allocated. Default is []
%				NOTE : This is not currently implemented
%GroupSize: Size of the carrier groups to use for multi-group hopping
%				Default value is 1
if nargin <6
   GroupSize = 1;
end
if nargin < 5
   PrevAlloc = [];
end
if nargin < 4
   OptAlgor = 1
end


bins = length(FreqData);

switch HopType
case 1
   %Fixed Frequency Single Group of carriers
   indmn = round(bins/2)-floor((Ncarr-1)/2);
   indmx = round(bins/2)+floor((Ncarr-1)/2);
   car_index = indmn:indmx;
case 2
   %Fixed Frequency Comb carriers
   step = floor(bins/Ncarr);
   car_index = 1:step:bins;
   car_index = car_index(1:Ncarr);
case 3
   %Single Group Adaptive Frequency Hopping
   
   %Perform a sweep across the avaliable band and measure
   %how good each band is, based on what optimisation to use
   GoodNess = zeros(size(1:(bins-Ncarr)));
   for s = 1:(bins-Ncarr)
      Fbins = FreqData(s:(s+Ncarr));
      switch OptAlgor
      case 1
         %Measure the mean power (dB input data)
         GoodNess(s) = mean(10.^Fbins/10);
      case 2
         %Measure the mean power (linear input data)
         GoodNess(s) = mean(Fbins);
      case 3
         %Maximise worst carrier power
         GoodNess(s) = min(Fbins);
      case 4
         %Maximise the best carrier power
         GoodNess(s) = max(Fbins);
      end
   end
   %Now pick the band that was the best
   [Y,I] = max(GoodNess);
   car_index = I:(I+Ncarr-1);
case 4
   %Multigroup Adaptive Frequency Hopping
   
   
   %Break the Avaliable carriers into groups, then
   %find the best group
   
   %Trim FreqData so that its length is a multiple of the
   %GroupSize
   binstrim = floor(bins/GroupSize)*GroupSize;
   
   if GroupSize > 1
	   %Make FreqData into a matrix, each column is a group of carriers
	   FreqData2 = reshape(FreqData(1:binstrim),GroupSize,binstrim/GroupSize);
	   %Apply the same transform to an index vector of all the carriers
	   %This makes it easy to work backwards to the indexes, after we have picked which 
	   %Groups we want
	   CarrIndex = 1:binstrim;
	   CarrIndex2 = reshape(CarrIndex(1:binstrim),GroupSize,binstrim/GroupSize);
	   
	   %Apply the goodness measure test to each group, i.e. apply to each column 
   	%of FreqData2
	
	   switch OptAlgor
	   case 1
	      %Measure the mean power (dB input data)
	      GoodNess = mean(10.^FreqData2/10);
	   case 2
	      %Measure the mean power (linear input data)
	      GoodNess = mean(FreqData2);
	   case 3
	      %Maximise worst carrier power
	      GoodNess = min(FreqData2);
	   case 4
	      %Maximise the best carrier power
	      GoodNess = max(FreqData2);
	   end	
   else
      GoodNess = FreqData;
      CarrIndex2 = 1:binstrim;
   end
   
   Ngroups = Ncarr/GroupSize;		%Calculate the number of groups we need
   %Now find the best groups by sorting them
   [Y,I] = sort(GoodNess);
   
   %The best ones will be at the end because the sort is in ascending order
   Ibest = I((length(I)-ceil(Ngroups)+1):length(I));

   
   %Now lets work back to find the indexes for FreqData corresponding to those
   %Groups
   CarrBest1 = CarrIndex2(:,Ibest); %This is a matrix, each column is a group of carriers
   car_index2 =reshape(CarrBest1,1,length(CarrBest1(:)));
   car_index = car_index2(1:Ncarr);	%Trim the number of carriers to match the number required
end
