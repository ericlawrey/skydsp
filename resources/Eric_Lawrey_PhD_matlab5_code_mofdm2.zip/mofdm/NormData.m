function DataNorm = NormData(Data)
%Normalises the input matrix, this is for radio channel measurments

Fmean = mean(Data');
Fstep = 1:length(Fmean);

%Remove any straight line trend in the frequency domain
P = polyfit(Fstep,Fmean,1);
Grid = repmat(Fstep,size(Data,2),1)';
Offset = polyval([P(1) 0],Grid);
DataTrend = Data-Offset;

%Normalise the power
MeanPow = mean(mean(10.^(DataTrend/10)));
MeanPowdB = 10*log10(MeanPow);
DataNorm = DataTrend - MeanPowdB; 