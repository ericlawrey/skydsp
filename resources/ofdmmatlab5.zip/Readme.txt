This simulation script set allows for an OFDM transmission to be 
simulated. Imagetx.m generates the OFDM signal, saving it as a 
windows WAV file. This allows the OFDM signal to be played out a sound
card and recorded back. Imagerx.m decodes the WAV to extract the 
data.

settings.m contains all the common settings to specify all the 
simulation parameters such as FFT size, number of carriers,
input data source file, input and output WAV files, etc.

See settings.m for more details.

Note: The both the receiver and transmitter must have a copy of the 
input data file, as this is used for calculating the exact number
of data words in the transmission. This is done automatically using 
rddatatx.

The scripts should work as extracted. Just run imagetx.m to generate the
OFDM signal. Then run imagerx.m to decode the signal. The initial settings
transmit a wave file 'Corrs.wav'. The decoded OFDM data ('Out.wav') can be
compared with the original data by listening to the two wave files.

You also try changing the DataType from 1-4. I have test each of these.

This script set has been upgraded to run in matlab 5.3, however there
may still be quite a few bugs. It has also been tested in matlab 5.1
Eric Lawrey April 1999.
eng-epl@jcu.edu.au
James Cook University
Electrical and Computer Engineering Department
Australia