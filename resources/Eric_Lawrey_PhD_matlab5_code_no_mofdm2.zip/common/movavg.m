function mavg = movavg(x,N)
%MOVAVG returns the moving average of the input
% mavg = movavg(x,N)
% x - input to be processed
% N - length of the moving average
% mavg is returned shorter than x by N
%
% Copyright Eric Lawrey 16/1/01
c = cumsum(x);
mavg = c((N+1):length(x))-c(1:(length(x)-N));
