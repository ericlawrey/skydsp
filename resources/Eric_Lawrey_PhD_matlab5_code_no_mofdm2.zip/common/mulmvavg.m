function mavg = mulmvavg(x,N,M,P)
%MULMVAVG Multiple moving average filter
% mavg = mulmvavg(x,M,S,P)
% This function performs a multiple moving average filter,
% equivalent to filtering with tap coefficients:
% B = [ones(1,M) zeros(1,S) ... repeated P times]
% This function was designed to be used for performing
% a multiple symbol moving average for time synchronisation
% This function out performs FILTER for moving 
% averages which are large (typically > 20-30 taps)
% The output of mulmvavg is shorter than the input by
% M+(S+M)*(P-1) samples. If the input is padded with
% zeros by this amount, the output of mulmvavg will be
% exactly the same as using an FIR filter, where the delay
% line values are initially zero.
%
% Number of floating point operations is approximately
% (2*P+1)*length(x)
%
% See also TMSYNCDS
%
% Copyright Eric Lawrey 22/1/1

%Modifications
% 25/7/2001 by Eric Lawrey
% MULMVAVG was failing for column vector of data, and so added automatic
% rotation at start and end
% Also changed the labeling in the introduction to match the variable 
% names used in tmsyncds.
% 29/7/2001 By Eric Lawrey
% Had a bug in the rotation of the matrix at the start. It left RotFlag uninitialised
% if not rotation was needed.

if (size(x,2)==1)&((size(x,1)>1))
   RotFlag = 1;
   x = x.';
else
   RotFlag = 0;
end


if (P == 1)
   %For a single moving average section use simplest (fastest)
   %method
   c = cumsum(x);
   mavg = c((N+1):length(x))-c(1:(length(x)-N));
else
   c = cumsum(x);
   mavg = zeros(1,length(c)-(N+(M+N)*(P-1)));
   for k = 1:P
      ed = N+(M+N)*(P-1)-(N*k+M*(k-1)); 
      m1 = c((N*(k)+M*(k-1)+1):length(x)-ed)-c(N*(k-1)+M*(k-1)+1:(length(x)-N-ed));
      mavg = mavg + m1;
   end
end
if RotFlag
   mavg = mavg.';
end

