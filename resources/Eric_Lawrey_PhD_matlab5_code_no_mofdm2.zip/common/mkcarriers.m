function Carriers = mkcarriers(NumCarr1,IFFTsize,RealComplex,NoDC)
%MKCARRIERS returns a list of OFDM carriers which correspond to the centre frequency
%Carriers = mkcarriers(NumCarr,IFFTsize,RealComplex)
% Choses a list of carriers to use. Will be centred upper side for even
% number of carriers.
% NumCarr = number of carriers
%   The spacing between the carriers can be specified by making NumCarr a vector.
%   NumCarr = [Number of Carriers, Spacing between carriers, Offset];
%   Offset shifts the carriers to the right (more positive). Default is 0.
%	 For example mkcarriers([4 3],16,'complex'), will generate [11, 14, 1, 4]
%   which is 4 carriers, spaced 3 apart for a 16 point IFFT complex output
% RealComplex of 'low', generates carriers from DC for real vector, Offset
%   can be used shift the frequency
%
% IFFTsize = size of the IFFTsize used in the OFDM modulation
% RealComplex = 'real', use real modulation, thus the centre frequency
%  corresponds to Fs/4
%  'complex', use modulation, thus the centre frequency is DC
%
% Carriers = mkcarriers(NumCarr,IFFTsize,RealComplex, NoDC)
% NoDC - set this to 1 if there is to be no DC component. 0 - include DC. (default)
% This is useful for practical complex signals which often don't use
% the DC component. 
% For example for Hiperlan2, which has no DC component.
% carriers = mkcarriers(52,64,'complex',1);
%
% Not that when the NoDC is used in conjuction with spacing of the carriers and offseting 
% the carriers, the offset is disturbed by the requirement of no DC component. 
%
% See OFDMMOD
%
% Copyright Eric Lawrey 2000

% Revision History
% 25/10/01
% Added the NoDC option to allow accurate modelling of Hiperlan/2
% 20th March 2001
% Added the option to specify the spacing between the carriers. This is
% useful for windowed OFDM.

if nargin < 3
   error('Mkcarriers requires a minimum of three inputs: NumCarr1,IFFTsize,RealComplex')
end

if nargin < 4
   NoDC = 0;	%Default is to include the DC component
end

if length(NumCarr1)>1
   NumCarr = NumCarr1(1);
   NumCarrReq = NumCarr1(1);
   Spacing = NumCarr1(2);
   if length(NumCarr1) < 3
      Offset = 0;
   else
      Offset = NumCarr1(3);
   end
   
else
   NumCarr = NumCarr1;
   NumCarrReq = NumCarr1;
   Spacing = 1;
   Offset = 0;
end

%Use a recursive call to find out if we need to increase the number of subcarriers
%to compensate for the removal of the DC component
if NoDC == 1
	Carriers = mkcarriers(NumCarr1,IFFTsize,RealComplex,0);
	ind = find(Carriers==1);
	if ~isempty(ind)
   	NumCarr = NumCarr+1;
	end
end

switch lower(RealComplex)
case 'real'
   if NumCarr*Spacing > IFFTsize/2
      error(['Can''t have NumCarr (' num2str(NumCarr) ') * Spacing (', ...
            num2str(Spacing) ') > IFFTsize (', num2str(IFFTsize)...
            ')/2 for a real modulation']);
   end   
   Carriers = (1:Spacing:(NumCarr*Spacing))-floor(NumCarr*Spacing/2)+ceil(IFFTsize/4)+Offset;   
case 'complex'
   %Positive frequencies are from 1->IFFTsize/2, negative frequencies are from
   %IFFTsize-> IFFTsize/2+1
   if NumCarr*Spacing > IFFTsize
      error(['Can''t have NumCarr (' num2str(NumCarr) ') * Spacing (', ...
            num2str(Spacing) ') > IFFTsize (', num2str(IFFTsize)...
            ') for complex modulation']);
   end  
   CarrierTable = [(ceil(IFFTsize/2)+1):IFFTsize 1:(ceil(IFFTsize/2))];
   CarrierIndex = (1:Spacing:(NumCarr*Spacing))+round(IFFTsize/2)-floor(NumCarr*Spacing/2)+Offset;
   Carriers = CarrierTable(CarrierIndex);
case 'low'
   Carriers = (1:Spacing:(NumCarr*Spacing))+1+Offset;
otherwise
   error(['Unknown RealComplex type : ' RealComplex ', must be ''real'' or ''complex'''])
end

%Remove the DC component
if NoDC 
   ind = find(Carriers==1);
   Carriers(ind) = [];
   %If the spacing between the subcarriers is greater than 1, than increasing the number of
   %subcarriers results in DC component at all, so we need to remove this extra subcarrier
   %Take the righthand side of the vector as the previous carrier allocations are already lop sided
   %to the left or negative carriers, so cut these out first.
   Carriers = Carriers(end-NumCarrReq+1:end);
end
