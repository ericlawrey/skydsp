function [Y, OBO] = clipdist(X,OutBackoffdB,PeakAmp)
%CLIPDIST models clipping distortion
% Y = clipdist(X,OutBackoffdB)
% This function models clipping distortion. It clips the input signal
% until the peak to average power ratio of the signal is OutBackoffdB. 
% This is achieved using an iterative solution. The peak of the signal is
% then scale to have a peak amplitude of 1.
% X - input signal,
%     If X is a matrix the average is still taken over the entire matrix
% OutBackoffdB - Output power back off in dB. 
%
% Y = clipdist(X,OutBackoffdB,PeakAmp)
% PeakAmp - The signal is scaled to a peak amplitude of PeakAmp
%
% If OutBackoffdB is an array [OutBackoffdB Tolerance], then the signal
% will be clipped to an accuracy of Tolerance (in dB) of the OutBackoff 
% given. The default tolerance is 0.01dB
%
% A third parameter can be added to the OutBackoffdB array:
% [OutBackoffdB Tolerance MaxTrails], which species the maximum number of
% trials to run. The default is 10.
%
% [Y, OBO] = clipdist(X,....)
% OBO is the actual Output power backoff of the output signal, in dB
%
% Copyright Eric Lawrey April 2001

%28/7/2001 By Eric Lawrey
% If the crest factor of input signal is greater than the required OutBackoffdB
% than don't clip. Previously clipdist would simply run through all trials then
% warn that the error was greater than the tolerance. The signal peak amplitude
% is still scaled

if nargin < 3
   PeakAmp = 1;
end
%OBOflag = 1;
%if OBOflag==0
%	AvgPow = mean(mean((abs(X).^2)));			%average signal power
%	OutBackoff = 10.^(OutBackoffdB/10);	%Linear Output power backoff
%	PeakAmpClip = sqrt(AvgPow.*OutBackoff);	%Peak amplitude to clip to
%	Y = clip(X,PeakAmpClip);
%	AmpScale = PeakAmpClip/PeakAmp;
%	Y = Y./AmpScale;
%else
if isstr(X)
   %=======================================================
   %		Generate Look up table to help speed up 
   %		the guess process
   %=======================================================
   IFFTsize = 256;
   Nsymbols = 10;
   Ncarriers = 128;
   GuardPeriod = 0;
   RealComplex = 'complex';
   fast_mode = 0;
   OutBackoffdBlist = [-15:1:11];
   MeasOBO = zeros(1,length(OutBackoffdBlist));
   for k = 1:length(OutBackoffdBlist)
      OBO = OutBackoffdBlist(k);
      %Create random QAM data with a peak amplitude of 1.
      IQ = (rand(Ncarriers,Nsymbol)*2-1+i*(rand(Ncarriers,Nsymbol)*2-1))/sqrt(2);
      IQ = IQ/mean(mean(abs(IQ)));	%Make the mean carrier power = 1;
      carriers = mkcarriers(Ncarriers,IFFTsize,RealComplex);
      outsymbol = ofdmmod(IQ, carriers, IFFTsize, GuardPeriod, ...
         RealComplex, fast_mode);
      OutBackoff = 10^(OBO/10);
      AvgPow = mean(mean((abs(outsymbol).^2)));			%average signal power
      PeakAmpClip = sqrt(AvgPow.*OutBackoff);	%Peak amplitude to clip to
      %Clip the signal to the guess
      Y = clip(outsymbol,PeakAmpClip);	
      %Measure the OBO, which is the peak to average power ratio
      MeasOBO(k) = (max(max(abs(Y))).^2)/mean((mean(abs(Y).^2)));
      disp([num2str(k) ' of ' num2str(length(OutBackoffdBlist))])
   end
   plot(OutBackoffdBlist,10*log10(MeasOBO))
   xlabel('Input power clipping (dB)')
   ylabel('Output Power Back off (dB)')
   IBO = OutBackoffdBlist;
   OBO = 10*log10(MeasOBO);
   save('IBO_OBO.mat','IBO','OBO');
else
   %Check the CF of the input signal
   CF = 10*log10((max(abs(X)).^2)/mean(mean(abs(X).^2)));
   %If the input CF is less than the required OBO, no clipping is
   %required
   %CF
   %OutBackoffdB
   if CF >= OutBackoffdB
      
      if ~exist('IBO_OBO.mat','file')
         error('Lookup table for input backoff verse OBO doesn''t exist, run clipdist(''setup'')')
      end
      load IBO_OBO
      if length(OutBackoffdB) > 2
         Ntrials = OutBackoffdB(3)
      else
         Ntrials = 15;			%Maximum number of trials to run
      end
      if length(OutBackoffdB) > 1
         thresholddB = OutBackoffdB(2);
         OutBackoffdB = OutBackoffdB(1);
      else
         thresholddB = 0.02;
      end
      
      
      AvgPow = mean(mean((abs(X).^2)));			%average signal power
      OutBackoff = 10.^(OutBackoffdB/10);	%Linear Output power backoff
      error = 0;
      IBOguessdB = interp1(OBO,IBO,OutBackoffdB,'linear');
      if isnan(IBOguessdB)
         if OutBackoffdB>=max(OBO)
            OutBackoffGuess = 10.^(max(IBO)/10);
         else
            OutBackoffGuess = 10.^(min(IBO)/10);
         end
      else  
         OutBackoffGuess = 10.^(IBOguessdB/10);
      end
      %OutBackoffGuess = OutBackoff;
      ErrPow = max((6-OutBackoffdB),1);
      %thresholddB = 0.01;
      
      
      for k = 1:Ntrials
         PeakAmpClip = sqrt(AvgPow.*OutBackoffGuess);	%Peak amplitude to clip to
         %Clip the signal to the guess
         Y = clip(X,PeakAmpClip);	
         %Measure the OBO, which is the peak to average power ratio
         OBO = (max(abs(Y)).^2)/mean((mean(abs(Y).^2)));
         %Measure how many times too big the OBO is to where it should be
         error = OBO/OutBackoff;
         %Calculate a new guess and test its accuracy
         OutBackoffGuess = OutBackoffGuess/(error.^ErrPow);
         errordB = abs(OutBackoffdB-10*log10(OBO));
         if errordB < thresholddB
            break
         end
         %     10*log10(OBO)
      end
      if errordB > thresholddB
         warning(['Did not converge to error tolerance, Error : ' num2str(errordB) ' dB'])
      end
      OBO = 10*log10(OBO);
   else
%      disp('Bypass')
      Y = X;
      PeakAmpClip = max(abs(X));
   end
   
   AmpScale = PeakAmpClip/PeakAmp;
   Y = Y./AmpScale;
   
   %k
end

