function [IQdata, CF]= genref(NumCarr,RefScheme)
%GENREF	Generates pilot symbol for OFDM modulation
% IQdata = genref(NumCarr,RefScheme)
% This function calculates a pilot symbol for use with Coherent
% modulation, or as a phase reference symbol for differential
% modulation. Several types of reference symbol can be generated.
% IQdata = genref(NumCarr,RefScheme)
% NumCarr - Number of carriers in the symbol
% RefScheme 
%   0 - S. Narahashi and T. Nojima phasing scheme
%       Ph = (k-1)(k-2)*pi/(N-1)
%		  S. Narahashi, T. Nojima, "New phasing scheme of N-multiple
%       carriers for reducing peak-to-average power ratio", Electronic
%       Letters, Vol. 30, No. 17, pp. 1382-1383, Aug. 1994
%   1 - Use the low crest factor phasing scheme developed
%       using genetic algorithms. This algorithm only allows
%       for carrier numbers which have been simulated and stored
%       in s0019_low_CF_DMT_phase_table.mat.
%   2 - Use random phase angles
%   3 - Spectral Flatness Optimised using simulations
%       Phase = 3.6315*X.^2
%   4 - Newmanns phasing scheme
%       Ph = (pi*(k-1)^2)/N
%       S. Boyd, "Multitone signals with low crest factor", IEEE Trans.
%       Circuits Syst., Vol. CAS-33, pp. 1018-1022, Oct. 1986
%   5 - Shapiro-Rudin Phase scheme
%       #Tones, Phase Sequence
%         2      1, 1
%         4      1, 1, 1,-1
%         8      1, 1, 1,-1, 1, 1,-1, 1
%         16     1, 1, 1,-1, 1, 1,-1, 1, 1, 1, 1,-1,-1,-1, 1,-1
%			etc
%       where -1 maps to 0 radians and +1 corresponds to pi radians.
%       Non-power of two number of tones truncates the sequence.
%
% IQdata - Reference Symbol carrier vector. This is a column
%   vector with each row corresponding to the IQ vector for
%   each carrier
%
% If genref is called with no output the reference symbol time
% waveform is plotted and the spectrogram provided the number of
% carriers is > 31.
%
% [IQdata, CF]= genref(NumCarr,RefScheme)
% Genref calculates the Crest Factor (CF) of the reference symbol
% Accurate to about +- 0.02dB.
%
% See also OFDMMOD, MKCARRIERS
%
% Copyright Eric Lawrey March 2001

%Modifications:
% 3/7/01
% Added Shapiro-Rudin Phasing scheme
switch RefScheme
case 0
   X = 1:NumCarr;
   %S. Narahashi and T. Nojima phasing scheme
   Phase = ((X-1).*(X-2)./(NumCarr-1)*pi);    %2^(wordsize-1));
   RefString = 'S.N., T.N.';
case 1
   if ~exist('s0019_low_CF_DMT_phase_table.mat','file')
      error('Can''t find phase table file: s0019_low_CF_DMT_phase_table.mat');
   end
   load s0019_low_CF_DMT_phase_table
   ind = find(CarrList==NumCarr);
   if isempty(ind)
      s = sprintf('%3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d\n',CarrList);
      disp('Possible values for GA phasing scheme')
      disp(s)
      error(['Number of carriers selected (' num2str(NumCarr) ...
            ') is not in phase table']);
   end
   Phase = Phases{ind}';
   RefString = 'GA minimised';
case 2
   %Random Phase angle
   Phase = rand(1,NumCarr)*2*pi;
   RefString = 'Random';
case 3
   %Time Spectral Flatness Optimised
   X = 1:NumCarr;
   Phase = 3.6315*X.^2;	%0.425
   RefString = 'Spec Flat';
case 4
   X = 1:NumCarr;
   %Newmanns phasing scheme
   Phase = pi*(X-1).^2/NumCarr;
   RefString = 'Newmanns';
case 5
   %Shapiro-Rudin phasing scheme
   S = [ 1 1 ];
   Ndouble = nextpow2(NumCarr)-1;
   for k = 1:Ndouble
      S = [S S(1:end/2) -S(end/2+1:end)];
   end
   Nlength = length(S);
   Over = (Nlength-NumCarr);
   Seq = S((1:NumCarr)+round(Over/2));
   %Seq = S(1:NumCarr);
   Phase = (Seq>0)*pi;
   RefString = 'Shapiro-Rudin';
otherwise
   error(['Unsupported Reference Scheme (' num2str(RefScheme) ')'])
end
Phase = rem(Phase,2*pi);
Mag = ones(size(Phase));

[x,y] = pol2cart(Phase,Mag);
if nargout > 0
   if nargout > 1
      %Calculate the Crest Factor of the reference symbol generated
      RealComplex = 'complex';
      ifft_size = 2^(nextpow2(NumCarr+1)+4);
      carriers = mkcarriers(NumCarr,ifft_size,RealComplex);
      data_vector = x+i*y;
      outsymbol = ofdmmod(data_vector,carriers, ifft_size, 0, RealComplex);
      CF = calcpapr(outsymbol,1);
   end
   IQdata = (x+i*y)';
else
   RealComplex = 'complex';
   ifft_size = 2^(nextpow2(NumCarr+1)+2);
   carriers = mkcarriers(NumCarr,ifft_size,'complex');
   data_vector = x+i*y;
   outsymbol = ofdmmod(data_vector,carriers, ifft_size, 0, RealComplex);

   figure(1)
   clf
   plot(abs(outsymbol));
   xlabel('Time (Samples)')
   ylabel('Envelope Amplitude')
   axis tight;
   title(['Reference Symbol, ', num2str(NumCarr) ,' Carriers, ' RefString]);
   setplotstyle
   if NumCarr>31
      figure(2)
      RealComplex = 'real';
   	ifft_size = 2^(nextpow2(NumCarr+1)+2);
	   carriers = mkcarriers(NumCarr,ifft_size,'real');
      outsymbol = ofdmmod(data_vector,carriers, ifft_size, 0, RealComplex);
      N = 8;		%Frequency Interpolation
      M = 16;		%Time Interpolation
      SubSections = 8;
      I = ifft_size/SubSections;%round(sqrt(ifft_size))*2;
      [B,F,T] = specgram(outsymbol,I*N,ifft_size,kaiser2(I,'width',2),round(I*(1-1/M)));
      %T = linspace(0,1,size(B,2));
      imagesc(T,F,20*log10(abs(B)));
      %plot(abs(B(round(end/2),:)));%abs(B(round(end/2)-50:50:round(end/2)+50,:)'))
      caxis([-50 -0])
      colorbar('vert')
      setplotstyle
      xlabel('Time (Normalised to Symbol Length)')
      ylabel('Frequency (Norm. to Carrier Spacing)')
   end
end
