function Y = intlogspace(d1,d2,N)
%INTLOGSPACE
% Y = intlogspace(d1,d2,N)
% This function generates a log space similar to logspace, but
% with integer outputs and only unique numbers.
%
% d1, d2 are the limits over which to make the log list. Unlike
% logspace with requires d1 and d2 to be a power of ten,
% intlogspace just requires the upper and lower limits.
%
% N is the approximate number of points to generate. Because
% only unique integer numbers are kept, if N is large the number
% of output values will be significantly lower.
% Y = intlogspace(1,100,15)
% Y = [1, 2, 3, 4, 5, 7, 10, 14, 19, 27, 37, 52, 72, 100]
%
% Copyright Eric Lawrey 1/1/1

D1 = log10(d1);
D2 = log10(d2);
Y1 = round(logspace(D1,D2,N));
Y = unique(Y1);
