function Y = upsamp(X1,R,Quality,BackOff);
%UPSAMP - interpolates data using low pass filtering
% Successively up samples the input signal.
% Y = upsamp(X,R,Quality,BackOff);
% X - input signal to be interpolated. If X is a matrix each column
%   of the matrix is filtered separately.
% Y - output of the interpolation. If X is a vector Y is of size X'
% R - integer interoplation rate
% Quality - Scales the number of taps used in the interpolation
%      Default for Quality is 1.
% BackOff - This sets the frequency cut off for the lowpass interpolator
%   and is the fraction of the orginal nyquist bandwidth before interpolation.
%   Quality results in the steepness of the interpolating filter and thus
%   also determines the maximum allowable frequency cut off to prevent
%   Aliasing.
%   Setting BackOff to >=1 will result in some aliasing components in the
%   interpolated output.
%   Typical values range from 0.85-0.98. If BackOff is not specified
%   a default value of 0.95 is used.
%
% upsamp('test',R,Quality,BackOff) 
% This performs a self test showing the effects of rate conversion on a 
% tone and on white noise. This can be used to estimate the aliasing 
% performance of the conversion. This also shows the processing time:
% upsamp('test',8,1.5) 
% Average Processing Time (100000) points : 4.855sec
%
% Copyright (C) April 2001, Eric Lawrey

%Version 1.1, 17th March 2001
%Changed upsamp so that it can process matrices, i.e. each column
%is filter separately. This was achieved by vecotrising the code.
%
%5th April 2001
%Fixed a bug which occured when processing input matrices, with one
%result per column. If the number of columns was greater than the
%number of rows upsamp would crash. This was due to using a length
%command instead a size.
%
%5th June 2001
%upsamp outputs arrays rotated so that if the input is a row vector the
%output is a column vector. This is really an error, but I am not changing
%it as it will probably break functions using upsamp. However I found that
%the output is not transposed when the resample rate is 1. This is inconsistent
%so I may the output transposed for an interpolation rate of 1.
if nargin < 4
    BackOff = 0.95;
end   
if isstr(X1)
   if nargin < 3
      error('You must specify the Quality factor and R for testing')
   end
   %Qual = R;
   N = 100e3;
   a = sin((0:N)*2*pi*0.4);
   tic
   t = upsamp(a,R,Quality,BackOff);
   t1 = toc;
   M = 4096;
   figure(1)
   psd(t,M,2,lawrey5(M));
   
   a = randn(1,N);
   tic
   t = upsamp(a,R,Quality,BackOff);
   t2 = toc;
   disp(['Average Processing Time (' num2str(N) ') points : ' num2str(mean([t1 t2])) 'sec'])
   M = 1024;
   figure(2)
   psd(t,M,2,lawrey5(M));
   break
end

if R == 1
   Y = X1';
else
   if (size(X1,2)>1)&(size(X1,1) == 1)
      X1 = X1';	%If X is a vector make X1 a column vector 
   end
   
   %Set Default values for Quality and Backoff
   if nargin < 3
      Quality = 1;
   end
   %Find the factors of R
   N = min(R*32,size(X1,1)-1);
   
   %Input is a matrix so filter each column separately
   
   %Make the signal cyclic. This is designed to work for OFDM symbols which are cyclic
   %This is to remove transients from the start and end of the signal
   t = [X1((size(X1,1)-N+1):size(X1,1),:); X1; X1(1:N,:)];
   %perform the interpolation
   interpsig = interpS(t,R,Quality,BackOff);
   %Trim back to size. This stops transients at the start and end.
   Y = interpsig(N*R+1:(size(interpsig,1)-N*R),:);
   
end

%General interoplation
function Y = interpS(X,R,Quality,BackOff)
fact = factor(R);

for k = length(fact):-1:1;
   MaxTap = (floor(size(X,1)/3)*fact(k)-1);
   %   Ntap = min(max(fact(k)*12,30),MaxTap);
   Ntap = min(round(fact(k)*4*Quality),MaxTap);
   
   %If we are interpolating the first up sampling
   %use a sharp filter, and thus use more taps
   if k == length(fact)
      %Quality gets effectively squared for setting the taps for the first stage
      Ntap = min(round(Ntap*4*Quality),MaxTap);
      window = hanning(Ntap+1); %blackh4(Ntap+1);
   else
      window = hanning(Ntap+1);
      
   end
   %Ntap
   %window = blackh4(Ntap+1);
   %BackOff = 0.96;		%Percentage of original nyquist band to keep
   B = fir1(Ntap,(1/fact(k))*BackOff,window);
   YZ = zeros(size(X,1)*fact(k),size(X,2));
   YZ(1:fact(k):size(YZ,1),:) = X;
   
   Y = filtfilt(B,1,YZ)*fact(k);
   X = Y;
end

