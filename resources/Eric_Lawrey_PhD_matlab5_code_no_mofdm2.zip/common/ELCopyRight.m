%This script adds a hard coded copyright tag something similar to
%�ELJul01 to the current plot.
tag = [char(169) 'EL' datestr(datenum(date),12)];
t = settag(tag);
set(t,'fontsize',10);	%This makes the tag text go outside the bound 
%                      of the plot
settag                 %Re-position the tag