function B = gauss2D(N,s)
%GUASS2D returns a guassian 2D filter
%B = gauss2D(N,s)
%	N size of the filter (returns an N x N matrix)
%  if N is a vector N = [M1 M2] than the filter will
%  be M1 x M2 in size.
%	s standard deviation, sets how wide the filter is
%  if s is a vector s = [s1 s2] than make the standard
%  deviation different is each dimension
%
%Copyright Eric Lawrey April 2001

%27.12.00
%Fixed up so that guass2D would give the correct size filter
if length(N)>1
   M1 = N(1);
   M2 = N(2);
else
   M1 = N;
   M2 = N;
end

if length(s)>1
   s1 = s(1);
   s2 = s(2);
else
   s1 = s;
   s2 = s;
end

[x,y] = meshgrid(linspace(-M1/2/s1,M1/2/s1,M1),linspace(-M2/2/s2,M2/2/s2,M2));
r = sqrt(x.^2+y.^2);
B1 = exp(-(r.^2)/(2*1.^2));
B = B1/sum(sum(B1));