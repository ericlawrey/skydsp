function o = tmsyncds(x,N,M,SyncType,P,S)
%TMSYNCDS finds duplicate half symbols within a waveform
% Calculated the mean squared error between signals
% which are spaced N sampled apart in the input waveform
%
% o = tmsyncds(x,N,M,SyncType)
% x - Waveform to process (can be real or complex)
% N - length of one duplicate segment, samples between 
%     duplicate (width of correlator time window)
% M - length of the moving average filter. Normally this is
%     the same length as N. If M not specified, M=N
% SyncType - Specifies the type of detector to use
%     0 - Use Correlation
%     1 - Use Difference (This doesn't perform very well)
%
% o = tmsyncds(x,N,M,SyncType,P,S)
% P - number of symbols to perform the averaging over (default = 1)
% S - Number of samples between frames (default = N), don't
%     include the samples in the duplicate. For example
%     If we have a duplicate symbol at start of each frame of
%     length 128 samples (i.e. 64 sample each half). If the
%     GuardPeriod is 32 samples and the total number of symbols per
%     frame is 10, than S should be (128+32)*10-64
%
% tmsyncds('help') displays a graphic showing the details of the
% synchroniser
%
% See also MULMVAVG
%
% Copyright Eric Lawrey 17/1/1
if isstr(x)
   H = findobj('tag','diagram');
   if isempty(H)
      [A,M] = imread('tsync.tif');
      figure
      image(A);
      colormap(M);
      axis off
      set(gca,'units','n','position',[0 0 1 1]);
      set(gcf,'units','pixels','position',[30 50 size(A,2) size(A,1)],'menubar',...
         'none','tag','diagram','name','Diagram of Time Sync Algorithm');
      
      figure(gcf)
   else
      figure(H)
   end
   
   %  help tmsyncds
else
   
   if nargin < 6
      S = N;
   end
   
   if nargin < 4
      SyncType = 0;
   end
   if nargin < 5
      P = 1;
   end
   
   if nargin < 3
      M = N;
   end
   
   S1 = x(1:end-N);
   S2 = x(N+1:end);
   %o = abs(movavg(S2-S1,M));
   %err = (abs(S2-S1)).^2;
   switch SyncType
   case 0
      err = S1.*conj(S2);
   case 1
      err = (abs(S2-S1)).^2;
   end
   %a = ones(1,64);
   %a = 1;
   %plot(filter(a,1,err))
   %pause
   %o = movavg(err,M);
   o = mulmvavg(err,M,S,P);
   %o = abs(movavg(err,M));
   %o = S1.*conj(S2);
end

%find
%o = o2(M+1:end);