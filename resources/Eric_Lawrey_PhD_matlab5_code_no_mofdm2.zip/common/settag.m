function h = settag(String)
%SETTAG Add copyright tag to plot
% settag(String)
% This function adds a copyright string (String) to the bottom right
% corner of the current plot. This should be called last after setting
% the plot axis and using setplotstyle.
%
% If settag is called with no input it will reposition a tag that is
% already on the plot. This can be used to change the fontsize, or any
% property of the tag, eg:
% t = settag(tag);
% set(t,'fontsize',15);	%This makes the tag text go outside the bound 
% %                      of the plot
% settag                 %Re-position the tag
% 
% h = settag(String)
% If an output is specified the handle to the text is returned
%
% For a tag which has the copyright symbol, a name and the month and
% year use something similar to this
% tag = [char(169) 'EL' datestr(datenum(date),12)];
% settag(tag)
%
% This will add text similar to �ELJul01 to the plot.
%
% See also SETPLOTSYLE
%
% Copyright Eric Lawrey 24/7/01

%Modifications
%25/7/2001 by Eric Lawrey
%Improved the positioning of the tag for log plots.
LogFlag = strcmp(get(gca,'yscale'),'log');
if nargin == 0
   ht = findobj(gca, 'tag','settag');
   if ~isempty(ht)
      Xmax = max(xlim);
      yl = ylim;
      Ymin = yl(1);
      set(ht,'tag','settag')
      
   end
else
   Xmax = max(xlim);
   yl = ylim;
   Ymin = yl(1); %(yl(2)-yl(1))/100+yl(1);
   ht = text(Xmax,Ymin,String);
   set(ht,'tag','settag')   
end
e = get(ht,'extent');
X = Xmax-e(3);
if LogFlag
   %10.^(3/(1000/32.11))
   Y = Ymin*10^((log10(yl(2))-log10(yl(1)))/(yl(2)/e(4)));
else
   Y = Ymin+e(4)/2;
end

set(ht,'position',[X,Y,0]);
if nargout > 0
   h = ht;
end
