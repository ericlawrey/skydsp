function plotm(h,M,markersize,markerline,markerlist,colourlist)
%PLOTM overlay the current plot with markers, with plot data sub sampled
% This function is useful for putting markers on plots which have a lot
% of data points. The markers are not placed on every data point.
% plotm(h,M)
% Overlay markers on plot h (handle to the plot), with marker spaced out
% by M samples of the data in the plot.
%
% If M is a vector of then the markers will be placed at the specified
% x locations, where x is a fraction of the plot width, i.e. M = [0.1 0.2 0.6];
% will place a marker 10%, 30%, and 60% along the X axis. Since the
% markers always map to data points of the plot the marker will be
% placed on the data point closes to the requested marker location.
%
% plotm(h,M,markersize,markerline,markerlist,colourlist)
% markersize is the size of the markers in points (default = 16)
% markerline is the line width of the markers (default = 2)
% markerlist is a cell array of the marker strings (default is
%   {'none', 'o', '^','s','x','.','+','*','>','<','p','h'}
% colourlist is the list of colours to make the plot lines and
%   markers. The default is 
%   {'k','r','g','b','m','c','y','k','r','g','b','m'}
%
% Example:
% h = plot(cumsum(randn(40,4)));
% legend(h,'1','2','3','4')
% setplotstyle
% plotm(h,5)
%
% This type of marker overlay appears to sometimes have a problem with 
% saveas command, which is used in savefig to save the plots as emf 
% format. It appears to screw up the legend.
% Save the diagram as TIF format if this is a problem.
%
% See also SETPLOTSTYLE
%

% Copyright Eric Lawrey 10th April 2001

% 5/7/2001
% plotm was changing log plots to linear, so I fixed this up.
% 15/10/2001
% The legend was not being updated when plotm was called with M = 1, or with the
% default of M=1. This is because the legend command wasn't being called. This was
% fixed.
% 3/11/2001
% Added the option of specifying the location of the markers as a fraction of the
% xaxis.
if nargin < 5
   markerlist = { 'none', 'o', '^','s','x','p','+','*','>','<','.','h'};
end
if nargin < 6
   colourlist = { 'k','r',[0 0.8 0],'b',[0.8 0 0.8],[0 0.8 0.8],[0.8 0.8 0],'k','r','g','b','m'};
end
if nargin < 3
   markersize = 16;
end
if nargin < 4
   markerline = 2;
end

for k = 1:length(h)
   set(h(k),'marker',markerlist{k},'color',colourlist{k},'linewidth',...
      markerline,'markersize',markersize)
end
legend		%Refresh the legend to the new marker shapes and colours
if length(M)>1
   plotflag = 1;
else
   if M > 1
      plotflag = 1;
   else
      plotflag = 0;
   end
end

if plotflag
   set(h,'marker','none')
   hold on
   if strcmp(get(gca,'xscale'),'linear')
      LinFlag = 1;
   else
      LinFlag = 0;
   end
   
   for k = 1:length(h)
      y = get(h(k),'ydata');
      x = get(h(k),'xdata');
      if length(M)==1
      xm = x(1:M:end);
      ym = y(1:M:end);
      else
      ind = round(length(x)*M);
      xm = x(ind);
      ym = y(ind);
      end
      plot(xm,ym,'marker',markerlist{k},'color',colourlist{k},'linestyle','none',...
         'linewidth',markerline,'markersize',markersize)
   end
   hold off
   if ~LinFlag
      set(gca,'xscale','log');
   end
   
end