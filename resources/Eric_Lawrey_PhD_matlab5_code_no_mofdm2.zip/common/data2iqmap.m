function [ModTableOut,BitHzOut, GrayMapOut] = data2iqmap(ModType,DiffMapFlag,FontScale)
%DATA2IQMAP Generates a table of IQ points suitable for modulation
% [ModTable,BitHz] = data2iqmap(ModType)
% This generates a table of IQ points that can be used to map data to modulated
% IQ points. The output IQ map table is in complex number form.
% The following modulation schemes are supported:
%  'BPSK', Binary phase shift keying
%  'QPSK', Quadrature phase shift keying
%  'S8QAM', Square mapping of 8QAM
%  '8QAM', Optimal IQ mapping
%  '16QAM', '32QAM', '64QAM', '128QAM', '256QAM','512QAM','1024QAM',
%  '2048QAM','4096QAM', '8PSK', '16PSK', '32PSK', '64PSK','128PSK', '256PSK'
%
% Example code:
% ModMap=data2iqmap('QPSK');			%Generate IQ vector table
% Data = floor((rand(1,16))*4);		%Generate random data 0 - 3, each word is 2 bits
% IQ = ModMap(Data+1);					%Select the IQ vector for each data word
%
% [ModTableOut,BitHzOut, GrayMap] = data2iqmap(ModType,DiffMapFlag)
% All the modulation schemes, except for non-square QAM modulation uses Gray mapping
% on the data to help minimise the error rate. The GrayMap used can be obtained
% with a third output parameter. Gray mapping is not used for differential modulation.
% For differential PSK the IQ table is a linear phase map.
%
% If no output is used DATA2IQMAP plots the IQ plot instead of generating the output 
% table. i.e. DATA2IQMAP('32QAM') will generate a plot of 32QAM 
%
% DATA2IQMAP(ModType,DiffFlag,FontScale)
% FontScale is used to scale the IQ plots generated. This was added for generating
% IQ plots for a seminar. FontScale = 1, normal size
%
% See also IQ2DATA for the reverse mapping of data, see SNR2BER
%
% Copyright Eric Lawrey March 2001

% 22/3/01
% Fixed up a problem with the gray code mapping in the PSK modulation. Also
% improved the IQ vector diagram plotting/
%
% 5/6/01
% Add the option of specifying ModType as a number instead of a name. This is to match up
% with the SNR2BER function, so that the IQ map for each modulation scheme can be
% easily displayed.

if nargin < 2
   DiffMapFlag = 0;
end

%Generate lookup tables to convert from the data to the Complex spectral components
PSK = 0;

if ~isstr(ModType)
   %If the modulation was specificied as a number (in bits/Hz) rather than a name
   %assume QAM modulation and convert the ModType number to the corresponding name
	ModList = {'bpsk','qpsk','8qam','16qam','32qam','64qam','128qam','256qam','512qam',...
         '1024qam','2048qam','4096qam'};   
   ModType = ModList{ModType};
end

switch upper(ModType)
case 'BPSK'
   %BPSK
	ModMag = [ 1 1 ];
   ModPh = [ 0 pi ];
   GrayMap = [0 1];
   BitHz = 1;
   cart_or_pol = 0;	%Constellation defined using polar coordinates
case 'QPSK'
	%QPSK
	ModMag = ones(1,4);
   ModPh = [0 pi/2 pi 3/2*pi]; %[0 pi/2 3*pi/2 pi];
   %ModPh = [ 5/4*pi 7/4*pi 3/4*pi pi/4]; %[0 pi/2 pi 3/2*pi]; %[ 5/4*pi 7/4*pi 3/4*pi pi/4];
   GrayMap = [0 1 3 2]; %[0 1 2 3]; %   
   BitHz = 2;
   cart_or_pol = 0;	%Constellation defined using polar coordinates
case 'S8QAM'
   %Square mapping 8QAM
   a = sqrt(1/2);
   X = [a, a, 0, -a, -a, -a, 0, a];
   Y = [0, a, a, a, 0, -a, -a, -a];
   GrayMap = [0 1 3 2 6 7 5 4];
   BitHz = 3;
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
case '8QAM'
   %Optimal mapping for 8QAM
   %Proakis J., "Digital Communications", 3rd Edition, McGraw-Hill, 1995, pg. 279
   a1 = sqrt(2);
   a2 = 1+sqrt(3);
   ModMag = [a1, a1, a1, a1, a2, a2, a2, a2];
   ModPh = [-pi/4, pi/4, -(3/4)*pi, 3/4*pi, 0, pi/2, -pi/2, pi];
   GrayMap = 0:7;		%Gray mapping is already used in the phase/amp mappping
   cart_or_pol = 0;	%Constellation defined using polar coordinates
   BitHz = 3;
case '16QAM'
   [X1,Y1] =meshgrid(-3:2:3,-3:2:3);
   X = reshape(X1',1,16);
   Y = reshape(Y1',1,16);
   GrayMap = [0 1 3 2 4 5 7 6 12 13 15 14 8 9 11 10];
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 4;
case '32QAM'
   X = [-3:2:3 -5:2:5 -5:2:5 -5:2:5 -5:2:5 -3:2:3];
   Y = [-5*ones(1,4) -3*ones(1,6) -1*ones(1,6) ones(1,6) 3*ones(1,6) 5*ones(1,4)];
   GrayMap = 0:31;	%The optimal mapping for this modulation scheme is unknown
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 5;
case '64QAM'
   [X1,Y1] =meshgrid(-7:2:7,-7:2:7);
   X = reshape(X1',1,64);
   Y = reshape(Y1',1,64);
   a = [0 1 3 2 6 7 5 4];
   GrayMap = [];
   for l = 1:8, GrayMap = [GrayMap a+a(l)*8]; end
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 6;
case '128QAM'
   [X1,Y1] = meshgrid(-7:2:7,-11:2:-9);
   [X2,Y2] = meshgrid(-11:2:11, -7:2:7);
   [X3,Y3] = meshgrid(-7:2:7, 9:2:11);
   X = [ reshape(X1',1,16) reshape(X2',1,96) reshape(X3',1,16)];
   Y = [ reshape(Y1',1,16) reshape(Y2',1,96) reshape(Y3',1,16)];
   GrayMap = 0:127;	%The optimal mapping for this modulation scheme is unknown
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 7;
case '256QAM'
   [X1,Y1] =meshgrid(-15:2:15,-15:2:15);
   X = reshape(X1',1,256);
   Y = reshape(Y1',1,256);
   a = [0 1 3 2 6 7 5 4 12 13 15 14 10 11 9 8];
   GrayMap = [];
   for l = 1:16, GrayMap = [GrayMap a+a(l)*16]; end
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 8;
case '512QAM'
   [X1,Y1] = meshgrid(-15:2:15,-23:2:-17);
   [X2,Y2] = meshgrid(-23:2:23, -15:2:15);
   [X3,Y3] = meshgrid(-15:2:15, 17:2:23);
   X = [ reshape(X1',1,length(X1(:))) reshape(X2',1,length(X2(:))) reshape(X3',1,length(X3(:)))];
   Y = [ reshape(Y1',1,length(Y1(:))) reshape(Y2',1,length(Y2(:))) reshape(Y3',1,length(Y3(:)))];
   GrayMap = 0:511;	%The optimal mapping for this modulation scheme is unknown
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 9;   
case '1024QAM'
   [X1,Y1] =meshgrid(-31:2:31,-31:2:31);
   X = reshape(X1',1,1024);
   Y = reshape(Y1',1,1024);
   a = [0 1 3 2 6 7 5 4 12 13 15 14 10 11 9 8 24 25 27 26 30 31 29 28 20 21 23 22 18 19 17 16];
   GrayMap = [];
   for l = 1:32, GrayMap = [GrayMap a+a(l)*32]; end
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 10;
case '2048QAM'
   [X1,Y1] = meshgrid(-31:2:31,-47:2:-33);
   [X2,Y2] = meshgrid(-47:2:47, -31:2:31);
   [X3,Y3] = meshgrid(-31:2:31, 33:2:47);
   X = [ reshape(X1',1,length(X1(:))) reshape(X2',1,length(X2(:))) reshape(X3',1,length(X3(:)))];
   Y = [ reshape(Y1',1,length(Y1(:))) reshape(Y2',1,length(Y2(:))) reshape(Y3',1,length(Y3(:)))];
   GrayMap = 0:2047;	%The optimal mapping for this modulation scheme is unknown
   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 11; 
case '4096QAM'
   [X1,Y1] =meshgrid(-63:2:63,-63:2:63);
   X = reshape(X1',1,4096);
   Y = reshape(Y1',1,4096);
   a = [0 1 3 2 6 7 5 4 12 13 15 14 10 11 9 8 24 25 27 26 30 31 29 28 20 21 23 22 18 19 17 16];
   a = [a a(32:-1:1)+32];
   GrayMap = [];
   for l = 1:64, GrayMap = [GrayMap a+a(l)*64]; end

   cart_or_pol = 1;	%Constellation defined using cartesian coordinates
   BitHz = 12;
case '8PSK'
   %8PSK
   BitHz = 3;
	PSK = 1;
case '16PSK'
   %16PSK
   BitHz = 4;
	PSK = 1;
case '32PSK'
   %32PSK
   BitHz = 5;
   PSK = 1;
case '64PSK'
   %32PSK
   BitHz = 6;
   PSK = 1;
case '128PSK'
   %32PSK
   BitHz = 7;
   PSK = 1;
case '256PSK'
   %32PSK
   BitHz = 8;
   
   PSK = 1;
otherwise  
   error([ModType ' is unsupported']);
end

if PSK==1,
	ModMag = ones(1,2^BitHz);
   ModPh = 0:2*pi/(2^BitHz):2*pi*(1-1/(2^BitHz));
   GrayMap = [0 1 3 2 6 7 5 4];
   for k = 1:(BitHz-3),
      GrayMap = [GrayMap GrayMap(length(GrayMap):-1:1)+2^(k+2)];
   end
   cart_or_pol = 0;	%Constellation defined using polar coordinates
end

%Check is constellation is specified in cartesian or polar coordinates
if cart_or_pol == 0,
   %In polar so convert to cartesian
   [X,Y] = pol2cart(ModPh,ModMag);
end

if DiffMapFlag==0
   if (PSK == 1)
      Gray2 = zeros(size(GrayMap));
      %GrapMap is the data to go at each successive location around the
      %phase circle. So for each data value, find its position on this
      %gray mapped circle. These positions are then the lookup indexes
      %to put the IQ vectors in the correct spot.
      for k = 1:length(GrayMap)
         Gray2(k) = find((k-1)==GrayMap);
      end
      Xm = X(Gray2);
      Ym = Y(Gray2);
      GrayMap = Gray2;
   else
      %Map the table to include the Gray Code Mapping
		Xm = X(GrayMap+1);
      Ym = Y(GrayMap+1);
   end
   
else
   Xm = X;
   Ym = Y;
end

%Normalise the constellation levels so that the average power is equal to one
%Assume that the input data is random
rmsamp = sqrt(mean(Xm.^2+Ym.^2));
Xn = Xm/rmsamp;
Yn = Ym/rmsamp;

%Convert the magnitude and phase into complex numbers
ModTable = Xn+sqrt(-1)*Yn;

%If there are no outputs to the function plot the IQ diagram of the modulation
if nargout == 0,
   if nargin < 3
      FontScale = 1;
   end
   
   Data = 1:length(ModTable);
   bitstr = dec2bin(Data-1);
   %size(ModTable)
   q = ModTable(Data);
   h = plot(q,'.r');
   title(['I-Q diagram for ' upper(ModType)]);
   axis equal;
   mx = max(real(q));
   %Put text on for < 64QAM and for < 32PSK
   if ((BitHz<6)&(PSK==1))|((PSK==0)&(BitHz<6))
      ht = text(real(q)+0.05,imag(q),bitstr);
      if (PSK == 1)
         set(ht,'fontsize',(24-BitHz*3)*FontScale);
      else
         set(ht,'fontsize',(20-BitHz)*FontScale);
      end
   	xlim([-mx*1.1 mx*(1.3+(FontScale-1)/4)])
	   ylim([-mx*1.1 mx*1.1])
   else
     	xlim([-mx*1.05 mx*1.05])
      ylim([-mx*1.05 mx*1.05])
   end
     
   xlabel('Real');
   ylabel('Imaginary');
   setplotstyle
   %Scale the size of the '.' markers base on how many points there are on the plot
   if (PSK==1)
      set(h,'markersize',(35-BitHz*2.7)*FontScale);
   else
      set(h,'markersize',(35-BitHz*1.8)*FontScale);
   end
else
   if nargout == 3
      GrayMapOut = GrayMap;
   end
   ModTableOut = ModTable;
   BitHzOut = BitHz;
end

   
