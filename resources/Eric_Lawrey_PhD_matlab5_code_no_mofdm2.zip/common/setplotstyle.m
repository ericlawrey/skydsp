function setplotstyle(PlotLinewidth,FontScale,MarkerSize,Scaling)
%SETPLOTSTYLE maximises the plot and sets the fonts and linewidths 
% setplotstyle(PlotLinewidth,FontScale,MarkerSize,scalingflag)
%
% This function maximises the current plot and sets the font and line widths
% so that the plot is suitable for screen capture and embedding into a document
% Set the PlotLinewidth to [] if the linewidths of the lines are not to be modified
% Scalingflag = 1, changing the size of the plot to compensate for the increased
% font size. Scalingflag = 0, don't scale. This is useful for multiple subplots.
%
% This function also sets the paper size to A4, for printing.
%
% Copyright Eric Lawrey (c) September 2000, Eric.Lawrey@jcu.edu.au

% 13/12/00
% Added the optional to change the markersize
% 01/01/01
% Modified the size of the plots to prevent writting from being cut off the
% bottom of the plots.
% 23/01/01
% Improved the sizing of the plots so that changing the font size changes the
% amount of space for the x and y label. The space at the top of the plot
% is changed based on whether there is a title or not.
% 09/03/01
% Added the option to turn off plot scaling.
% 12/4/01
% Fixed up scaling of the plot position for plots with colorbars. Also improved
% plot size scaling with the font size.
% 21/6/01
% Improved the lay out for plots which have a ylabel on the colour bar of the plot
% 13/11/01
% There was a problem with horizontal colourbars. Setplotstyle was scaling them
% so that they became vertical. A simple patch was used. If the colour bar height
% is less than half the plot height then don't apply any scaling to the colorbar
% position.

if nargin <1
   PlotLinewidth = 1.5;
end
if nargin < 2
   FontScale = 1;
end

if nargin < 3
   MarkerSize = 15;
end

if nargin < 4
   Scaling = 1;
end

setstyle(PlotLinewidth,FontScale,MarkerSize,Scaling)

legend		%This updates the legend with the new fonts and line thicknesses
%           If the plot has no legend this has no effect.
setstyle(PlotLinewidth,FontScale,MarkerSize,Scaling)		%Update the outline of the legend. 

function setstyle(PlotLinewidth,FontScale,MarkerSize,Scaling)
scnsize = get(0,'screensize');
yoff = 28;
yheader = 67;
maxsize = [scnsize(1) scnsize(2)+yoff scnsize(3) scnsize(4)-(yoff+yheader)];
set(gcf,'position', maxsize)
TitleFontSize = 24*FontScale;
LabelFontSize = 24*FontScale;
AxesFontSize = 22*FontScale;
AxesLinewidth = 3;

%MarkerSize = 24;
FigColour = [1 1 1];
h_fig = gcf;

h_fig_child = get(h_fig,'children');
h_xlabel = get(h_fig_child,'Xlabel');
h_ylabel = get(h_fig_child,'Ylabel');
h_zlabel = get(h_fig_child,'Zlabel');
h_title = get(h_fig_child,'title');
h_lines = get(h_fig_child,'children');

set(h_fig_child,'fontsize',AxesFontSize,'linewidth',AxesLinewidth);
%Set the attributes of the figures children and the lines on the plots
%which are the children of the children of the figure
set(h_fig,'color',FigColour);
if length(h_fig_child)>1 
   for k = 1:length(h_fig_child)
      set(h_xlabel{k},'Fontsize',LabelFontSize);
      set(h_ylabel{k},'Fontsize',LabelFontSize);
      set(h_zlabel{k},'Fontsize',LabelFontSize);
      set(h_title{k},'Fontsize',TitleFontSize);
      type = get(h_lines{k},'type');
      if strcmp(type,'line')&(~isempty(PlotLinewidth))
         set(h_lines{k},'linewidth',PlotLinewidth);
         set(h_lines{k},'Markersize',MarkerSize);
      end    
   end
else
   set(h_xlabel,'Fontsize',LabelFontSize);
   set(h_ylabel,'Fontsize',LabelFontSize);
   set(h_zlabel,'Fontsize',LabelFontSize);
   set(h_title,'Fontsize',TitleFontSize);
   type = get(h_lines,'type');
   if strcmp(type,'line')&(~isempty(PlotLinewidth))
      set(h_lines,'linewidth',PlotLinewidth);
      set(h_lines,'Markersize',MarkerSize);
   end
end
if Scaling
   %If the fonts are large the dimensions of the plot need to be adjusted .
   ca = get(h_fig,'currentaxes');
   voffset = 0.11*FontScale+0.02;
   hoffset = 0.13*FontScale;
   ht = get(ca,'title');
   s = get(ht,'string');
   if isempty(s)
      %No title so remove the space used by it
      Height = 1-voffset*1.3;
   else
      Height = 1-voffset*2;
      
   end
   h_colour = findobj(gcf,'tag','Colorbar');
   ColourBarFlag = ~isempty(h_colour);		%True if there is a colour bar
   
   if ColourBarFlag
      p =  get(h_colour,'position');
      %Check whether the colorbar is horizontal or vertical
      if p(4)>0.5
         %Vertical so scale appropriately
         h_ylabel_cb = get(h_colour,'ylabel');
         if ~isempty(get(h_ylabel_cb,'string'))
            %Colour bar has a label so allow some more room
            set(h_colour,'position',[1-hoffset/2-0.09 voffset 0.05 Height]);
         else
            set(h_colour,'position',[1-hoffset/2-0.08 voffset 0.0555 Height]);
         end
         
         p = get(h_colour,'position');
         Width = 1-hoffset-(hoffset/2+0.1);
      else
         Width = 1-hoffset*1.5;
      end
      
   else
      Width = 1-hoffset*1.5;
   end
   
   set(ca,'position',[hoffset voffset Width Height]);
end
set(h_fig,'PaperUnits', 'inches',...
   'PaperOrientation', 'landscape',...
   'PaperPosition',[0.25 0.25 11.1929 7.76772],...
   'PaperPositionMode', 'manual',...
   'PaperType', 'a4letter');
