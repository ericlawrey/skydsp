function [outsymbol, overlap] = ofdmmod(SubcarrierVector,Subcarriers, IFFTsize, GuardPeriod, ...
   RealComplex, fast_mode)
%OFDMMOD Low level OFDM modulator
%outsymbol = ofdmmod(SubcarrierVector,Subcarriers, IFFTsize, GuardPeriod, RealComplex)
% Takes the data vectors (complex data representing a carrier phase and 
% amplitude) maps it on to the data carriers. It then performs the inverse 
% FFT to obtain the time domain signal. The guard period is then added. 
%
%outsymbol: OFDMMOD outputs each OFDM symbol as a column vector. If SubcarrierVector
%  is a maxtrix than the number of symbols output matches the number of
%  columns in SubcarrierVector.
%
%SubcarrierVector: complex number representing a carrier phase and amplitude 
%  of each of the carriers in use. If SubcarrierVector is a matrix, each column
%  is calculated as one OFDM symbol. The output OFDM symbols are in matrix
%  form with one symbol per column. The SubcarrierVector should be a column 
%  vector, with one row per carrier. Use DATA2IQMAP
%
%Subcarriers:  index of the carriers using the data. These correspond to 
%  the ifft bins being used. i.e DC => bin 1, positive frequencies
%  are from bin index 2 to ifftsize/2, nyquist frequency is ifftsize/2+1,
%  and negative frequencies start at ifftsize and go down to ifftsize/2+2.
%  The data vector must match the order of the Subcarriers. i.e. 
%  SubcarrierVector(1) will be put on Subcarriers(1) and so on.
%  If SubcarrierVector is a matrix the same Subcarriers will be used for 
%  each OFDM symbol. Use MKCARRIERS to generate Subcarriers
%
%IFFTsize: size of the IFFT to use (typically 128,256,512,1024,2048,4096). 
%  This should be a power of two for fast execution. The IFFT must be more
%  that 2 times the number of carriers for real output, and at least the
%  same as the number of carriers for complex output.
%  Default size is next power of 2 from the number of data 
%  carriers*2
%
%GuardPeriod: length of the cyclic extension (guard period) in samples
%  Default is 0 samples
%  Guard Period can be specified as a vector, indicating that the guard 
%  period should be a raised cosine windowed.
%  GuardPeriod = [constant guard period, raised cosine envelope, overlap];
%  The raised cosine section is added to the start and the end of the symbol.
%  The total length of the guard period is 
%  (raised cosine envelope)*2+constant guard period
%
%  Overlap specifies the overlap between symbols. This overlap occurs over
%  the raised cosine section of the guard period. If overlap == raise cosine
%  envolope then the raised cosine part of the guard period overlaps completely
%  with the next symbol. For a matrix output (i.e. one symbol per column the
%  overlap is taken from the previous symbol and added (addition) to the
%  start of the raised section of the symbol.
%
%RealComplex: Sets whether the output symbol is a complex or real signal
%  'real' - generates a real output waveform. The number of data 
%  carriers must be less than half size of the fft
%  'complex' - generates a complex output waveform
%  Default is 'real'
%
%[outsymbol, overlap] = ofdmmod(....)
%  overlap is the overlapping samples from using a raised cosine window function.
%  This is needed to combine separate calls to OFDMMOD for different symbols. overlap
%  is the length of a complete symbol, with the samples at the start correponding to
%  the overlapping region. Simply add overlap to the first symbol of the next OFDM
%  symbol block to achieve overlapping.
%
%outsymbol = ofdmmod(SubcarrierVector,Subcarriers, IFFTsize, GuardPeriod, ...
%  RealComplex, FastMode)
%FastMode: Turning this on disables all the input checking, warning 
%  messages, and setting of the defaults. The option is used to 
%  enable maximumal speed of execution. If it is turned on all 
%  input variables must be set. The speed improvement is minimal
%  especially if the input is vectors, or large IFFTs. Might be useful
%  for fast looping code operating on small IFFTs.
%  Default is fast_mode = 0
%  fast_mode = 0, warnings and default settings enabled and default setup
%  fast_mode = 1. No warnings, or input checking.
%
%  See also MKCARRIERS, DATA2IQMAP, IQ2DATA
%
% Copyright (c) 28/10/1999 Eric Lawrey

% James Cook University
% eric.lawrey@jcu.edu.au

%Revision History:
% 25/6/00
% OFDMMOD was giving false warnings that 2048 was not a power of two.
% This error was caused by rounding errors. This was fixed by using
% log2 instead of log10(x)/log10(2) and increasing the allowable error
% from eps to 5*eps
%
% 7/11/00 by Eric Lawrey
% Fixed up ofdmmod to allow an IFFTsize of 1. The error occurred due
% to the program failing to recognise the input data as a matrix for
% and IFFTsize of 1. Added |(IFFTsize==1) to the decision as to whether
% the input data is a matrix
%
% 19/3/01 by Eric Lawrey
% Added the ability to have a raised cosine section of the guard period.
%
% 20/3/01 by Eric Lawrey
% Fixed up ofdmmod to allow a single carrier to be used.
%
% 25/3/01 by Eric Lawrey
% Added code to allow the total guard period to be longer than the length of
% the data symbol for raised cosine guard periods.
%
% 23/7/01 by Eric Lawrey
% Modified the function description so that the variable names match up better
% with the other functions developed, such as mkcarriers.
%
% 27/7/01 by Eric Lawrey
% Added overlap to the output. This is needed for combining multiple calls to
% OFDMMOD when raised cosine windowing is called.
%
% 20/10/01 by Eric Lawrey
% Standardised the input variable names, and fixed up the raised cosine windowing,
% which was giving a one half sample error in the envelope. This makes the window
% incorrect when the number of samples is very low.

%check if fast mode is set. Fast mode bypasses all input parameter checking
if nargin < 6
   fast_mode = 0;
end

if nargin < 3
   error('Must have at least two inputs, SubcarrierVector, Subcarriers and IFFTsize');
end

%These checks must be done regardless of fast mode, to set up array interpretation

%The number of data vectors must match the number of data carriers
%If we have a SubcarrierVector which is a matrix, set flags to ensure that
%the OFDM modulation is done using each column of the matrix
if ((size(SubcarrierVector,1)>1)&(size(SubcarrierVector,2)>1))|(IFFTsize==1)
   %We have a matrix thus take data in colunms
   matrixflag = 1;
   Sd = size(SubcarrierVector,1);
else
   matrixflag = 0;
   Sd = length(SubcarrierVector);
end

if (length(Subcarriers) == 1)&(size(SubcarrierVector,1)==1)&(size(SubcarrierVector,2)>1)
   %We have a matrix thus take data in colunms
   matrixflag = 1;
   Sd = size(SubcarrierVector,1);

end

if ~fast_mode
   %======================
   %Set the defaults
   %======================
   if nargin < 5
      RealComplex = 'real';
   end
   
   if nargin < 4
      GuardPeriod = 0;
   end
   
   %Convert the string RealComplex variable to a binary flag, 
   %real_flag = 1  (real output), 
   %real_flag = 0 (complex output)
   if strcmp(lower(RealComplex),'real') 
      real_flag = 1;
   else
      real_flag = 0;
   end
   
   number_carriers = length(Subcarriers);
   
   %============================================================
   %Verify input parameters are valid and issue warnings if any
   %============================================================
   
   %The number of data vectors must match the number of data carriers
   %-   if (size(SubcarrierVector,1)>1)&(size(SubcarrierVector,2)>1)
   %We have a matrix thus take data in colunms
   %-      matrixflag = 1;
   %-      Sd = size(SubcarrierVector,1);
   %-   else
   %-      matrixflag = 0;
   %-      Sd = length(SubcarrierVector);
   %-   end
   if Sd ~= length(Subcarriers)
      error(['Data vector length (' int2str(Sd) ') doesn''t match '...
            'number of data carriers (' int2str(length(Subcarriers)) ')']);
   end
   
   %Check that the number of data carriers is less than the IFFTsize for a complex output
   if (~real_flag & (number_carriers > (IFFTsize)))
      error(['Number of data carriers (' num2str(length(Subcarriers)) ') > IFFTsize (' ...
            num2str(IFFTsize) '), this is illegal for a complex output waveform']);
   end
   
   %Check that the number of data carriers is less than half the IFFTsize, for a real output
   if (real_flag & (number_carriers > (IFFTsize/2)))
      error(['Number of data carriers (' num2str(length(Subcarriers)) ') > IFFTsize/2 (' ...
            num2str(IFFTsize/2) '), this is illegal for a real output waveform']);
   end
   
   if length(GuardPeriod) > 1
      if GuardPeriod(3) > GuardPeriod(2)
         error(['Overlap region of guard period (' num2str(GuardPeriod(3)),...
               '), must be shorter or of equal length to raised cosine section (',...
               num2str(GuardPeriod(2)) ')' ]);
      end
   end
   
   if GuardPeriod(1) < 0
      warning(['guard period (' num2str(GuardPeriod) ') was input as < 0, setting to 0']);
      GuardPeriod(1) = 0;
   end
   
   %check that the IFFTsize is a power of 2
   if (mod(log2(IFFTsize),1)>eps*5)
      warning(['IFFTsize (' num2str(IFFTsize) ') is not a power of two, ' ...
            '(this will result in slower execution)']);
   end
   
   %Check that the Subcarriers are valid numbers, and not more that the ifft size
   if (~real_flag&(max(Subcarriers)>(IFFTsize)))
      error(['Data_carrier (' num2str(max(Subcarriers)) ') too large for ifft size used (' ...
            num2str(IFFTsize) ')']);
   end
   
   %If the output is a real waveform, we can not have any negative frequency data carriers
   if (real_flag&(max(Subcarriers)>IFFTsize/2+1))
      error(['Data carriers (' num2str(max(Subcarriers)) ') must be must be less than IFFTsize(' ...
            num2str(IFFTsize) ')/2+1 for real output']);
   end
   
   %Check that there are not carriers which are negative or DC for real output
   if (real_flag&(min(Subcarriers)<=1))
      error(['No DC or negative frequency bin allow for real output, Data_carrier (' ...
            num2str(min(Subcarriers)) ')']);
   end
   
   %Check that negative frequency data carriers are not represented using negative
   %numbers for complex output.
   if (~real_flag&(min(Subcarriers)<=0))
      error(['No negative data carriers (' num2str(min(Subcarriers)) ') allowed']);
   end
   
else
   %Convert the string RealComplex variable to a binary flag, 
   %real_flag = 1  (real output), 
   %real_flag = 0 (complex output)
   if strcmp(RealComplex,'real') 
      real_flag = 1;
   else
      real_flag = 0;
   end
end   

%Calaculate the number of symbols for calculate
if matrixflag==1,
   Nsymb = size(SubcarrierVector,2);
else
   Nsymb = 1;
end

%Ifftbins will be the vector that the ifft is performed on
ifftbins = zeros(IFFTsize,Nsymb);						%Start with an empty vector;

%I am splitting up the real and complex output processing tasks to optimise the speed

if ~real_flag,
   %For complex output we need to setup both the positive and negative frequencies bins
   %Copy the contents of the data vector into the corresponding carriers
   if matrixflag == 1,
      %If there are multiple symbols to generate, copy using a for loop
      for k = 1:Nsymb
         ifftbins(Subcarriers,k) = SubcarrierVector(:,k);
      end
   else
      ifftbins(Subcarriers) = SubcarrierVector;
   end
   outsymbol = ifft(ifftbins);
else
   %Need for mirror the positive frequency carriers into the negative frequencies in order to get a real
   %output from the ifft. For example
   % a = [1+i 2+2i 3+3i 4+4i 0 0 0 0  0 0 0 0 0 4-4i 3-3i 2-2i];  ifft(a) is real
   %Set up the positive freq bins
   if matrixflag == 1,
      neg_bins = IFFTsize-Subcarriers+2;				%reverse map the positive bins to the negative bins
      for k = 1:Nsymb
         ifftbins(Subcarriers,k) = SubcarrierVector(:,k);
         ifftbins(neg_bins,k) = conj(SubcarrierVector(1:length(neg_bins),k));
      end
   else
      ifftbins(Subcarriers) = SubcarrierVector;
      neg_bins = IFFTsize-Subcarriers+2;				%reverse map the positive bins to the negative bins
      ifftbins(neg_bins) = conj(SubcarrierVector(1:length(neg_bins)));
   end
   
   %outsymbol = ifftbins;
   outsymbol = real(ifft(ifftbins));
end

if length(GuardPeriod)>1
   GuardLength = GuardPeriod(1)+2*GuardPeriod(2)-GuardPeriod(3);
else
   GuardLength = GuardPeriod;
end
OV = zeros(IFFTsize+GuardLength,1);
%Add a cyclic extension to the start of the symbol if needed
if GuardLength > 0
   if length(GuardPeriod) > 1
      
      GP = GuardPeriod(1);
      RaisedGuard = GuardPeriod(2);
      Overlap = GuardPeriod(3);
      
      
      %Add the raised cosine section of the guard period
      N = RaisedGuard;	%Length of the raised cosine section
      
      %Calculate the flat part of the guard period
      flat_guard = outsymbol((IFFTsize-GP+1):IFFTsize,:);
      
      %Check to see if calculating the raised guard period is necessary.
      if N > 0
         %==============================================
         %		Calculate Raised Cosine Windows
         %==============================================
         %Find the window for the raised cosine section at the end of the 
         %symbol. This goes from 1 - 0, and does not take overlap into account
         falling_window = (cos(((0:(N-1))+0.5)/N*pi/2).^2)';
         
         %The is the window for the right most section of the symbol. It is
         %the first part of the falling window, cropped by overlap with the
         %next symbol.
         right_window = repmat(falling_window(1:RaisedGuard-Overlap),1,size(outsymbol,2));
         
         %This is the remaining section of the falling window, and should
         %window the end of the last symbols right most guard period.
         overlap_window = repmat(falling_window(RaisedGuard-Overlap+1:RaisedGuard),...
            1,size(outsymbol,2));
         
         %This is the raising window for the left part of the guard period.
         rising_window = repmat((sin(((0:(N-1))+0.5)/N*pi/2).^2)',1,size(outsymbol,2));
         
         %====================================================
         %		Calculate each section of the guard period
         %====================================================
         if (GuardPeriod(1)+GuardPeriod(2)) > IFFTsize
            dup_output = repmat(outsymbol,ceil(GP/IFFTsize)+1,1);
         else
            dup_output = outsymbol;
         end
         %size(dup_output)
         left_raised_guard = dup_output((end-GP-RaisedGuard+1):end...
            -GP,:).*rising_window;
         
         right_raised_guard = dup_output(1:RaisedGuard-Overlap,:).*right_window;
         Overlap_guard = dup_output(RaisedGuard-Overlap+1:RaisedGuard,:).*overlap_window;
         
         %Record the overlapping
%         GuardLength
%         IFFTsize
%         GuardPeriod(3)
%         size(IFFTsize+GuardLength,1)-GuardPeriod(3)
         OV = [Overlap_guard(:,end); zeros(IFFTsize+GuardLength-GuardPeriod(3),1)];
         
         %Shift the overlap by one symbol
         Overlap_guard = [zeros(Overlap,1) Overlap_guard(:,1:end-1) ];
         
         left_raised_guard(1:Overlap,:) = Overlap_guard+left_raised_guard(1:Overlap,:);
         outsymbol = [left_raised_guard; flat_guard; outsymbol; right_raised_guard];
         
         
         %Overlap_guard
         %plot(OV);
         %pause
%         [SymbOverlap; zeros(size(Symbol2,1)-Overlap,1)];
      else
         outsymbol = [flat_guard; outsymbol];
      end      
      
   else
      GP = GuardPeriod;
      if GP > IFFTsize
         if matrixflag == 1
            dup_output = repmat(outsymbol,ceil(GP/IFFTsize)+1,1); %duplicate the output symbol
            %Trim the output to the correct length
            outsymbol = dup_output((size(dup_output,1)-(GP+IFFTsize)+1):size(dup_output,1),:);
         else
            dup_output = repmat(outsymbol,1,ceil(GP/IFFTsize)+1); %duplicate the output symbol
            %Trim the output to the correct length
            outsymbol = dup_output((size(dup_output,2)-(GP+IFFTsize)+1):size(dup_output,2),:); 
         end   
      else
         outsymbol = [outsymbol((IFFTsize-GP+1):IFFTsize,:); outsymbol];
      end
   end
end   
if nargout > 1
   overlap = OV;
end

