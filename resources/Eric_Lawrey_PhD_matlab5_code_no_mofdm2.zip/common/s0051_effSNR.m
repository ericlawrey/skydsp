%S0051_EFFSNR Find the effective channel SNR for OFDM under different conditions
% This script runs an OFDM simulation which measures the effective SNR of the link
% The simulation, produces a single OFDM frame with one or more pilot symbols
% at the start. These are used for channel equalisation. The rest of the frame
% has Nsymbol symbols in it. Channel equilisation is only done at the start
% of the frame. No frequence correction is applied, only a correction for
% amplitude scaling and a phase rotation.
% The simulation allows the simulation to be looped through two parameters.
% LoopVariable is the primary X axis variable, which will be calculated at
% points LoopList. For example LoopVariable = 'OutBackoffdB', and 
% LoopList = [0:1:12];, the x axis of the simulation will be Output Back off Power
% which will go from 0 in steps of 1 dB up to 12 dB. 
% LoopVariable should be a string of the variable name which is to be the x axis.
%
% LoopVariable2 allows another parameter to be varied, such as repeating the 
% output backoff simulation at 3 different numbers of carriers. This
% would be achieved by making LoopVariable2 = 'Ncarriers';
% LoopList2 = [8, 64, 512], simulating 8, 64, and 512 carriers.
%
% LockVariables2 allows other variables to be changed along with LoopVariable2.
% This is useful for changing parameters like the IFFTsize to match the number of
% carriers.
% LockValues2 is a cell array of vectors that each LockVariable2 will take.
%
% s0051_effsnr should be called from another script which will set up all the
% simulation parameters.
%
% See s0052_SNR_OB.m for an example of a scipt to call S0051_effsnr
%
% FreqOff - Frequency offset to apply to the signal, in subcarrier spacings, i.e.
%           FreqOff = 0.5 means a frequency error of half a subcarrier spacing.
%
% LogPlotFlag - (1) - Plot xaxis as a log space, (0) - linear axis
%
% NpilotTones - Number of pilot tone to be used in each OFDM symbol.
% SymbAvgType - 0, perform symbol effective SNR over the average of all symbols
%               >0 select the SNR from the SymbAvgType(th) symbol.
% SymbolPlotFlag - 0 plot the data from the average over carriers
%                  1 plot using the SNR from a particular symbol.
% FreqErrType - Type of frequency error to add. 0 - freq offset, 1 - randn
% Wrap - Wraps the signal generated to make a trailer on the signal, this is
%        needed to prevent errors when bandpassing a signal and applying a
%        negative time offset. It is removed automatically, Default = 512;
%        Its value should be at least = TimeOffset
%
% Copyright Eric Lawrey

%6/7/2001
% Fixed up so that overlapping raised cosine guard periods work
switch LoopVariable
case 'FreqOff'
   xlabel_text = 'Frequency Offset Error (carrier spacings)';
case 'OutBackoffdB'
   xlabel_text = 'Output Power Backoff (dB)';
case 'TimeOffset'
   xlabel_text = 'Time Offset (Fraction of Symbol)';
case 'GuardPeriod'
   xlabel_text = 'Guard period (samples)';
otherwise
   warning(['Unsupported loop variable (' LoopVariable '), plot axes will be wrong'])
   xlabel_text = '';
end

%===========================================================
%Set default to maintain compatibiliy with older simulations
if ~exist('BPFilterFlag','var')
   BPFilterFlag = 0;
end
if ~exist('RxBPFilterFlag','var')
   RxBPFilterFlag = 0;
end

if ~exist('CarrierPlotFlag','var')
   CarrierPlotFlag = 0;
end

if ~exist('SymbAvgType','var')
   SymbAvgType = 0;
end

if ~exist('SymbolPlotFlag','var')
   SymbolPlotFlag = 0;
end

if ~exist('TimeOffSymbScaleFlag','var')
   TimeOffSymbScaleFlag = 0;
end

if ~exist('LockVariables','var')
   LockVariables = {};
   LockValues = {};
end

if ~exist('PreClipDistFlag','var')
   PreClipDistFlag = 0;
   PreOutBackoffdB = 0;
end

if ~exist('SavePlotFlag','var')
   SavePlotFlag = 1;
end

if ~exist('FreqOff','var')
   FreqOff = 0;
end

if ~exist('NpilotTones','var');
   NpilotTones = 0;
end

if ~exist('LogPlotFlag','var')
   LogPlotFlag = 0;
end

if ~exist('FreqErrType','var')
   FreqErrType = 0;
end

if ~exist('Wrap','var')
   Wrap = 512;
end

if (length(LoopList2)>1)&(CarrierPlotFlag)
   error('Can only plot carrier SNR for single value loop variable 2')
end
%============================================================
legend_str = cell(1,length(LoopList2));
if CarrierPlotFlag
   LoopVariable2a = LoopVariable;
   LoopList2a = LoopList;
else
   LoopVariable2a = LoopVariable2;
   LoopList2a = LoopList2;
end


switch LoopVariable2a
case 'Ncarriers'
   for s= 1:length(LoopList2a)
      legend_str{s} = [num2str(LoopList2a(s)) ' carriers'];
   end
case 'PilotPowBoost'
   label = {'(a)','(b)','(c)','(d)'}
   for s= 1:length(LoopList2a)
      ind = find(strcmp(LockVariables2,'RefScheme'));
      if ~isempty(ind)
         [RefSymb, CF] = genref(Ncarriers,LockValues2{ind}(s));
         legend_str{s} = ['(' setstr(s-1+'a') ') Boost:' sprintf('%3.2g',10*log10(LoopList2a(s))) 'dB, CF:' ...
               sprintf('%3.2g',CF) 'dB'];
      else
         legend_str{s} = ['Boost:' sprintf('%3.2g',10*log10(LoopList2a(s))) 'dB'];
      end
   end
case 'FiltWidth'
   for s = 1:length(LoopList2a)
      legend_str{s} = [num2str(LoopList2a(s)) ' carr. cutoff'];
   end
case 'PreOutBackoffdB'
   for s = 1:length(LoopList2a)
      if LoopList2a(s) ~= -1
         legend_str{s} = ['Pre-Filter OBO: ' num2str(LoopList2a(s)) 'dB'];
      else
         legend_str{s} = ['No Pre-Filtering'];
      end
      
   end
case 'Nsymbol'
   for s = 1:length(LoopList2a)
      legend_str{s} = [num2str(LoopList2a(s))];
   end
otherwise
   warning(['Unsupported loop variable2 (' LoopVariable2a '), legend will be sparse'])
   for s = 1:length(LoopList2a)
      legend_str{s} = [num2str(LoopList2a(s))];
   end   
end


%==========================================================
EffSNR = zeros(length(LoopList),length(LoopList2));
AvgSymbSNR = EffSNR;
for l2 = 1:length(LoopList2)
   eval([LoopVariable2 ' = LoopList2(l2);'])
   %Set all lock variables to their corresponding value in LockValues2
   for lk = 1:length(LockVariables2)   
      eval([LockVariables2{lk} ' = LockValues2{lk}(l2);']);
   end
   AvgCarrierSNRRec = zeros(length(LoopList), Ncarriers);
   for l = 1:length(LoopList)
      eval([LoopVariable ' = LoopList(l);'])
      %Set all lock variables to their corresponding value in LockValues
      for lk = 1:length(LockVariables)   
         eval([LockVariables{lk} ' = LockValues{lk}(l);']);
      end
      
      carriers = mkcarriers(Ncarriers,IFFTsize,RealComplex);
      
      for k = 1:Ntrials
         
         %Repeat the process since, the maximum number of symbols is limited by memory
         %This is so we can get a smoother plot.
         
         %If we have specified an overlapping raised cosine guard period
         %calculate the effective length of the guard period
         if length(GuardPeriod)>1
            GP = GuardPeriod(1)+GuardPeriod(2);
         else
            GP = GuardPeriod;
         end
         
         
         %Create random QAM data with a peak amplitude of 1.
         IQ = (rand(Ncarriers,Nsymbol)*2-1+i*(rand(Ncarriers,Nsymbol)*2-1))/sqrt(2);
         IQ = IQ/mean(mean(abs(IQ)));	%Make the mean carrier power = 1;
         
         RefSymb = genref(Ncarriers,RefScheme)*sqrt(PilotPowBoost);
         IQ2 = [repmat(RefSymb,1,NumRefSymb) IQ];
         %=============================================
         %		Generate transmitted OFDM signal
         %=============================================
         outsymbol = ofdmmod(IQ2, carriers, IFFTsize, GuardPeriod, ...
            RealComplex, fast_mode);
         
         %If the modulation is real, then the effective bandwidth of the 
         %OFDM spectrum is 2*the number of carriers.
         %This is done to calculate the correct amount of noise to add
         if strcmp(RealComplex,'real')
            BWscale = 2*Ncarriers/IFFTsize;
         else
            BWscale = Ncarriers/IFFTsize;
         end
         %Convert from a matrix form of one symbol per column to 
         %a single time vector
         outsig = reshape(outsymbol,1,size(outsymbol,1)*size(outsymbol,2));
         
         %============================================================
         %		Frequency Offset (Simulate Doppler Shift)
         %============================================================
         %Frequency offset is normalised to the subcarrier spacing
         if FreqOff > 0
            switch FreqErrType
            case 0
               FreqFs = FreqOff/(IFFTsize);	%Find the Error as a fraction
               %                              of the sample rate
            case 1
               FreqFs = FreqOff/(IFFTsize).*randn(1,length(outsig));
               %PhaseOff = randn(1,length(outsig));
            end   
            I = sin(2*pi*(1:length(outsig)).*FreqFs);
            Q = cos(2*pi*(1:length(outsig)).*FreqFs);
            Yoff = I+i*Q;
            outsig = outsig.*Yoff;
         end
         %============================================================
         %		Add Time Offset to the signal (i.e. Time Sync Error)
         %============================================================
         if TimeOffSymbScaleFlag
            TimeOff = round(TimeOffset*(IFFTsize+GP));
         else
            TimeOff = TimeOffset;
         end
         Wrap = TimeOff;		%Add a bit of trailer signal to allow for the bit chopped by the time offset.
         if TimeOffset < 0
            outsig = [zeros(1,abs(TimeOff)) outsig(1:end-abs(TimeOff))]; % zeros(1,128)];
         end
         if TimeOffset > 0
            outsig = [outsig(TimeOff+1:end) zeros(1,TimeOff)];
         end
         %TimeOffset
         %===============================================
         %		Add Pre clipping before the filtering
         %===============================================
         if PreClipDistFlag&(PreOutBackoffdB~=-1)         
            outsig = clipdist(outsig,PreOutBackoffdB);
         end
         
         if BPFilterFlag
            %Lets used the same as done before in s0038
            %TransWidth is the transition width of the window function
            %FiltWidth width of the bandpass filtering to first null
            
            FilterTaps = TransWidth./FiltWidth;
            Ntaps = round(IFFTsize*FilterTaps/2)*2;	%Number of filter taps, make it even
            
            Window = kaiser2(Ntaps+1,'width',TransWidth);	%Window function to use
            if strcmp(lower(RealComplex),'real')
               %Band pass filter the signal from minimum carrier to maximum carrier
               f1 = min(carriers)/IFFTsize/(1+2/Ntaps);
               f2 = max(carriers)/IFFTsize*(1+2/Ntaps);
               B = fir1(Ntaps,[f1 f2]*2,Window);	%Filter Coefficients
            else
               %Complex signal so low pass at the maximum positive carrier frequency
               %B = Filter Coefficients
               %We must add one to the carrier number because DC corresponds to subcarrier 1 not 0
               fc1 = max(carriers(find(carriers<=IFFTsize/2))-1)+1;
               fc2 = abs(min(carriers(find(carriers>IFFTsize/2)))-IFFTsize-1)+1;
%               f1 = (max(fc1,fc2)/IFFTsize*(1+2/Ntaps))*2;
               f1 = max(fc1,fc2)/IFFTsize*2;
               B = fir1(Ntaps,f1,Window);	         
            end
            outsig2 = outsig;   
            %            size(outsig)
            outsig = fftfilt(B,[outsig zeros(1,Ntaps/2)]);
            outsig = outsig(Ntaps/2+1:end);	%Compensate for filter delay
            
         end
%         outsigbp = outsig;
         %outsig = outsig(1:end-Wrap);
         %===============================================
         %		Add clipping distortion to the signal
         %===============================================
         if ClipDistFlag         
            outsig = clipdist(outsig,OutBackoffdB);
         end
         
         SpecVerify = 0;
         if SpecVerify
            %Check the spectrum of the signal (used for debugging)
            %Use specgram to get an averaged spectrum.
            PlotFFT = 1024;			%FFT to use in plotting the graphs
            W = specgram(outsig,PlotFFT,1,lawrey5(PlotFFT));
            avg_pow = mean(mean(abs(W).^2));
            mw = 20*log10(fftshift(mean(abs(W/sqrt(avg_pow))')))';
            plot(mw);
            pause
         end
         %======================================
         %		Add AWGN to the signal
         %======================================
         [outsig noise] = addnoise(outsig,SNRdB,BWscale);
         %         psd(outsig,8192)
         %         pause
         
         %=========================================
         %    Bandpass filter the received signal
         %=========================================
         if RxBPFilterFlag
            %Lets used the same as done before in s0038
            %TransWidth is the transition width of the window function
            %FiltWidth width of the bandpass filtering to first null
            
            FilterTaps = RxTransWidth./RxFiltWidth;
            Ntaps = round(IFFTsize*FilterTaps/2)*2;	%Number of filter taps, make it even
            
            Window = kaiser2(Ntaps+1,'width',TransWidth);	%Window function to use
            if strcmp(lower(RealComplex),'real')
               %Band pass filter the signal from minimum carrier to maximum carrier
               f1 = min(carriers)/IFFTsize/(1+2/Ntaps);
               f2 = max(carriers)/IFFTsize*(1+2/Ntaps);
               B = fir1(Ntaps,[f1 f2]*2,Window);	%Filter Coefficients
            else
               %Complex signal so low pass at the maximum positive carrier frequency
               %B = Filter Coefficients
               fsc1 =max(carriers(find(carriers<=IFFTsize/2)));
               fsc2 =abs(min(carriers(find(carriers>IFFTsize/2)))-IFFTsize-1);
               f1 = (max(fsc1,fsc2)/IFFTsize*(1+2/Ntaps))*2;
               B = fir1(Ntaps,f1,Window);	         
            end
            outsig2 = outsig;   
            %            size(outsig)
            outsig = fftfilt(B,[outsig zeros(1,Ntaps/2)]);
            outsig = outsig(Ntaps/2+1:end);
            outsigbp = outsig
         end
         %Change the time domain data into matrix form, one symbol per column.
         outsig = reshape(outsig,(IFFTsize+GP),length(outsig)/(IFFTsize+GP));        
         %==========================================               
         %		Demodulate the OFDM signal
         %==========================================
         %Strip off the guardperiod
         %This will be the lower rows of the matrix. Each column is a symbol
         %This simulation assumes perfect time synchronization
         outsig = outsig(GP+(1:IFFTsize),:);
         %Apply the FFT
         fftdata = fft(outsig);
         %Now keep the carriers which were used
         IQrx = fftdata(carriers,:);          
         
         %=========================================
         %	Perform channel characterisation
         %=========================================
         %From the pilot symbols at the start of the transmission
         if NumRefSymb > 1
            ChannResp = (mean(IQrx(:,1:NumRefSymb)')')./(mean(IQ2(:,1:NumRefSymb)')');
         else
            ChannResp = (IQrx(:,1)./IQ2(:,1));
         end
         
         IQrx2 = IQrx(:,NumRefSymb+1:end)./repmat(ChannResp,1,size(IQrx,2)-NumRefSymb);
         
         IQerr = (IQrx2-IQ);
         
         if k > 1
            carrierSNR = carrierSNR + 20*log10(mean(abs(IQ'))./mean(abs(IQerr')));	%Take the mean of the
            %data before dividing the results, to prevent a lot of div by 0 results, which
            %give infinite SNR.
         else
            carrierSNR = 20*log10(mean(abs(IQ'))./mean(abs(IQerr')));
         end
         
         if k > 1
            SymbolSNR = SymbolSNR + 20*log10(mean(abs(IQ))./mean(abs(IQerr)));	%Take the mean of the
            %data before dividing the results, to prevent a lot of div by 0 results, which
            %give infinite SNR.
         else
            SymbolSNR = 20*log10(mean(abs(IQ))./mean(abs(IQerr)));
         end        
         disp([LoopVariable2 ': ' sprintf('%4g',LoopList2(l2)) ', ' LoopVariable ': ' sprintf('%4g',LoopList(l))...
               ', ' sprintf('%4g',l) ' of ' num2str(length(LoopList)) ', Calc: ' sprintf('%4g',k)...
               ' of ' num2str(Ntrials) ' Trials'])
      end
      AvgCarrierSNR = carrierSNR/Ntrials;
      AvgCarrierSNRRec(l,:) = AvgCarrierSNR;
      if SymbAvgType == 0
         AvgSymbSNR(l,l2) = mean(SymbolSNR)/Ntrials;
      else
         AvgSymbSNR(l,l2) = SymbolSNR(SymbAvgType)/Ntrials;
      end
      
      EffSNR(l,l2) = mean(AvgCarrierSNR);
   end
end
figure(1)
clf
if CarrierPlotFlag
   %Plot the effective SNR of each of the carriers
   CarrNumbers = 1:Ncarriers;
   h = plot(CarrNumbers,AvgCarrierSNRRec);
   xlabel('Subcarrier number from edge of signal');
   if legend_flag
      legend(h,legend_str,legend_pos)
   end
else
   if SymbolPlotFlag
      Y = AvgSymbSNR;
   else
      Y = EffSNR;
   end
   %h = plot(LoopList,AvgSymbSNR);
   if LogPlotFlag
      h = semilogx(LoopList,Y);
   else
      h = plot(LoopList,Y);
   end
   
   if exist('xticks','var')
      if length(xticks)>1
         set(gca,'xtick',xticks);
      end
   end
   xlabel(xlabel_text)
   axis(axis_range);
   if legend_flag
      legend(h,legend_str,legend_pos)
   end
end
grid on
ylabel('Effective SNR (dB)')
title(title_text)
if exist('yticks','var')
   if length(yticks)>1
      set(gca,'ytick',yticks);
   end
end
if exist('TitleStr','var')
   title(TitleStr)
end

setplotstyle;
plotm(h,MarkerSpacing)
if SavePlotFlag
   savefig(plot_filename)
end