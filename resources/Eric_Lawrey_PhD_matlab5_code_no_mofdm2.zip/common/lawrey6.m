function w = lawrey6(n)
%LAWREY6 returns the N-point 6 term Lawrey window
% w = lawrey6(n)
% This window was developed, based on the Kaiser window function.
% The coefficients used were optimised for 6 terms and limited 
% precision (single precision) 
%
% This window has a -139.9 dB first sidelobe level. The first
% null is 5.86 carrier bins in width. This makes it useful for
% for maintaining full dynamic range of 24 bit signals.
%
% Attenuation Transistion width from DC
%   3 dB        1.162
%   6 dB        1.635
%   10 dB       2.097
%   20 dB       2.915
%   40 dB       3.977
%   60 dB       4.683
%   80 dB       5.181
%   100 dB      5.523
%   120 dB      5.736
% window loss 0.29478 (= vout/vin), Power loss is -10.6102dB
% must allow for this in calculations.
%
% See also LAWREY5, BARTLETT, BOXCAR, CHEBWIN, HAMMING, HANNING, 
%    KAISER and TRIANG.

% Copyright Eric Lawrey 17th July 2001
% $Revision: 1.00 $  $Date: 2001/07/17 00:00:00 $

theta = 2*pi/(n-1)*(0:n-1);
w = (0.2949200 - 0.4531624*cos(theta) +0.2004549*cos(2*theta) -...
   0.0467364*cos(3*theta)+0.0046253*cos(4*theta)-0.0001010*cos(5*theta))';

