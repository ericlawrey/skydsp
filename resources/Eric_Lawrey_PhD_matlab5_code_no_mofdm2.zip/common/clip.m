function y = clip(x,low,high)
%CLIP clips the input signal to a lower and upper limit
% y = clip(x,low,high)
%  Clips the signal x to a lower limit of 'low' and an upper
%  limit of 'high'
%
% y = clip(x,amplimit)
%  if only a single input is given it will clip the magnitude 
%  of the signal to the amplitude given.
%
% If x is complex, y = clip(x,amplimit) should be used
% Copyright Eric Lawrey April 2001
y = x;
if ~isreal(x)
   if nargin > 2
      error('Should only have 2 inputs for complex signals : y = clip(x,amplimit)');
   end
end
if nargin < 3
   ind = find(abs(x)>low);
   %Scale the vectors which are longer than the amplitude limit
   %to match the amplitude limit, keep the phase the same.
   scale = abs(x(ind))/low;
   y(ind) = y(ind)./scale;
else
   %Clip on the lower side
	ind = find(x<low);
	y(ind) = ones(size(ind))*low;

	%clip high signals
	ind = find(x>high);
   y(ind) = ones(size(ind))*high;
end


