function w = lawrey5(n)
%LAWREY5 returns the N-point 5 term Lawrey window
% w = lawrey5(n)
% This window was developed, based on the Kaiser window function
% then optimised for 5 terms and limited precision using genetic 
% algorithms.
%
% This window function has a -109.9 dBc first sidelobe level. The first
% null is 4.795 carrier bins in width. 
% Attenuation Transistion width
%   3dB         1.056
%   6dB         1.484
%   10dB        1.90
%   20dB        2.63
%   40dB        3.55
%   60dB        4.13
%   80dB        4.50
% window loss 0.33171 (= vout/vin), Power loss is -9.5849dB
% must allow for this in calculations
%
% See also LAWREY6, BARTLETT, BOXCAR, CHEBWIN, HAMMING, HANNING, 
%    KAISER and TRIANG.

% Eric Lawrey 7th March 2001
% $Revision: 1.00 $  $Date: 2001/03/07 00:00:00 $

theta = 2*pi/(n-1)*(0:n-1);
w = (0.3318676 - 0.4766027*cos(theta) +0.1675404*cos(2*theta) -...
   0.0234285*cos(3*theta)+0.0006249*cos(4*theta))';

