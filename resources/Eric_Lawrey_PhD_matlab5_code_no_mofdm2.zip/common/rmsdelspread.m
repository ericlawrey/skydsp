function rmsds = rmsdelspread(A,T)
%RMSDELSPREAD   Calculate the rms delay spread of impulse response
% rmsds = rmsdelspread(A,T)
%A - amplitude of the impulses (vector)
%T - Time of each impulse (vector of same length as A)
Pt = sum(abs(A).^2);			%Total Power
Ta = sum(((abs(A).^2)/Pt).*T);	%Calculate the the power weighted first moment
rmsds = sqrt(sum(((abs(A).^2)/Pt).*((T-Ta).^2)));

