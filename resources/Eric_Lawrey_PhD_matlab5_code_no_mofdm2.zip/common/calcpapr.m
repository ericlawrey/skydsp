function [papr, maxsig] = calcpapr(timesig,interprate,Quality)
%CALCPAPR calculates the peak to average power ratio in dB
% The input signal is interpolated to find the peak power
% accurately then the PAPR is calculated. If the signal is a
% complex signal, then the PAPR is equivalent to the Crest Factor
% of a carrier modulated by that complex waveform.
% [papr] = calcpapr(timesig,interprate,Quality)
%
% timesig - time waveform to analyse. If timesig is a matrix
%           each column is processed separately.
% interprate - interpolation rate to use when estimating the 
% Quality - Quality of low pass filtering used in upsamping
%           peak signal power. Default = 4;
%
% [papr maxsig] = calcpapr(timesig,interprate)
% maxsig = peak signal amplitude found
%
% Copyright Eric Lawrey April 2001
if nargin < 2
   interprate = 8;
end
if nargin < 3
   Quality = 1;
end
%Interpolate the signal to get a better measurements of the peaks
if interprate > 1
   intsig = upsamp(timesig ,interprate, Quality);
else
   intsig = timesig;
end
%Find the peak power to average power
maxsig = max(abs(intsig));
papr = 10*log10(maxsig.^2./(mean(abs(intsig).^2)));