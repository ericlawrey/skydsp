function [papr, timesig]= phasepapr(Phase,Oversamp,Offset,RealComplex)
%PHASEPAPR This function calculates time time signal for a DMT with given phase angles.
%[papr, timesig]= phasepapr(Phase,Oversamp,Offset,RealComplex)
% Interpolation of the signal is performed in the frequency domain
%
% Phase = vector of the carrier phases in radians
% Oversamp = Over sampling of the carriers for generation of the time domain.
%  Default Oversamp = 64
% Offset = Frequency Offset for the carriers. For a real output, Offset
%  corresponds to the number of carriers from DC+1. An Offset of 0 corresponds
%  to a minimum carrier of one carrier offset from DC. Set Offset
%  to [] for centering. For complex output an offset of 0 correspond to the 
%  carriers being centred around DC. (Default is to centre carriers)
% RealComplex = 0, use a real output, 1 = complex output waveform (default)
%
% papr = Peak to Average Power Ratio in dB
% timesig = Time waveform of the low papr DMT signal.
% The number of samples in the time waveform is equal to:
% The number of carriers rounded upto the next power of 2, times the over sample
% rate.

%Copyright Eric Lawrey 19/9/00
% 9/1/1
% Finished implementation of function
if nargin < 2
   Oversamp = 64;	%Oversample rate used in estimation of the PAPR ratio
end
if nargin < 3
   Offset = []; %Centred by default
end
if nargin < 4
   RealComplex = 1; %Complex output by default
end

Ncarrs = length(Phase);
IFFT_size = 2.^nextpow2(Ncarrs*Oversamp);		%Calculated the IFFT size.
%		This will be the size of the final time waveform

GuardPeriod = 0;	%Assume no guard period
fast_mode = 0;		%This indicates whether to use input checking with the ofdm
%						 Setting this to 1 will make it slightly faster.   

if size(Phase,1) > 1
   Phase = Phase';	%Make sure Phase is a single row vector
end

Amp = ones(1,Ncarrs);	%All carriers have the same power.
[x,y] = pol2cart(Phase,Amp);	%Calculate the IQ data of the carriers
iqdata = x+sqrt(-1)*y;

%Calculate the carrier bins.
if RealComplex
   real_complex = 'complex';
   %Complex data so centring
   data_bins_interp = (-floor(Ncarrs/2-0.1):floor(Ncarrs/2))+Offset;
   Ind = find(data_bins_interp<0);
   data_bins_interp(Ind) = data_bins_interp(Ind)+IFFT_size;
   data_bins_interp = data_bins_interp+1;   
else
   real_complex = 'real';
   %Complex data so centring
   data_bins_interp = (2:(Ncarrs+1))+Offset;
end

%Generate the real OFDM (DMT) waveform for the given iqdata (low papr reference)
%Note: this symbol is generated using a large IFFT which effectively interpolates
%the signal. This allows use to get a good estimate of the peaks in the signal.
refsinterp = ofdmmod(iqdata, data_bins_interp, IFFT_size, GuardPeriod, real_complex, fast_mode);

%Calculate the papr of the OFDM signal, use 1x interpolation as we have already
%interpolated the signal in the frequency domain by using a large IFFT. Interpolation
%in the frequency domain is faster than the time domain interpolation used in calcpapr
papr  = calcpapr(refsinterp,1);
if nargout > 1
   timesig = refsinterp;
end