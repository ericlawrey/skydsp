function [delpro] = gensimpimp(Ntaps,delspread,arg3,arg4,arg5)
%GENSIMPIMP generate a simple radio impulse response
% This model produces a filter which simulates multipath in a
% radio channel. This model produces a random impulse response.
% The impulse has an exponential decay, with a time constant 
% of delspread.
% [delpro] = gensimpimp(Ntaps,delspread)
%
% More complicated impulse functions can be made by adding two 
% additional parameters, dellist and decay
% [delpro] = gensimpimp(Ntaps,delspread,dellist,decay)
% dellist is a list of starting locations for exponential decay
% random impulses. These multiple impulses are decay overall with
% a time constant of decay.
% For example:
% delpro = gensimpimp(100,10,[1,50, 80],100);
%
% This will make a randomised impulse response of 100 samples, 
% with an envelope with 3 exponential decays starting a 1, 50, 
% and 80 samples, these decays will have a time constant of 10 
% samples. There will be an overall decay with time constant of 
% 100 samples.
%
% Complex impulse functions (as real and imaginary) can be made
% by making the third parameter a string. i.e
% [delpro] = gensimpimp(Ntaps,delspread,'complex')
% and [delpro] = gensimpimp(Ntaps,delspread,'complex',dellist,decay)
% Any string will do. The routine checks to see if the 3rd parameter
% is a string. If so complex generation is performed.
% [delpro] = gensimpimp(Ntaps,delspread,'real'), will NOT make a
% real output. The value of the string is ignored.
%
% Copyright Eric Lawrey March 2001


%1/3/1
%5/3/01
%Added multiple impulse capability
%
%6/3/01
%Added an option to allow for complex impulses to be generated.
%
% 5/7/2001
% Fixed a problem with generating complex impulse response. It had
% a memory overflow, because the input argument selection was
% setting the number in the dellist to 1e9;
if nargin < 3
   arg3 = 1;
end

if nargin < 4
   arg4 = 1e20;
end

if nargin < 5;
   arg5 = 1e20;
end

%Check to see if arg3 is a string. If so make a complex impulse
%use arg4, arg5 and the input for dellist and decay.
if isstr(arg3)
   complexflag = 1;
   if nargin < 4
      dellist = 1;
   else
      dellist = arg4;
   end
    
   decay = arg5;
else
   complexflag = 0;
   dellist = arg3;
   decay = arg4;   
end


if Ntaps == 0
   error('Ntaps is zero, no filter can be built');
end

%
delpro1 = zeros(1,Ntaps);
for k = 1:length(dellist)
   if complexflag
      delrand = randn(1,Ntaps)+sqrt(-1)*randn(1,Ntaps);
   else
      delrand = randn(1,Ntaps);
   end
   t = 0:(Ntaps-1-dellist(k)+1);
   delpro1 = delpro1+[zeros(1,dellist(k)-1), exp(-(t/delspread))].*delrand;
end
t = 0:(Ntaps-1);
delpro1 = delpro1.*exp(-(t/decay));
delpro = delpro1/sqrt(sum(abs(delpro1).^2));

