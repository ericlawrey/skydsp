function [StartTime, Times]= multisync(x,FrmLength,SyncFrms,SyncGap,...
   SyncLength,Nsegments,TimeTolScale,SyncType,MultiAvg,FrmSyncLength)
%MULTISYNC Perform time synchronisation using duplicate waveforms
% It detects the signal difference or correlator, and selects the
% best signals using frame time difference.
% [StartTime, Times]= multisync(x,FrmLength,SyncFrms,SyncGap,...
%                       SyncLength,Nsegments,TimeTolScale,MultiAvgFlag)
% Break the waveform into multiple segments, which are smaller
% than on frame. If we have four segements the algorithm will
% find four nulls in the waveform per frame.
% FrmLength  - Total number of samples in a frame including synch
% SyncFrms   - Number of Frames to synchronise over
% Nsegements - Each frame is broken into Nsegments for detection
%              If there is a spurious null from noise breaking into
%              segments will allow the sync null to still be detected.
% SyncGap    - Length of the Synch waveform. This is the spacing, in 
%              samples, between error measurements.
% SyncLength - Length of the moving average filter used for detection
% TimeTolScale - Scaling value for changing the weighting between frame 
%              time matching and depth of the null in deciding best nulls
%              Default value is 5
% SyncType   - Type of Synchroniser, 0 - Correlation
%              1 - Difference
% MultiAvg   - Number of symbols or frames to perform moving averaging over
%
% See also TMSYNCDS
%
% Copyright Eric Lawrey 25/7/2001
if nargin < 7
   SyncType = 1;
end

if nargin < 6
   TimeTolScale = 5;
end

%Trim the waveform to the expected length (complain if it is
%too short) Need a little longer than SyncFrms * FrmLength
%to allow for the trimming when performing the detection
M = SyncLength;
P = MultiAvg;
S = FrmSyncLength;
ExtraLength = M+(S+M)*(P-1);
xlength = FrmLength*SyncFrms+SyncGap+ExtraLength;
if xlength > length(x)
   error(['Sample set too small (' num2str(length(x)) ') to synch over ',...
         num2str(SyncGap) ' frames, needs to be >' num2str(xlength) ' in length']);
end
x = x(1:xlength);
if rem(FrmLength,Nsegments)~=0
   error(['FrmLength (' num2str(FrmLength) ') must a multiple of the number of segments ',...
         '(' num2str(Nsegments) ')']);
end
SegLength = FrmLength/Nsegments;
%Perform the mean squared error on the waveform. This function chops off the start
%figure(3)
o = tmsyncds(x,SyncGap,M,SyncType,P,S);
plot(abs(o))
pause
%SyncGap
%size(o)
%SegLength

%Chop up the filtered envelop to find the nulls in the waveform
Nsegtot = length(o)/SegLength;
%Nsegtot
Segs = reshape(o,SegLength,Nsegtot);
switch SyncType
case 0
   %The correlator creates peaks and so find these
   [NullPow,I] = max(Segs);
case 1
   %The difference method creates minima so find these
   [NullPow,I] = min(Segs);
otherwise
   error(['Invalid synchronisation type : ' num2str(SyncType)])
end

IndexAdd = (0:SegLength:Nsegtot*SegLength-1);
IndNull = I+IndexAdd;	%Indexes of the found nulls in the envelope

%The nulls should be equally spaced in the IndNull list, due to the segmenting
%If the correct null was in the 3 segment in the first frame it will also be
%in the 3rd segment of the second frame.
SegTimeErr = zeros(1,Nsegments);
SegPow = zeros(1,Nsegments);

%For each segment, find the differential timing error, and the null
%depth
for k = 1:Nsegments
   %Find the time difference between nulls, 
   %and find the error compared with the expected number of samples
   SegErr = rem(diff(IndNull(k:Nsegments:end)),FrmLength);	
   ind = find(SegErr>FrmLength/2);
   SegErr(ind) = SegErr(ind)-FrmLength*ones(size(ind));
   if Nsegments == 1
      SegTimeError = SegErr;
   else
	   %Record the mean squared error for that segment
      SegTimeErr(k)=mean(SegErr.^2);
   end
   
   SegPow(k) = mean(NullPow(k:Nsegments:end).^2);
end
SegRank = SegTimeErr + (SegPow/mean(SegPow))*TimeTolScale.^2;
[Y,TimeSeg] = min(SegRank);	%Choose a time segment
%Average the time syncs from these time segments to estimate
%overall timing
Times = IndNull(TimeSeg:Nsegments:end);
%rem(Times,FrmLength)
StartTime = mean(rem(Times,FrmLength));
%Error = Offset-StartTime;

%Need to remove duplicate nulls, which are caused by nulls at the segment boundaries
%Due to the noisy signal nature make sure ripples in the null don't cause duplicates
%NullPosTol = round(SyncGap/5);
%ind = find(diff(IndNull)>=NullPosTol);

