function y = freqoff(x,freqoffset)
%FREQOFF frequency offset a complex time waveform
%y = freqoff(x,freqoffset)
%x - signal to apply the frequency offset (must be complex)
%freqoffset - frequency shift, as fraction of sample frequency
%

%Copyright Eric Lawrey 23/7/2001

if nargin<2
   error('Number of inputs must be two, x - signal vector, freqoffset - frequency offset');
end

%Frequency offset is normalised to the subcarrier spacing
if abs(freqoffset) > 10*eps
   if (size(x,1)>1)&(size(x,2)==1)
      x = x.';
      rotflag = 1;
   else
      rotflag = 0;
   end
   %FreqFs = FreqOff/(IFFTsize);	%Find the Error as a fraction
   %                              of the sample rate
%   I = sin(2*pi*(1:length(x))*(-freqoffset));
%   Q = cos(2*pi*(1:length(x))*(-freqoffset));
   I = cos(2*pi*(1:length(x))*(freqoffset));
   Q = sin(2*pi*(1:length(x))*(freqoffset));
   Yoff = I+i*Q;
   
   y = x.*Yoff;
   if rotflag 
      y = y.';
   end
   
else
   y = x;
end
