function Data = iq2data(IQinput,ModType,DiffFlag);
%IQ2DATA Maps data in the IQ domain back to data points
% It uses a optimal detector, i.e. finds the data location which is the
% closest to the IQ vector input. This algorithm is general purpose
% but not efficient for modulation schemes with many IQ locations, such as
% 4096QAM. 
%
% Data = IQ2DATA(IQinput,ModType,DiffFlag);
% IQinput - vector of IQ points as complex numbers. If IQinput is a matrix the 
%   the demodulation will be done for each element in the matrix
% Modtype - Modulation type used
%   The following modulation schemes are supported:
%   'BPSK', Binary phase shift keying
%   'QPSK', Quadrature phase shift keying
%   'S8QAM', Square mapping of 8QAM
%   '8QAM', Optimal IQ mapping
%   '16QAM', '32QAM', '64QAM', '128QAM', '256QAM','512QAM','1024QAM','2048QAM',
%   '4096QAM', '8PSK', '16PSK', '32PSK', '64PSK','128PSK', '256PSK'
%
% Square modulation schemes such as '16QAM', '64QAM','256QAM','1024QAM', and
% '4096QAM', have a fast demodulator due to the regular mapping. Odd number of
% bit modulation schemes such as 512QAM use a much slower algorithm (~10-50 
% times slower).
%
% DiffFlag - Indicate if differential encoding was used. This is simply used
%   to indicate whether the constellation should use gray coding, or be
%   cyclic in the I axis and the Q axis. This does not perform the differential
%   decoding.
%
% See also DATA2IQMAP for allowable modulation schemes
%
% Copyright Eric Lawrey March 2001

% 22/3/01
% Updated iq2data to allow matrix inputs to be processed correctly
%
% 23/3/01
% Added a fast demodulator for square QAM modulation schemes.
if nargin < 3
   DiffFlag = 0;
end

[IQMap, BitHz, GrayCode] = data2iqmap(ModType,DiffFlag);
Data = zeros(size(IQinput));

%This algorithm is only faster for 1024QAM and 4096QAM.
SquareQAM = {'16QAM','64QAM','256QAM','1024QAM','4096QAM'};
SquareFlag = ~isempty(find(strcmp(SquareQAM,upper(ModType))));
if SquareFlag
   SigPeak = max(real(IQMap));
   IQinput = IQinput/SigPeak;		%Normalise the input so that the square goes from -1 to 1
   Iloc = 2^(BitHz/2);				%Number of columns of IQ points
   %Now data has to be separated from the I and Q directions
   
   MSN = clip(round(real(IQinput)*(Iloc-1)/2+((Iloc-1)/2+1))-1,0,Iloc-1); %Most significant nibble
   
   LSN = clip(round(imag(IQinput)*(Iloc-1)/2+((Iloc-1)/2+1))-1,0,Iloc-1); %Least Significant nibble
   %Now data has to be separated from the I and Q directions
   %      MSN = real(IQData);	%Most significant nibble
   %      LSN = imag(IQData);	%Least Significant nibble

   Data = MSN*(2^(BitHz/2))+LSN;
   Gray2 = reshape(GrayCode,2^(BitHz/2),2^(BitHz/2))';
   Gray3 = Gray2(:)';
   Gray4 = zeros(size(Gray3));
   Gray4(Gray3+1) = 0:((2^(BitHz))-1);
   %Gray2 = zeros(size(GrayCode));
   %GrapMap is the data to go at each successive location around the
   %phase circle. So for each data value, find its position on this
   %gray mapped circle. These positions are then the lookup indexes
   %to put the IQ vectors in the correct spot.
   %for k = 1:length(GrayCode)
   %   Gray2(k) = find((k-1)==GrayCode);
   %end
   Data = Gray4(Data+1);
else
   
   sz = size(IQinput);
   IQinput = reshape(IQinput,1,length(IQinput(:)));	%Make into a row vector
   
   newver = 1;
   if newver
      %   disp('new version')
      %Break the input data in chunks and process it in a vector format.
      %we can't process the whole input data in vector due to the
      %large memory requirements.
      MaxElem = 1e6;		%Max number of elements to process in vector form. This is to limit
      %						 the amount of memory used.
      %totelem = length(IQMap)*IQinput;	%Total number of calcs & elements for all results
      InputLength = length(IQinput(:));				%Number of input samples
      ChunkLength = floor(MaxElem/length(IQMap));		%Number of input samples to Process in one chunk
      Nchunks = ceil(InputLength/ChunkLength);	%Number of chunks of data to process
      %Make a copy of the input map, but make it a rectangular matrix where the IQMap
      %is a column and all columns are the same. 
      IQMapRect = repmat(IQMap.',1,min(ChunkLength,InputLength));
      for k = 1:Nchunks
         ChunkIndex = (k-1)*ChunkLength+1:min(k*ChunkLength,InputLength);
         IQchunk = IQinput(ChunkIndex);	%Select a
         %							chunk of data. Make sure not to go over the length of the input array
         
         IQrep = repmat(IQchunk,length(IQMap),1);	%Replicate the Input data chunk so that each column
         %							is one IQ data point, and all data in the rows is the same. 
         if k == Nchunks
            %Trim the IQMapRect to match the size of the data. This trimming needs doing
            %only for the last block of data.
            IQMapRect = IQMapRect(:,1:size(IQchunk,2));	%Store the result back in IQMapRect as it is the 
            %														 last block of data
         end
         [Y,I] = min(abs(IQrep-IQMapRect));		%Subtract the two rectangular arrays. This measures the 
         %						distance the input IQ data is to each constellation point, abs(IQrep-IQMapRect),
         %						in the modulation scheme. Then choose the one which is the minimum distance.
         %						Do all these in one statement to minimise memory useage.
         Data(ChunkIndex) = I-1;
      end
   else   
      %disp('old version')
      for k= 1:length(IQinput)
         Dist = abs(IQinput(k)-IQMap);		%Find the distance from the input IQ signal to all
         %											the constellation points of the modulation scheme
         %											Pick the one which is the closest
         [Y,I] = min(Dist);
         Data(k) = I-1;
      end
   end
   
   Data = reshape(Data,sz);
end
