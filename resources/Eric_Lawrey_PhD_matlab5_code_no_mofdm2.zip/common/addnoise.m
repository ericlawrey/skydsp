function [Y,N] = addnoise(X,SNR,varargin)
%ADDNOISE adds white noise to the input waveform to a specified SNR
% Y = addnoise(X,SNR) 
% This functions adds white noise to the input waveform X. Noise is added
% so that the output Signal to Noise Ratio (SNR) matches the specified
% SNR. The SNR is specified in dB. The calculation of the SNR assumes that
% in input signal uses the entire spectrum. If the input signal is 
% complex then complex noise is added. If X is a matrix, each column
% will have noise added to it. The noise is based on the global RMS
% power of the whole matrix
% 
% Y = addnoise(X,SNR,BW)
% BW specifies the percentage bandwidth that the signal uses. This can be
% used to scale the spectral noise density so that the total noise in the
% BW used by the signal will give the correct SNR. For example:
% Assume a system which uses a real time waveform (no imaginary components) 
% and 20 OFDM carriers generated from a 64 point IFFT. This means that the 
% OFDM waveform is 20/(64/2) = 0.625 or 62.5% of the nyquist bandwidth. 
% The nyquist bandwidth is half the number of points in the IFFT because the
% signal is real. Thus BW should be set to 0.625. Noise is be added over 
% the entire nyquist bandwidth however if a matched receiver is used it will 
% only see 62.5% of it, thus the need to increase the amount of noise to 
% maintain the correct SNR. Wideband noise = NoiseReq/BW, where NoiseReq
% is the nosie required to give the desired SNR.
% 
% [Y, N] = addnoise(...)
% N is the noise that was added to the input signal
%
% Detrend can be applied to the input signal Y before estimating the signal 
% power. This removes the DC component. If you want the detrend to
% be applied use [..] = addnoise(...,'D'). In fact, any string will work.
% Detrending the slows the processing significantly. 
%
% A benchmark can be generated using t0001_bench('addnoise')
%
% See also RANDN, DETREND
%
% This code is part of the OFDM toolkit as is subject to conditions of use
% see licence.txt

%   Author(s): Eric Lawrey
%   Copyright (c) 2000 by Triwave DSP Inc.
%   $Revision: 1.0 $  $Date: 30/10/2000 $
%   New code
%   $Revision: 1.1 $  $Date: 31/10/2000 $
%   Modified by Eric Lawrey
%   Tested the code and optimised for speed by group processing into
%   complex and real inputs, and also for detrend or no detrend
%   $Revision: 1.2 $  $Date: 6/11/2000 $ 
%   Modified by Eric Lawrey
%   Was missing a DetrendFlag definition for when the varargin was
%   of length 1 and wasn't a string
%   $Revision: 1.3 $  $Date: 7/11/2000 $  Modified by Eric Lawrey
%   Changed the SNR calculation for matrix inputs from processing
%   columns indepently to using global matrix power. Processing
%   each column separately was causing slight BER errors in
%   OFDM simulations.
%   $Revision: 1.4 $  $Date: 5/7/2001 $ Modified by Eric Lawrey
%   Mistake in the function description text, had [N,Y] = addnoise(...
%   should be [Y,N] = addnoise(...

msg = nargchk(2,3,nargin);	%Check number of inputs
if ~isempty(msg)
   error(msg)
end

switch length(varargin)
case 0
   DetrendFlag = 0;
   BW = 1;				%Assume signal bandwidth matches the nyquist bandwidth
case 1
   if isstr(varargin{1})
      DetrendFlag = 1;
      BW = 1;
   else
      BW = varargin{1};
      DetrendFlag = 0;
   end
case 2
   if isstr(varargin{2})
      DetrendFlag = 1;
   else
      error('Fourth Argument makes no sense');	%Shuold never get here
   end
   BW = varargin{1};
end

%Calculate the mean signal power. Perform detrend and power measurement in one
%step to minimise memory useage
if ~isreal(X)
	if DetrendFlag == 1
      SigPow = mean(mean(abs(detrend(X,'constant').^2)));
      %input signal is complex so add complex noise
	   Noise = detrend(randn(size(X))+i*randn(size(X)),'constant');
	else
      SigPow = mean(mean(abs(X).^2));
      %input signal is complex so add complex noise
	   Noise = randn(size(X))+i*randn(size(X));
   end
   
   %Measure the noise power (The noise power should be 1 on average, but 
	%for small sample sets it might vary)
	NoisePow = mean(mean(abs(Noise).^2));	%Take the abs to get correct results with complex numbers
else
   if DetrendFlag == 1
      SigPow = mean(mean((detrend(X,'constant')).^2));
      Noise = detrend(randn(size(X)),'constant');
	else
      SigPow = mean(mean((X).^2));
      Noise = randn(size(X));
   end
   
   %Measure the noise power (The noise power should be 1 on average, but 
	%for small sample sets it might vary)
	NoisePow = mean(mean((Noise).^2));	%Take the abs to get correct results with complex numbers
end

%SigPow and NoisePow will be vectors for matrix input and scalar for a vector input
%Scale the noise to give the correct SNR when the noise is added to the input signal
SNRlin = 10.^(SNR/10);	%SNR in linear
NoiseScale = sqrt(SigPow./(SNRlin.*NoisePow.*BW));
%Noise = Noise.*(ones(size(Noise,1),1)*(NoiseScale));	%Scale the noise. 
Noise = Noise*NoiseScale;	%Scale the noise. 

%																	 (Use 'Noise' again to save memory)

%Add the noise to the signal
%disp(['In addnoise Calc SNR: ' num2str(10*log10(mean(abs(X).^2)/mean(abs(Noise).^2))) 'dB'])
Y = X+Noise;
if nargout > 1
   N = Noise;
end
