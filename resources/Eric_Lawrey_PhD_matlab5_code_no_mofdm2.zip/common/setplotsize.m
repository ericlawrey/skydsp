function setplotsize(horz,vert,xoff,yoff)
%SETPLOTSIZE Sets the size of a plot in pixels
% setplotsize(horz,vert)
% sets the plot size to 'horz' number of horizontal pixels, and 'vert'
% number of vertical pixels
%
% setplotsize(horz,vert,hoffset,voffset)
% hoffset, and voffset, set the horizontal and vertical offset position
% of the window. If unspecified the default values are 10 and 40 
% respectively
if nargin < 4
   yoff = 40;
end
if nargin < 3
   xoff = 10;
end

maxsize = [xoff yoff horz vert];
set(gcf,'position', maxsize)