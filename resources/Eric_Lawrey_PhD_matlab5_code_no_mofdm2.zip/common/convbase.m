function  DataOut = convbase(DataIn,CurrBase,NewBase,SignedFlag)
%CONVBASE Converts the number base of the input data (DataIn)
%	DataOut = convbase(DataIn,CurrBase,NewBase)
%	from the current base (CurrBase) to the new base required
%	(NewBase). If the new base is less the the old base, e.g
%	NewBase = 2 and CurrBase = 8, the DataOut will have more
%	data words. For the above example DataOut will be 4 times
%	longer then DataIn.
%	The actual base used = 2^NewBase, thus NewBase = 8, is base 256
%	E.g. DataIn = [ 2 64 20 ] with CurrBase = 8, NewBase = 2
%  DataOut = convbase([2 64 20],8,2), results in
%	DataOut = [2 0 0 0, 0 0 0 1, 0 1 1 0]
%
%  a = convbase([2 64 20]',8,2)
%  a =[2     0     0     0
%      0     0     0     1
%      0     1     1     0]
%  
%  DataOut = convbase(DataIn,CurrBase,NewBase,SignedFlag)
%  SignedFlag indicates whether the data is signed (1) or
%  unsigned data (0). The default is for unsigned data if
%  SignedFlag is not supplied.
%
%  Note: conversion from a small base (eg 1 bit) to a larger base 
%  (eg 8 bits) has only been tested for unsigned data.
%
%  Copyright Eric Lawrey (c) Sept 2000, Eric.Lawrey@jcu.edu.au

%6/3/01
%Modified so that conversion can be specified has signed or unsigned.
%The signed version only works for converting from a larger
%to smaller base.
%
% 20/3/01
% Modified convbase so that when a column DataIn is given the output
% data has one output per row, with the converted output in columns.

if nargin < 4
   SignedFlag = 0;
end

%====================================
% Convert the number base of the data
%====================================
if CurrBase > NewBase,
   %Convert the input data into the base (NewBase) required
   if size(DataIn,2)>1
      if size(DataIn,1) > 1
         disp(['DataIn size : ' num2str(size(DataIn))])
         error('DataIn must be a vector not a matrix')
      end
      
      leftover = DataIn';
   else
      leftover = DataIn;
   end
   
   DataOut = zeros(size(leftover,1),CurrBase/NewBase);
   %DataOut = [];		%1. This is legasy code, if the vector code fails, change it back
	for k = 1:(CurrBase/NewBase)
      DataOut(:,k) = rem(leftover,2^NewBase);
      %DataOut = [ DataOut rem(leftover,2^NewBase)];  %2. Second line, legasy code
		leftover = floor(leftover./(2^NewBase));
   end
   if size(DataIn,2)>1
      DataOut = reshape(DataOut',1,size(DataOut,1)*size(DataOut,2));
   end
   
   if SignedFlag==1
      I = find(DataOut>2^(NewBase-1));
   	DataOut(I) = DataOut(I)-ones(size(I))*2^(NewBase);
   	I = find(DataOut<-(2^(NewBase-1)));
      DataOut(I) = DataOut(I)+ones(size(I))*2^(NewBase);
   end   
elseif CurrBase < NewBase,
	%=======================
	%Convert back to decimal
	%=======================
	remainder = rem(size(DataIn,2),NewBase/CurrBase);
	if (remainder > 0),
		disp('WARNING : Received data length problem when converting base');
		disp('Clipping data to make possible');
		DataIn = DataIn(1:size(DataIn,1)-remainder);
	end
	Datawords=reshape(DataIn',NewBase/CurrBase,size(DataIn,1)*size(DataIn,2)/...
		(NewBase/CurrBase))';
	DataOut = zeros(size(Datawords,1),1);
	for k = 1:(NewBase/CurrBase)
		DataOut = DataOut+Datawords(:,k)*(2^CurrBase)^(k-1);
	end
	DataOut = DataOut.';
else
	DataOut = DataIn;	%No change of base.
end
