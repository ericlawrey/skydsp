function c4 = coppernew(A,m)
%COPPERNEW Modified copper-tone color map.
%   COPPERNEW(A,M) returns an M-by-3 matrix containing a "copper" colormap.
%   COPPERNEW, by itself, is the same length as the current colormap.
%	 A is a colour map modifier with a typical range from 0.5 - 1.5.
%   This colour map goes from a dark red purple through to a pale yellow 
%   For example, to reset the colormap of the current figure:
%
%             colormap(coppernew)
%
%   See also COPPER, HSV, GRAY, HOT, COOL, BONE, PINK, FLAG, 
%   COLORMAP, RGBPLOT.

%Eric Lawrey, modified from the original COPPER colormap to improve
%linearity of the mapping

if nargin < 2, m = size(get(gcf,'colormap'),1); end
if nargin < 1, A = 1; end

c = min(1,gray(m)*diag([1 1 0.55])); %[1.2500 0.7812 0.55]));
c(:,3) = max(c(:,3)-0.25,0);
c(:,2) = max(c(:,2)-0.4,0);
ind = round(m*0.5);
cg = c(ind,2);
c(ind:m,2) = min(1,c(ind:m,2)+(1.5*((c(ind:m,2))-cg)).^3);
ind2 = round(m*0.8);
cb = c(ind2,3);
c(ind2:m,3) = min(1,c(ind2:m,3)+(6*((c(ind2:m,3))-cb)).^3);
c2 = sign(c-0.5).*((abs(c-0.5)).^A);
c3 = c2/(max(max(c2))-min(min(c2)));
c4 = c3-min(min(c3));