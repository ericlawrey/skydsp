function psdavg(X,NFFT,Fs,WINDOW,NOVERLAP)
%PSDAVG Estimates the power spectral density.
% psdavg(X,NFFT,Fs,WINDOW,NOVERLAP)
% The power spectral density is estimated by taking the average of 
% the spectrograph of the signal. 
if nargin < 2
   NFFT = 512;
end
if nargin < 3
   Fs = 1;
end
if nargin < 4
   WINDOW = lawrey5(NFFT);
end

if nargin < 5
   NOVERLAP = NFFT/2;
end

[B,F,T] = specgram(X,NFFT,Fs,WINDOW,NOVERLAP);
plot(F,20*log10(mean(abs(B.'))));
xlabel('Frequency (Hz)');
ylabel('Power (dB)');