function r = randns(N,M,S)
%This function is the same as randn except that multiple gaussian random numbers are
%multipled together to produce a random number with a high probability of being near zero,
%and a small probability of being large. Multipling the random numbers make the standard deviation
%the same but the probability of large variations is increased
r1 = randn(N,M);
r = sign(r1).*(abs(r1).^S);
%for k = 1:(S-1)
%   r = r.*randn(N,M);
%end