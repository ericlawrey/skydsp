function B = gauss2D(N,s)
%GUASS2D returns a guassian 2D filter
%B = gauss2D(N,s)
%	N size of the filter (returns an N x N matrix)
%	s standard deviation, sets how wide the filter is
%
%Copyright Eric Lawrey April 2001

%27.12.00
%Fixed up so that guass2D would give the correct size filter
[x,y] = meshgrid(linspace(-N/2,N/2,N),linspace(-N/2,N/2,N));
r = sqrt(x.^2+y.^2);
B1 = exp(-(r.^2)/(2*s.^2));
B = B1/sum(sum(B1));