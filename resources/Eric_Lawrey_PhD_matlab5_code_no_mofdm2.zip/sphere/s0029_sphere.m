%This script creates two plots to demonstrate the expansion of RF waves.
%The first plot is simply a sphere with a section cut out to show the 
%transmitter in the centre. The second shows the concentrated energy
%on the surface of the sphere when using a high gain antenna.
clear all
scriptnum = 's0029_';		%Number of this script (added to plot
%									filenames)
k = 5;	%The Grid size is 2^k*2^k, cax needs to changed when k is changed.
n = 2^k-1;
theta = pi*(-n:2:n)/n;
phi = (pi/2)*(-n:2:n)'/n;
%Calculate the coordinates of a sphere
X2 = cos(phi)*cos(theta);
Y2 = cos(phi)*sin(theta);
Z2 = sin(phi)*ones(size(theta));

%Cut out a section of the sphere by setting the X,Y & Z
%values to NaN. X, Y & Z are 2D arrays so first find the 
%indices for the area to remove
horz = size(X2,2);
vert = size(X2,1);
rows = ceil(vert*(1/2+0.0001)):ceil(vert*(1));
cols = ceil(horz*(5/16)):ceil(horz*(13/32));
X3 = X2*0.1;
Y3 = Y2*0.1;
Z3 = Z2*0.1;

X2(rows,cols) = NaN*ones(length(rows),length(cols));
Y2(rows,cols) = NaN*ones(length(rows),length(cols));
Z2(rows,cols) = NaN*ones(length(rows),length(cols));

%Use Gray colour map as the
colormap(hot)
%Use a 2D gaussian shape as the coloring of the sphere
%This results in a bright central area, simulating an
%antenna with a high gain
beamwidth = [5 13];		%Broadness of the beam. (Actually the 
% standard deviation of the guassian shape, in samples)
% High gain  = 4-6, Almost Omnidirectional = 12-18
% An array of values will result in multiple plots
PlotNames = {'highgain','omni'};	%Name of the plot
cax = {[0 0.0065],[0 0.005]};		%Colour axis to use on each plot
LineFlag = [1 0];		%Flag to indicate whether to plot the antenna
%							 direction arrow line
for k = 1:length(beamwidth)
   clf
   C = (gauss2D(size(X2,1),beamwidth(k)));
   
   surf(X2,Y2,Z2,C)
   axis square
   view(45,15)
   caxis(cax{k})
   hold on
   axis manual
   
   if LineFlag(k)
      h3 = plot3([0 1.6],[0 0],[0 0],'b-');	%Draw a line from the Tx outward in direction
      % of high antenna gain   
      h4 = plot3([1.6],[0],[0],'b>');   	%Add a triangle to the end of the line (like and arrow)
      set(h4,'markerfacecolor',[0 0 1],'markersize',16); %Fill in the triangle on the end of the line	
      set(h3,'linewidth',4);
   end
   
   plot3(0,0,0,'xc','markersize',28,'linewidth',5)
   g = get(gcf,'currentaxes');
   set(gcf,'color',[1 1 1])
   set(g,'position',[-0.1 -0.1 1.2 1.2]);
   set(gcf,'position',[10 35 725 658]);
   axis off
   hold off
   savefig([scriptnum PlotNames{k}],{'tif','jpg'})
end
