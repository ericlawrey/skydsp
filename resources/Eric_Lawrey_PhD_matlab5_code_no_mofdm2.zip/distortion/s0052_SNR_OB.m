%This simulation plots the Effective SNR of and OFDM as a function of Output Power
%Backoff from 0 to 9.5 dB, for three different number of carriers. 
%
%===========================
%	Default Variabels
%===========================
Nsymbol = 300;				%Number of Symbols to simulate (default)
Ntrials = 2;				%Number of Trials to average the results over. Lowering Nsymbol
%								and increasing Ntrials can be used to minimise the memory useage
%								Memory useage ~(Nsymbol+NumRefSymb)*(IFFTsize+GuardPeriod)*8(bytes 
%								per number)*2(complex)*2(working memory) in Bytes
Ncarriers = 64;			%Number of carriers to use
IFFTsize = 128;			%Size of the IFFT used to generate the OFDM signal
RealComplex = 'complex';	%Whether to generate a 'real' or 'complex' OFDM signal
GuardPeriod = 32;			%Length of the guard period in samples
fast_mode = 0;				%Enabling the fast mode in OFDMMOD (see help ofdmmod)
PreClipDistFlag = 0;		%Preclip the signal before bandpass filtering. This is
%								to reduce out-of-band spectral spreading caused by
%								distortion in the PA.
PreOutBackoffdB = 6;		%Output power backoff in dB

%								This simulates distortion in the Power Amp (PA)
ClipDistFlag = 1;			%Whether to enable clipping distortion on the signal
OutBackoffdB = 6;			%Output power backoff in dB
BPFilterFlag = 0;			%Flag to enable bandpass filtering of the signal (1) - enabled 
%								(0) - no filtering
TransWidth = 4;			%TransWidth is the transition width of the window function
%								This determines the out of band attenuation 
FiltWidth = 8; 			%FiltWidth width of the bandpass filtering to first null

%Filter in the recevier
RxBPFilterFlag = 0;			%Flag to enable bandpass filtering of the signal (1) - enabled 
%								(0) - no filtering
RxTransWidth = 4;			%TransWidth is the transition width of the window function
%								This determines the out of band attenuation 
RxFiltWidth = 8; 			%FiltWidth width of the bandpass filtering to first null

%TimeOffset = -GuardPeriod/(IFFTsize+GuardPeriod)/2;			%Time Offset error as fraction of total symbol time (ifft & guard)
TimeOffSymbScaleFlag = 1;	%(1) Scale the time offset data as a fraction of the symbol period
%								(0) Use TimeOffset in units of samples

TimeOffset = 0;			%Time Offset error in samples (integer)
SNRdB = 2000;				%Channel SNR for AWGN in dB
RefScheme = 0;				%Type of pilot symbol used
PilotPowBoost = 1;		%Power boosting of the pilot power
NumRefSymb = 8;			%Number of pilot symbols to use
legend_flag = 1;					%Enable (1) or Disable plotting of the legend
title_text = '';
axis_range = [0 9.5 0 80];	%Plot axis range
xticks = [0:1:10];		%Xticks marks to put on the plot
yticks = [0:10:80];
MarkerSpacing = 5;		%Spacing between the markers
plot_filename = 's0052_effSNR_OBO_Ncarrs';	%File name of the plot generated
SavePlotFlag = 0;
%=====================================
%	Loop Variables
%=====================================
%The loop variables overwrite the default values
LoopVariable = 'OutBackoffdB';		%X axis Loop Variable
LoopList = [0.5:0.5:9.5];
LoopList = [4:0.5:7];
LoopVariable2 = 'Ncarriers';
LoopList2 = [8 64 512 1700];
LockVariables2 = {'IFFTsize', 'Nsymbol','Ntrials'};	%This variable will also change with LoopVariable2
LockValues2 = {[16 128 1024 2048], [2000 500 200 100], [8 4 2 1]};	%These are the values the lock variables will take
%																		The length of each array must match the LoopList length

LoopVariable2 = 'Ncarriers';
LoopList2 = [1700];
LockVariables2 = {'IFFTsize', 'Nsymbol','Ntrials','BPFilterFlag'};	%This variable will also change with LoopVariable2
LockValues2 = {[2048], [200], [2],[0]};				%These are the values the lock variables will take
%																		The length of each array must match the LoopList length


legend_pos = 2;					%Position of legend, See help legend

s0051_effSNR