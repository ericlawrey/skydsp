%This simulation plots the Effective SNR of and OFDM as a function of Output Power
%Backoff, for different pilot refence scheme
%===========================
%	Default Variabels
%===========================
Nsymbol = 100;				%Number of Symbols to simulate (default)
Ntrials = 8;				%Number of Trials to average the results over. Lowering Nsymbol
%								and increasing Ntrials can be used to minimise the memory useage
%								Memory useage ~(Nsymbol+NumRefSymb)*(IFFTsize+GuardPeriod)*8(bytes 
%								per number)*2(complex)*2(working memory) in Bytes
Ncarriers = 64;			%Number of carriers to use
IFFTsize = 128;			%Size of the IFFT used to generate the OFDM signal
RealComplex = 'complex';	%Whether to generate a 'real' or 'complex' OFDM signal
GuardPeriod = 0;			%Length of the guard period in samples
fast_mode = 0;				%Enabling the fast mode in OFDMMOD (see help ofdmmod)
ClipDistFlag = 1;			%Whether to enable clipping distortion on the signal
OutBackoffdB = 10;			%Output power backoff in dB
TimeOffset = 0;			%Time Offset error in samples (integer)
SNRdB = 25;					%Channel SNR for AWGN in dB
%SNRdB = 50;					%Channel SNR for AWGN in dB
RefScheme = 2;				%Type of pilot symbol used
%							    0 - S. Narahashi and T. Nojima phasing scheme
%   							 1 - Use the low crest factor phasing scheme developed
%     					   using genetic algorithms. This algorithm only allows
%        					for carrier numbers which have been simulated and stored
%        					in s0019_low_CF_DMT_phase_table.mat.
%    							2 - Use random phase angles
PilotPowBoost = 1;		%Power boosting of the pilot power
NumRefSymb = 1;			%Number of pilot symbols to use
title_text = ['AWGN SNR: ' num2str(SNRdB) ' dB, ' num2str(Ncarriers) ' carriers'];
MarkerSpacing = 5;		%Spacing between the markers
plot_filename = 's0054_SNR_phref';	%File name of the plot generated
SavePlotFlag = 0;
%=====================================
%	Loop Variables
%=====================================
%The loop variables overwrite the default values
LoopVariable = 'OutBackoffdB';		%X axis Loop Variable
LoopList = [0.5:0.5:12];

LoopVariable2 = 'PilotPowBoost';
LoopList2 = [1 4 4 4];
LockVariables2 = {'RefScheme'};				%This variable will also change with LoopVariable2
LockValues2 = {[1 0 1 2]};					%These are the values the lock variables will take
%										the length of each array must match the LoopList length

%LoopVariable2 = 'PilotPowBoost';
%LoopList2 = [4 4 ];
%LockVariables2 = {'RefScheme'};				%This variable will also change with LoopVariable2
%LockValues2 = {[0 1]};					%These are the values the lock variables will take
%										the length of each array must match the LoopList length
axis_range = [min(LoopList) max(LoopList) 0 SNRdB];	%Plot axis range
xticks = round(min(LoopList):max(LoopList));
yticks = 0:2:SNRdB;
legend_flag = 1;					%Enable (1) or Disable plotting of the legend
legend_pos = 4;					%Position of legend, See help legend

s0051_effSNR