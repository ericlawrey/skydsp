two_tone_flag = 1;		%Two tone distortion test (1), BPSK single carrier distortion test (0)
OB = 5;						%Output back off (dB)
PlotFFT = 8192;			%FFT size for plotting the result
c = sin((0:(2^19-1))*2*pi*0.055);
if two_tone_flag == 0
	a = round(rand(1,1024))*2-1;
	b = reshape(repmat(a,512,1),1,2^19);
	B=fir1(4096,1/512,blackh4(4097));
   bf = fftfilt(B,b);
   d = b.*c;
else
   c2 = sin((0:(2^19-1))*2*pi*0.06);
   d = (c+c2);
end
dc = clipdist(d,OB);
psd(dc,PlotFFT,1,lawrey5(PlotFFT));
ylim([-40 33]);
setplotstyle(1,0.8)
set(gca,'linewidth',1.5)
%savefig('s0049_2toneIMD')