IFFTsize = 256;
Nsymbols = 10;
Ncarriers = 128;
GuardPeriod = 0;
RealComplex = 'complex';
fast_mode = 0;
OutBackoffdBlist = [-15:1:11];
MeasOBO = zeros(1,length(OutBackoffdBlist));
for k = 1:length(OutBackoffdBlist)
   OBO = OutBackoffdBlist(k);
   %Create random QAM data with a peak amplitude of 1.
   IQ = (rand(Ncarriers,Nsymbol)*2-1+i*(rand(Ncarriers,Nsymbol)*2-1))/sqrt(2);
   IQ = IQ/mean(mean(abs(IQ)));	%Make the mean carrier power = 1;
   carriers = mkcarriers(Ncarriers,IFFTsize,RealComplex);
   outsymbol = ofdmmod(IQ, carriers, IFFTsize, GuardPeriod, ...
      RealComplex, fast_mode);
   OutBackoff = 10^(OBO/10);
   AvgPow = mean(mean((abs(outsymbol).^2)));			%average signal power
   PeakAmpClip = sqrt(AvgPow.*OutBackoff);	%Peak amplitude to clip to
   %Clip the signal to the guess
   Y = clip(outsymbol,PeakAmpClip);	
   %Measure the OBO, which is the peak to average power ratio
   MeasOBO(k) = (max(max(abs(Y))).^2)/mean((mean(abs(Y).^2)));
   disp([num2str(k) ' of ' num2str(length(OutBackoffdBlist))])
end
plot(OutBackoffdBlist,10*log10(MeasOBO))
xlabel('Input power clipping (dB)')
ylabel('Output Power Back off (dB)')
IBO = OutBackoffdBlist;
OBO = 10*log10(MeasOBO);
save('IBO_OBO.mat','IBO','OBO');

