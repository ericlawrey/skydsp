%s0047_plotdist This script collates and plots the results from s0041_distref1,2,3,4
%These simulations show the effect of clipping on the BER for 16QAM at a EBNR of 11dB.
%s0041_distref1.mat
%This shows the performance with only a single reference symbol. This has no 
%power boosting on the reference symbol resulting in good performance at low output 
%back offs, by results in high residule BER due to the poor channel characterisation 
%in the presence of noise.
%1 reference symbols
%1 x Power Boost
%GA low CF reference
%EBNR = 12dB, ideally should have residule BER of about 2e-4
%
%s0041_distref2.mat
%This shows the performance with only a single reference symbol. Here the power have 
%been boosted in the reference symbol by 4 times to reduce the residule BER. This is 
%using GA evolved low CF references so this should work better than other phase 
%references at this amount of power boosting.
%1 reference symbols
%4 x Power Boost
%GA low CF reference
%EBNR = 12dB, ideally should have residule BER of about 2e-4
%
%s0041_distref3.mat
%This shows the performance with only a single reference symbol. Here the power have 
%been boosted in the reference symbol by 4 times to reduce the residule BER. This is 
%using S. Narahashi and T. Nojima phasing scheme on the phase reference.
%1 reference symbols
%4 x Power Boost
%S. Narahashi and T. Nojima phasing scheme
%EBNR = 12dB, ideally should have residule BER of about 2e-4
%
%s0041_distref4.mat
%This is a reference to show the lower limit in the error rate verses output backoff.
%8 reference symbols
%1 x Power Boost
%GA low CF reference
%EBNR = 12dB, ideally should have residule BER of about 2e-4
%i.e.
% If no output is used DATA2IQMAP plots the IQ plot instead of generating the output 
% table.
% i.e. DATA2IQMAP('32QAM')
% will generate a plot of 32QAM
%
% Contents of s0041_coh_qam are:
%  BERall               85x12          8160  double array
%  BitSimThreshold       1x1              8  double array
%  BitsReq               1x1              8  double array
%  DiffFlag              1x1              8  double array
%  DispRate              1x1              8  double array
%  EBNRIndex             1x1              8  double array
%  EBNRdB                1x85           680  double array
%  GuardPeriod           1x1              8  double array
%  IFFTsize              1x1              8  double array
%  InLineChanChar        1x1              8  double array
%  MaxRuns               1x1              8  double array
%  MaxTests              1x12            96  double array
%  ModCatergory          1x19           152  double array
%  ModIndex              1x1              8  double array
%  ModNumberList         1x12            96  double array
%  ModType               1x19          1952  cell array
%  ModsUsed              1x12          1236  cell array
%  Ncarriers             1x1              8  double array
%  Nconstellation        1x19           152  double array
%  Ntaps                 1x1              8  double array
%  NumRefSymb            1x1              8  double array
%  NumRuns               1x1              8  double array
%  Nwords                1x1              8  double array
%  NwordsUsed           85x12          8160  double array
%  OFDMflag              1x1              8  double array
%  PrevENBRcheck         1x1              8  double array
%  RealComplex           1x7             14  char array
%  RefScheme             1x1              8  double array
%  SERall               85x12          8160  double array
%  SNRtest               1x1              8  double array
%  TotalTime             1x1              8  double array
%  biterrors            85x12          8160  double array
%  decay                 1x1              8  double array
%  dellist               1x3             24  double array
%  delspread             1x1              8  double array
%  errorstotal          85x12          8160  double array
%  fast_mode             1x1              8  double array
%  limits                1x2             16  double array
%  totbitsim             1x1              8  double array
%
% Most of these parameters are stored to make this a restartable
% simulation with separate simulation files.
% The important variables for plotting are:
% EBNRdB - SNR in dB that each BER test was run
% BERall - bit error rate of each modulation scheme. Each mod scheme
% is a different column. The modulation used in each column is
% given by ModsUsed
% ModsUsed - modulation scheme used for each test (cell array of strings)
% SERall - symbol error rate for each modulation scheme
%
% Copyright Eric Lawrey (c) September 2000, Eric.Lawey@jcu.edu.au
BER = [];
CF_list = [];
file_list = {'s0041_distref1', 's0041_distref2', 's0041_distref3','s0041_distref4'};

for k = 1:length(file_list)
	load(file_list{k})
	BER(:,k) = squeeze(BERall);
	[RefSymb, CF] = genref(Ncarriers,RefScheme); %*sqrt(PilotPowBoost);
	CF_list(k) = CF;
end

h = semilogy(OutBackoffdB,BER);
set(h(1),'marker','o','markersize',15)
set(h(2),'marker','^','markersize',15)
set(h(3),'marker','x','markersize',15)
%set(h(1),'marker','.')
%set(h(2),'marker','+')
legend(h,{['(a) Ref:1 Boost:1 CF:' sprintf('%4.2g',CF_list(1)) 'dB'],...
      ['(b) Ref:1 Boost:4 CF:' sprintf('%4.2g',CF_list(2)) 'dB'],...
		['(c) Ref:1 Boost:4 CF:' sprintf('%4.3g',CF_list(3)) 'dB'],...
      ['(d) Ref:4 Boost:1 CF:' sprintf('%4.2g',CF_list(4)) 'dB']},3)
xlabel('Output Power Backoff (dB)')
ylabel('Bit Error Rate')
title('100 carrier, with 16QAM modulation') 
setplotstyle

set(h,'marker','none')
M = 5;
hold on
h2 = semilogy(OutBackoffdB(1:M:end),BER(1:M:end,:),'linestyle','none','linewidth',1.5);
hold off
%setplotstyle
set(h2(1),'marker','o','markersize',15)
set(h2(2),'marker','^','markersize',15)
set(h2(3),'marker','x','markersize',15)
axis tight
ylim([1e-3 0.5])
set(gca,'xtick',[0:1:11]);
%plot_text = {{'BPSK' 'QPSK' '16' '64' '256' '1024','4096'}};
%text_x = {[5.3 10 13.3 17.5 22 26 31]};
%text_y = {[1.4e-4 1.4e-3 ones(1,5)*1.4e-4]};
grid on
savefig('s0047_refdist')
   %Make the font sizes bigger and the lines thicker
%setplotstyle(lw,fs)
%if ~isempty(plot_text)
%   text(text_x{k},text_y{k},plot_text{k},'fontsize',20);
%end
%title(plot_title{k})

%   savefig(plot_filename);




