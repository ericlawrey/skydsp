%This script plots the effect of clipping distortion on the spectrum of 
%OFDM. It shows the spectral spreading caused by distortion. It generates
%two plots, 1. OFDM spectrum, 2. Spectral Spreading verse Output power back 
%off.
FreqPlotCarrs = 64;		%Number of carriers
FreqPlotFFT = 256;		%OFDM IFFT size used to generate the signal
PlotFFT = 1024;			%FFT to use in plotting the graphs
TransWidth = 2;			%Width of the window function used
FiltWidth = 8;				%Width of the filter in carrier spacings
FreqNsymbs = 800;			%Number of symbols to simulate (larger numbers smooth plot)
FilterTaps = TransWidth./FiltWidth;
CarrierSpacing = 1;		%Spacing between the carriers
FlatGuardPeriod = 0;
RaisedCosine = 0;			%Length of the raise cosine section of the guard period in samples
Window = 0;

OutbackoffdB = [2:0.25:10];	%Output power backoffto simulate (-1) means no clipping
OutBOplot = [6.5];		%Output power backoff for plotting the spectrum, must be calculated 
%									in OutbackoffdB

PreClipFlag = 1
PreClipOutbackoffdB = [4 5 6 7 -1];
PowFudge = 6;
OutBandList = [0.5];	%Find the out of band attenuation at these points (normalised to
%			the carrier bandwidth. These are in spacings away from the edge of the system carriers
LegendStr = {};
for k = 1:length(PreClipOutbackoffdB)
   if PreClipOutbackoffdB(k) ~= -1
      LegendStr{k} = ['Pre-Filter OBO: ' num2str(PreClipOutbackoffdB(k)) 'dB'];
   else
      LegendStr{k} = 'No Pre-Filter';
   end
end


%xtext = [-100 -80];
%ytext = [-25 -25];

SavePlotFlag = 1;			%Flag to enable (1) or disable (0) saving of the plots generated

%Calculate legend string for the OFDM spectrum plot with distortion
LegendStrSpec = [];
for k = 1:length(OutBOplot)
   if OutBOplot(k)~=-1
      LegendStrSpec{k} = ['OB: ' num2str(OutBOplot(k)) 'dB'];
   else
      LegendStrSpec{k} = 'No Distortion';
   end
end

mw = zeros(PlotFFT,length(OutbackoffdB),length(PreClipOutbackoffdB));
Index = [];
for k = 1:length(OutBOplot)
   %index(k)
   I = find(OutBOplot(k)==OutbackoffdB);
   if isempty(I)
      error('Value of OutBOplot not found in OutbackoffdB')
   end
   Index(k) = I;
end
%==============================================
%      Frequency Plot of Bandlimited OFDM
%==============================================
for P = 1:length(PreClipOutbackoffdB)
   for D = 1:length(OutbackoffdB)
      if FilterTaps > 0
         %Recalculate the low pass filter for band limiting the complex OFDM signal
         B = fir1(round(FreqPlotFFT*FilterTaps),(FreqPlotCarrs+3)/FreqPlotFFT...
            *(1+0/FreqPlotFFT), kaiser2(round(FreqPlotFFT*FilterTaps)+1, ...
            'width',TransWidth));
      else
         B = 1;
      end
      
      Nsymbs = FreqNsymbs;
      carriers = mkcarriers([FreqPlotCarrs, CarrierSpacing], FreqPlotFFT, 'complex');
      [x,y] = pol2cart(rand(FreqPlotCarrs,Nsymbs)*2*pi,ones(FreqPlotCarrs,Nsymbs));
      datavector = x+i*y;
      
      %Length of the total symbol time including the guard period
      SymbolLength = FreqPlotFFT+round(RaisedCosine.*FreqPlotFFT)*2+FlatGuardPeriod;
      outsymbol = ofdmmod(datavector,carriers, FreqPlotFFT, [FlatGuardPeriod, ...
            RaisedCosine 0],'complex');
      if isstr(Window)
         switch Window
         case 'blackh4'
            w = blackh4(SymbolLength);
         case 'hanning'
            w = hanning(SymbolLength);
         otherwise
            error(['Unsupported window type : ' Window]);
 		   end
      else
         if Window==0
            w = boxcar(SymbolLength);
         else
            w = kaiser2(SymbolLength,'trans',Window);
         end
      end
      w2 = repmat(w,1,Nsymbs);
      outsymbol = outsymbol.*w2;
      %Change the signal from a matrix form (one symbol per column) to a continuous
      %time waveform.
      timesig = reshape(outsymbol,length(outsymbol(:)),1);
      if PreClipFlag&(PreClipOutbackoffdB(P)~=-1)
         timesig = clipdist(timesig,PreClipOutbackoffdB(P));
      end
      %Filter the OFDM waveform. 
      timesig = fftfilt(B,timesig);   %Use same variable to save memory
      if OutbackoffdB(D) ~= -1
         timesig = clipdist(timesig,OutbackoffdB(D));
      end
      
      %Use specgram to get an averaged spectrum.
      W = specgram(timesig,PlotFFT,1,lawrey5(PlotFFT));
      avg_pow = mean(mean(abs(W).^2));
      mw(:,D,P) = 20*log10(fftshift(mean(abs(W/sqrt(avg_pow))')))';
      %   avg_pow = mean(abs(mw(:,D)).^2);
      %   mw(:,D) = mw(:,D);
      BW = FreqPlotCarrs/FreqPlotFFT;
      disp(['Calculated Backoff :' num2str(OutbackoffdB(D)) 'dB, ' num2str(D) ' of ' ...
            num2str(length(OutbackoffdB))])    
   end
end

   mean_carr_pow = mean(mean(mean(mw((-BW*PlotFFT/2+PlotFFT/2+2):(BW*PlotFFT/2+PlotFFT/2),:,:))));
   BinAvg = 2;		%Number of freq bins to average the result over
   mean_side_pow = zeros(length(OutbackoffdB),length(OutBandList),length(PreClipOutbackoffdB));
   T = (BW*PlotFFT*(OutBandList(k)+0.5)+PlotFFT/2);
   mean_side_pow = squeeze(mean(mw(T:T+BinAvg-1,:,:))-mean_carr_pow);

      
      %      MeanPow = mean(mw((PlotFFT/2-BW*PlotFFT/2):(PlotFFT/2+BW*PlotFFT/2)));
   figure(1)
   Freq = linspace(-FreqPlotFFT/2,FreqPlotFFT/2,PlotFFT);
      
      
      mw2 = squeeze(mw(:,Index,:))-PowFudge;
      OB = OutbackoffdB(Index);
      h = plot(Freq,mw2); %-MeanPow);
      %set(h(1),'linewidth',1);
      %set(h(end),'linewidth',4);
      %legend(h,LegendStrSpec,3)
      
      axis tight
      xlabel('Frequency (Carrier Spacings)')
      ylabel('Power (dB)');
      title(['OFDM spectrum for OBO: ' num2str(OutBOplot) 'dB, ' num2str(FreqPlotCarrs) ' carriers']);
      grid on
      ylim([-100 3]);
      legend(h,LegendStr,-1)
      setplotstyle(1.5,0.8,12)
      plotm(h,100)
      
      %text(xtext,ytext,LegendStrSpec,'fontsize',20);
      %set(h(1),'linewidth',1);
      %set(h(end),'linewidth',4);
      %legend
      if SavePlotFlag
         savefig('s0063_distspec');     
      end
      index = find(OutbackoffdB~=-1);
      
      figure(2); h = plot(OutbackoffdB(index),mean_side_pow(index,:));
      xlabel('Output Power Backoff (dB)')
      ylabel('Side Lobe Power (dBc)')
      title('Side Lobe Power, measured 100% of system BW away from centre')
      ylim([-100 -20])
      set(gca,'ytick',-100:10:-20)
      set(gca,'xtick',[1:1:11])
      plotm(h,1)
      legend(h,LegendStr,3)
      grid on
      setplotstyle(1.5,1,15)
      %set(h(2),'markersize',15);
      if SavePlotFlag
         savefig('s0063_OBdist')
      end
      