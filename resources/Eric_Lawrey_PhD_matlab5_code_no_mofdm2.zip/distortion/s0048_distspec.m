%This script plots the effect of clipping distortion on the spectrum of 
%OFDM. It shows the spectral spreading caused by distortion. It generates
%two plots, 1. OFDM spectrum, 2. Spectral Spreading verse Output power back 
%off.
FreqPlotCarrs = 101;		%Number of carriers
FreqPlotFFT = 512;		%OFDM IFFT size used to generate the signal
PlotFFT = 1024;			%FFT to use in plotting the graphs
TransWidth = 3;			%Width of the window function used
FiltWidth = 2;	
FreqNsymbs = 1000;			%Number of symbols to simulate (larger numbers smooth plot)
FilterTaps = TransWidth./FiltWidth;
CarrierSpacing = 1;		%Spacing between the carriers
FlatGuardPeriod = 0;
RaisedCosine = 0;			%Length of the raise cosine section of the guard period in samples
Window = 0;

OutbackoffdB = [0.5:0.5:10.5 -1];	%Output power backoffto simulate (-1) means no clipping
OutBOplot = [4 6 8 -1];		%Output power backoff for plotting the spectrum, must be calculated 
%									in OutbackoffdB
PowFudge = 6;
OutBandList = [0.05 0.5 1.5];	%Find the out of band attenuation at these points (normalised to
%			the carrier bandwidth. These are in spacings away from the edge of the system carriers
LegendStr = {'55% BW from center','100% BW from centre','200% BW from centre'};

xtext = [-175 -170 -170 -170];
ytext = [-25 -48 -62 -75];

SavePlotFlag = 0;			%Flag to enable (1) or disable (0) saving of the plots generated

%Calculate legend string for the OFDM spectrum plot with distortion
LegendStrSpec = [];
for k = 1:length(OutBOplot)
   if OutBOplot(k)~=-1
      LegendStrSpec{k} = ['OB: ' num2str(OutBOplot(k)) 'dB'];
   else
      LegendStrSpec{k} = 'No Distortion';
   end
end

mw = zeros(PlotFFT,length(OutbackoffdB));
Index = [];
for k = 1:length(OutBOplot)
   %index(k)
   I = find(OutBOplot(k)==OutbackoffdB);
   if isempty(I)
      error('Value of OutBOplot not found in OutbackoffdB')
   end
   Index(k) = I;
end
%==============================================
%      Frequency Plot of Bandlimited OFDM
%==============================================
for D = 1:length(OutbackoffdB)
   if FilterTaps > 0
      %Recalculate the low pass filter for band limiting the complex OFDM signal
      B = fir1(round(FreqPlotFFT*FilterTaps),(FreqPlotCarrs+3)/FreqPlotFFT...
         *(1+0/FreqPlotFFT), kaiser2(round(FreqPlotFFT*FilterTaps)+1, ...
         'width',TransWidth));
   else
      B = 1;
   end
   
   Nsymbs = FreqNsymbs;
   carriers = mkcarriers([FreqPlotCarrs, CarrierSpacing], FreqPlotFFT, 'complex');
   [x,y] = pol2cart(rand(FreqPlotCarrs,Nsymbs)*2*pi,ones(FreqPlotCarrs,Nsymbs));
   datavector = x+i*y;
   
   %Length of the total symbol time including the guard period
   SymbolLength = FreqPlotFFT+round(RaisedCosine.*FreqPlotFFT)*2+FlatGuardPeriod;
   outsymbol = ofdmmod(datavector,carriers, FreqPlotFFT, [FlatGuardPeriod, ...
         RaisedCosine 0],'complex');
      
   if isstr(Window)
      switch Window
      case 'blackh4'
         w = blackh4(SymbolLength);
      case 'hanning'
         w = hanning(SymbolLength);
      otherwise
         error(['Unsupported window type : ' Window]);
      end
   else
      if Window==0
         w = boxcar(SymbolLength);
      else
         w = kaiser2(SymbolLength,'trans',Window);
      end
   end
   w2 = repmat(w,1,Nsymbs);
   outsymbol = outsymbol.*w2;
   %Change the signal from a matrix form (one symbol per column) to a continuous
   %time waveform.
   timesig = reshape(outsymbol,length(outsymbol(:)),1);
   %Filter the OFDM waveform. 
   timesig = fftfilt(B,timesig);   %Use same variable to save memory
   if OutbackoffdB(D) ~= -1
      timesig = clipdist(timesig,OutbackoffdB(D));
   end
   
   %Use specgram to get an averaged spectrum.
   W = specgram(timesig,PlotFFT,1,lawrey5(PlotFFT));
   avg_pow = mean(mean(abs(W).^2));
   mw(:,D) = 20*log10(fftshift(mean(abs(W/sqrt(avg_pow))')))';
%   avg_pow = mean(abs(mw(:,D)).^2);
%   mw(:,D) = mw(:,D);
   BW = FreqPlotCarrs/FreqPlotFFT;
   disp(['Calculated Backoff :' num2str(OutbackoffdB(D)) 'dB, ' num2str(D) ' of ' ...
         num2str(length(OutbackoffdB))])    
end
mean_carr_pow = mean(mw((-BW*PlotFFT/2+PlotFFT/2+2):(BW*PlotFFT/2+PlotFFT/2),:));
BinAvg = 2;		%Number of freq bins to average the result over
mean_side_pow = zeros(length(OutbackoffdB),length(OutBandList));
for k = 1:length(OutBandList)
   T = (BW*PlotFFT*(OutBandList(k)+0.5)+PlotFFT/2);
   mean_side_pow(:,k) = (mean(mw(T:T+BinAvg-1,:))-mean_carr_pow)';
end

%      MeanPow = mean(mw((PlotFFT/2-BW*PlotFFT/2):(PlotFFT/2+BW*PlotFFT/2)));
figure(1)
Freq = linspace(-FreqPlotFFT/2,FreqPlotFFT/2,PlotFFT);


mw2 = mw(:,Index)-PowFudge;
OB = OutbackoffdB(Index);
h = plot(Freq,mw2); %-MeanPow);
%set(h(1),'linewidth',1);
%set(h(end),'linewidth',4);
%legend(h,LegendStrSpec,3)
axis tight
xlabel('Frequency (Carrier Spacings)')
ylabel('Power (dB)');
title('OFDM spectrum verses Clipping Distortion');
grid on
ylim([-80 3]);
setplotstyle
text(xtext,ytext,LegendStrSpec,'fontsize',20);
%set(h(1),'linewidth',1);
%set(h(end),'linewidth',4);
%legend
if SavePlotFlag
	savefig('s0048_distspec');     
end
index = find(OutbackoffdB~=-1);

figure(2); h = plot(OutbackoffdB(index),mean_side_pow(index,:));
xlabel('Output Power Backoff (dB)')
ylabel('Side Lobe Power (dBc)')
ylim([-100 -10])
set(gca,'ytick',-100:10:-10)
set(gca,'xtick',[1:1:11])
set(h(1),'marker','.');
set(h(2),'marker','x');
legend(h,LegendStr,3)
grid on
setplotstyle
set(h(2),'markersize',15);
if SavePlotFlag
   savefig('s0048_OBdist')
end
