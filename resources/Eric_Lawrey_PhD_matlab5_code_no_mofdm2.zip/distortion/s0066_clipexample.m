%This script plots an example of clipping on a random waveform (similar to an OFDM
%signal. From this we can see that the clipping corresponds to the Crest factor of
%the output signal.
N = 32;		%Number of samples in the random waveform
M = 16;		%Interpolation rate of the random waveform (makes it nice and smooth
OBO = 3;		%Output power Back Off in dB
randn('seed',224519)
A = randn(1,N);
A2 = upsamp(A,M);
Y = A2;
CF = (max(abs(Y)).^2)/mean((mean(abs(Y).^2)));
x = linspace(0,1,length(A2));
figure(1)
%subplot(1,2,1);
h1 = plot(x,A2);
[Ac, OBO2, AmpScale] = clipdist(A2,OBO);
%subplot(1,2,2);
Ac2 = Ac*AmpScale;
hold on
h2 = plot(x,Ac2,'r')
axis tight

ylim([-2.1 2.1])
xlabel('Time');
ylabel('Amplitude');

setplotstyle(2,1.2);
set(h2,'linewidth',4)
%[Mx, Ind] = max(Y);
%plot(x(Ind),Mx,'go','markersize',15,'linewidth',3);
hold off
legend([h1,h2],['Input CF: ' num2str(CF,3) 'dB'],['Output CF: ' num2str(OBO,3) 'dB'],2)
savefig('s0066_clipexample','emf')