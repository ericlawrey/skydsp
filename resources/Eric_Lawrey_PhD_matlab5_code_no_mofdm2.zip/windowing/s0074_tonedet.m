%This script shows the effect of using window functions for spectral
%estimation. It shows that spectral spreading masks weak signals, and
%that using a window function can reduce this. 

%Copyright Eric Lawrey (18/7/2001)
N = 512;							%Length of the waveform to analyse
Fc = [0.1 0.13 0.2 0.4];	%Frequency of the tones
Pow = [0 -100 -40 -100];	%Power of each tone (dBc)
Wloss = [0 6.0185 8.9063 9.5828];	%Window loss of each window function
WindowFunc = {'Boxcar','Hanning','Blackh4','Lawrey6'}; %Window functions to plot

%Title on each plot
TitleList = {'Boxcar','Hanning','4 Term Blackman Harris','6 Term Lawrey'};

%Calculate a the multitone signal
PowLin = 10.^(Pow/10);
a = zeros(1,N);
for k = 1:length(Fc)
   a = a+sqrt(PowLin(k)).*sin(2*pi*(0:N-1)*Fc(k));
end

f = linspace(0,1,N/2);
for k = 1:length(WindowFunc)
   %Generate one plot per window function
   figure(k)
   eval(['w=' WindowFunc{k} '(N);']);	%calc the window function
   %Estimate the power spectrum
   F = 20*log10(abs(fft(a.*w')))-20*log10(N/2)+Wloss(k);
   plot(f,F(1:end/2));
   title(TitleList{k})
   xlabel('Frequency (1 = Nyquist)')
   ylabel('Power (dB)')
   axis([0 1 -140 10]);
   setplotstyle(1.5, 1.2)
   set(gca,'ytick',[-140:20:20])
   savefig(['s0074_tones' WindowFunc{k}]);
end

