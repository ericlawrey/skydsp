clear all
%FileHeader = 's0050_';	%Added to the start of all figure plots
%Filename to save the plots to, for the OFDM spectrum plots
%Specplotnames = {'norc','rc52p2.5','rc52p10','rc52_spec','rc300_spec','rc300_edge','rc_edge','rc300_edge','rc300_edge'};

%Number of taps proportional to the IFFTsize, used to filter the
%OFDM signal. Filtering can be disabled by setting FiltWidth to Inf
%The units correspond to subcarrier spacings, so setting a FiltWidth of
%8 means that the filter will have a transition width of 8 subcarrier
%spacings. The transition width is the frequency separation from
%the edge of the passband to the first null in the stop band.
FiltWidth = [Inf Inf 2 8 2 8 Inf Inf Inf];

%Transition width of the window function used
%to bandlimit the OFDM. The filtering is performed using the window
%method, see FIR1, and the depth of the out of band attenuation 
%depends on the window function used. The window functions have been
%normalised to subcarrier spacings. See kaiser2(N,'width',TransWidth).
TransWidth = [1 1 3 3 1.5 1.5 1 1 1 ];	

%The OFDM symbols can be windowed, which makes the carriers wider, but
%gives better frequency separation. Time domain windowing
% Window 
% 0 	 - No windowing of the OFDM symbol, this is the only allowable
%			option with raised cosine guard period
% X	 - Transition width of the window, using kaiser2 windowing
% 'blackh4' - 4 term blackman harris window
% 'hanning' - Hanning window
Window = {0, 0, 0, 0, 0, 0, 0, 0, 0};

%Spacing between the subcarriers, in units of subcarriers
CarrierSpacing = [1 1 1 1 1 1 1 1 1];

FreqTitleHeader = 'OFDM Spectrum, ';

%Scales the font size used for the plot, a value of 1 is the default for setplotstyle
Fontscale = [ 1 1 1 1 1 1 0.9 1 0.8];

%Raised Cosine section in samples. This number of samples is added to the start and
%end of the symbol, thus the total symbol length is:
%SymbolLength = FreqPlotFFT+RaisedCosine*2+FlatGuardPeriod;
RaisedCosine = { 0, 0, 0, 0, 0, 0, [0 3 8 16 64], [0 4 8 16 64], [0 2 4 8 16 32 64 128 256]}; 

%RCoverlap specifies the overlap between symbols. This overlap occurs over
%   the raised cosine section of the guard period. If overlap == raise cosine
%   envolope then the raised cosine part of the guard period overlaps completely
%   with the next symbol. Units = samples
RCoverlap = RaisedCosine;

%For plots with combined results, an overlay with markers can be added to allow
%the different results to be separated. MarkerSpace is the number of data points
%between the marker points. If an entry in MarkerSpace for a plot is a vector
%this specifies markers as a fraction of the x axis, see plotm
MarkerSpace = {0, 0, 0,0,0,0,[0.25 0.75],[0.25 0.75],[ 0.65 0.9]};

%Number of subcarriers to plot
FreqPlotCarrs = [ 52, 1536, 20, 20, 20, 20, 52, 300, 5];

%Titles of each of the plots
PlotTitle = {[ num2str(FreqPlotCarrs(1)) ' subcarriers, No filtering'],...
      [ num2str(FreqPlotCarrs(2)) ' subcarriers, No filtering'],...
      'Filter Cutoff: 2 subcarriers, Window Func: 3',...
      'Filter Cutoff: 8 subcarriers, Window Func: 3',...
      'Filter Cutoff: 2 subcarriers, Window Func: 1.5',...
      'Filter Cutoff: 8 subcarriers, Window Func: 1.5',...
      '52 subcarriers, No flat guard period',...
      '300 subcarriers, No flat guard period',...
      [ num2str(FreqPlotCarrs(7)) ' subcarriers']};
%A spectral plot of the OFDM signal is also generated. Matching these spec.
%This is so the effect of the filtering can be seen on the spectrum of the
%OFDM signal. This is spectral width of the plot shown. This is not the
%actual FFT size used to generate the plot.
FreqPlotFFT = [128 4096 64, 64, 64, 64, 256, 1024, 1024];


%Actual FFT size used. This should be bigger than FreqPlotFFT because windowing
%is applied to the waveform before taking the FFT.
PlotFFT = FreqPlotFFT*4;	%FFT size used to plot the OFDM spectrum
PlotFFT(1) = 2048;
PlotFFT([3 4 5 6]) = 4096;
%PlotFFT(4) = 4096;
%Number of symbols to perform spectral averaging over
FreqNsymbs = [ 2048, 128, 2048, 2048, 2048, 2048, 256, 128, 128];

%1 - peak plot. Plots the peak of the signal over intervals of
% one subcarrier spacing. PlotFFT is usually larger than FreqPlotFFT, this interpolates the
% frequency response measurement. Enabling Peak Plot takes the peaks of each side lobe to
% removing the plotting of nulls, thus making the plot smooth. Set PeakPlot to 0 for normal
% plotting.
PeakPlot = [0 0 0 0 0 0 1 1 1];

%Flag to indicate whether the DC subcarrier should be used. 0 - Use DC subcarrier
%1 - NoDC subcarrier. (Hiperlan/2 has no DC subcarrier
NoDC = [1 1 1 1 1 1 1 1 1];

%Frequency offset from DC in subcarrier spacings to the signal. This
%can be used to align the edges of the spectrum for signals with different
%numbers of subcarriers. This actually shifts the OFDM signal in frequency
Offset = [0 0 0 0 0 0 0 0 0];

%Offset added to the X scale, useful for aligning the plot to the edge of the
% signal while still maintaining the OFDM signal in the centre.
Xoffset = [0 0 0 0 0 0 0 0 -FreqPlotCarrs(6)/2];

%X limits of each plot
xlimits = {[-64 64],[-2048 2048], [-32 32], [-32 32], [-32 32], [-32 32], [-128 128],[-512 512], [-25 350] };
xticks = {[-60:10:60],[-2000:250:2000],[-32:2:32],[-32:2:32],[-32:2:32],[-32:2:32],[-120:10:120],[-500:50:500],[0:25:350]};
%Display only every xmayor of xticks as labels
xmayor = [2,2,2,2,2,2,2,2,2];

Yt = [-100:5:5];
yticks = {Yt,Yt,[-130:10:10],[-130:10:10],[-130:10:10],[-130:10:10],[-100:5:10],[-100:5:10],[-130:5:0]};
%Display only every ymayor of yticks as labels
ymayor = [2,2,2,2,2,2,2,2,2];
Yl = [-100 5];
%Y limits of each plot
ylimits = {[-50 5], [-50 5], [-130 10], [-130 10], [-130 10], [-130 10], [-100 10], [-100 10],[-130 5]};

%Location for the legend on the plot
%        0 = Automatic "best" placement (least conflict with data)
%        1 = Upper right-hand corner (default)
%        2 = Upper left-hand corner
%        3 = Lower left-hand corner
%        4 = Lower right-hand corner
%       -1 = To the right of the plot
LegendPos = [0 0 0 0 0 0 0 0 -1];

%Output power backoff from peak power, this determines at what amplitude the signal is clipped. 
%OutBackoffdB. The signal is clipped at an amplitude which is OutBackoffdB dB higher than
%the average power. Set to -1 if no clipping is required.
OutbackoffdB = [-1, -1, -1, -1, -1, -1, -1, -1, - 1];	

%Length of the flat guard period in samples. This can be 
%added in to look at the time waveform, or for checking the effects of the guard
%period on the spectral response.
FlatGuardPeriod = [0, 0, 0, 0, 0,0,0,0, 0];

PowFudge = [6.57 6.57 6.57 6.57 6.57 6.57 6.57 6.57 6.57];		%Fudge factor to get the power levels in the plots to be 0dB
%This is needed as a result of the power loss in the window function used for spectral
%analysis. PowFudge = window loss (measured for real plot) + 3.01 dB (because we are using a complex plot)

ReplotList = [6];	%Index of the plots to plot. This can be used to selectively
%						plot just a few of the bandlimit plots, to save time setting
%						up for new plots.


%Calculate the normalised number of filter taps
FilterTaps = TransWidth./FiltWidth;	%Number of taps = FilterTaps*IFFTsize

for m = 1:length(ReplotList)
   D = ReplotList(m);

   if FilterTaps(D) > 0
      %Recalculate the low pass filter for band limiting the complex OFDM signal
      B = fir1(round(FreqPlotFFT(D)*FilterTaps(D)),(FreqPlotCarrs(D)+1)/FreqPlotFFT(D)...
         *(1+0/FreqPlotFFT(D)), kaiser2(round(FreqPlotFFT(D)*FilterTaps(D))+1, ...
         'width',TransWidth(D)));
   else
      B = 1;
   end
   
   Nsymbs = FreqNsymbs(D);
   carriers = mkcarriers([FreqPlotCarrs(D), CarrierSpacing(D) Offset(D)], FreqPlotFFT(D), 'complex', NoDC(D));
   [x,y] = pol2cart(rand(FreqPlotCarrs(D),Nsymbs)*2*pi,ones(FreqPlotCarrs(D),Nsymbs));
   datavector = x+i*y;
   
   NRC = length(RaisedCosine{D});	%Number of RC plots to make
   LegendStr = cell(1,NRC);
   h = [];
   for R = 1:NRC
      disp([num2str(R) ' of ' num2str(NRC)]);
      drawnow
      N = round(RaisedCosine{D}(R));
      %Length of the total symbol time including the guard period
      SymbolLength = FreqPlotFFT(D)+round(N)*2+FlatGuardPeriod(D)-RCoverlap{D}(R);
      outsymbol = ofdmmod(datavector,carriers, FreqPlotFFT(D), [FlatGuardPeriod(D), ...
            round(N) RCoverlap{D}(R)],'complex');
		if Window{D} ~= 0      
      if isstr(Window{D})
         switch Window{D}
         case 'blackh4'
            w = blackh4(SymbolLength);
         case 'hanning'
            w = hanning(SymbolLength);
         otherwise
            error(['Unsupported window type : ' Window{D}]);
         end
      else
         if Window{D}==0
            w = boxcar(SymbolLength);
         else
            w = kaiser2(SymbolLength,'trans',Window{D});
         end
      end
      w2 = repmat(w,1,Nsymbs);
      outsymbol = outsymbol.*w2;
      end
      %Change the signal from a matrix form (one symbol per column) to a continuous
      %time waveform.
      timesig = reshape(outsymbol,length(outsymbol(:)),1);
      clear outsymbol
      disp(['Number of FIR taps: ' num2str(length(B))]);
      if length(B) > 1
	      %Filter the OFDM waveform. 
         timesig = fftfilt(B,timesig);   %Use same variable to save memory
      end
      
      if OutbackoffdB(D) ~= -1
         timesig = clipdist(timesig,OutbackoffdB(D));
      end
      
      %Use specgram to get an averaged spectrum.
      W = specgram(timesig,PlotFFT(D),1,lawrey5(PlotFFT(D)));
      if size(W,2)> 1
         mw = 20*log10(fftshift(mean(abs(W)')));
      else
         mw = 20*log10(fftshift(abs(W)'));
      end
      clear W
      BW = FreqPlotCarrs(D)/FreqPlotFFT(D);
      %      MeanPow = mean(mw((PlotFFT/2-BW*PlotFFT/2):(PlotFFT/2+BW*PlotFFT/2)));
      figure(1)
      if (NRC==1)|(R == 1)
         hold off
      else
         hold on
      end
      if N == 0
         LegendStr{R} = 'No RC';
      else
         %Calculate the precentage that the RC is of the flat section of the
         %symbol. Also only use one side of the RC because we will assume
         %the signal is overlapping.
         Str = sprintf('RC: %4.2f%%',N/(FreqPlotFFT(D)+FlatGuardPeriod(D))*100);
         LegendStr{R} = Str;
      end
      
      
      PeakN = PlotFFT(D)/FreqPlotFFT(D);
      PowOffset = 10*log10(PeakN);
      if PeakPlot(D)
         Freq = linspace(-FreqPlotFFT(D)/2,FreqPlotFFT(D)/2,FreqPlotFFT(D))+Xoffset(D);
         PeakVal = max(reshape(mw,PeakN,length(mw)/PeakN));
         h2 = plot(Freq,PeakVal+PowFudge(D)-PowOffset); %-MeanPow);
      else
       	Freq = linspace(-FreqPlotFFT(D)/2,FreqPlotFFT(D)/2,PlotFFT(D))+Xoffset(D);
         h2 = plot(Freq,mw+PowFudge(D)-PowOffset); %-MeanPow);
      end
      h = [h h2];
  
   end
   axis tight
   xlabel('Frequency (Normalised to Subcarrier Spacings)')
%   xlabel('Frequency wrt. edge subcarrier (Subcarrier Spacings)')
   ylabel('Power (dB)');
   title([FreqTitleHeader PlotTitle{D}]);
   grid on
	ylim(ylimits{D});
   Ytick = num2str(yticks{D}.');
   Ytick2 = setstr(ones(size(Ytick))*' ');
   Ytick2(1:ymayor(D):end,:) = Ytick(1:ymayor(D):end,:);
   set(gca,'ytick',yticks{D});
   set(gca,'yticklabel',Ytick2);
   xlim(xlimits{D});
   Xtick = num2str(xticks{D}.');
   Xtick2 = setstr(ones(size(Xtick))*' ');
   Xtick2(1:xmayor(D):end,:) = Xtick(1:xmayor(D):end,:);
   set(gca,'xtick',xticks{D});
   set(gca,'xticklabel',Xtick2);
   
   setplotstyle(1.5,Fontscale(D))
   
   if NRC>1
      legend(h,LegendStr,LegendPos(D));
      plotm(h,MarkerSpace{D},15,1.5)
   end
%   savefig([FileHeader Specplotnames{D}]); 
end
