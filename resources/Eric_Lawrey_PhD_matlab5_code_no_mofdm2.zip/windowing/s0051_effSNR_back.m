%S0051_EFFSNR Find the effective channel SNR for OFDM under different conditions
% This script runs an OFDM simulation which measures the effective SNR of the link
% The simulation allows the simulation to be looped through two parameters.
% LoopVariable is the primary X axis variable, which will be calculated at
% points LoopList. For example LoopVariable = 'OutBackoffdB', and 
% LoopList = [0:1:12];, the x axis of the simulation will be Output Back off Power
% which will go from 0 in steps of 1 dB up to 12 dB. 
% LoopVariable should be a string of the variable name which is to be the x axis.
%
% LoopVariable2 allows another parameter to be varied, such as repeating the 
% output backoff simulation at 3 different numbers of carriers. This
% would be achieved by making LoopVariable2 = 'Ncarriers';
% LoopList2 = [8, 64, 512], simulating 8, 64, and 512 carriers.
%
% LockVariables2 allows other variables to be changed along with LoopVariable2.
% This is useful for changing parameters like the IFFTsize to match the number of
% carriers.
% LockValues2 is a cell array of vectors that each LockVariable2 will take.
%
% s0051_effsnr should be called from another script which will set up all the
% simulation parameters.
%
% See s0052_SNR_OB.m for an example of a scipt to call S0051_effsnr
%
% Copyright Eric Lawrey

switch LoopVariable
case 'OutBackoffdB'
   xlabel_text = 'Output Power Backoff (dB)';
   title_text = '';
otherwise
   warning(['Unsupported loop variable (' LoopVariable '), plot axes will be wrong'])
   xlabel_text = '';
   title_text = '';
end

switch LoopVariable2
case 'Ncarriers'
   legend_str = cell(1,length(LoopList2));
   for s= 1:length(LoopList2)
      legend_str{s} = [num2str(LoopList2(s)) ' carriers'];
   end
otherwise
   warning(['Unsupported loop variable2 (' LoopVariable '), legend will be sparse'])
   legend_str = cell(1,length(LoopList2));
   for s= 1:length(LoopList2)
      legend_str{k} = [num2str(LoopList2(s))];
   end   
end

EffSNR = zeros(length(LoopList),length(LoopList2));
for l2 = 1:length(LoopList2)
   eval([LoopVariable2 ' = LoopList2(l2);'])
   %Set all lock variables to their corresponding value in LockValues2
   for lk = 1:length(LockVariables2)   
      eval([LockVariables2{lk} ' = LockValues2{lk}(l2);']);
   end
   
   for l = 1:length(LoopList)
      eval([LoopVariable ' = LoopList(l);'])
      carriers = mkcarriers(Ncarriers,IFFTsize,RealComplex);
      
      for k = 1:Ntrials
         %Repeat the process since, the maximum number of symbols is limited by memory
         %This is so we can get a smoother plot.
         
         %Create random QAM data with a peak amplitude of 1.
         IQ = (rand(Ncarriers,Nsymbol)*2-1+i*(rand(Ncarriers,Nsymbol)*2-1))/sqrt(2);
         IQ = IQ/mean(mean(abs(IQ)));	%Make the mean carrier power = 1;
         
         RefSymb = genref(Ncarriers,RefScheme)*sqrt(PilotPowBoost);
         IQ2 = [repmat(RefSymb,1,NumRefSymb) IQ];
         %=============================================
         %		Generate transmitted OFDM signal
         %=============================================
         outsymbol = ofdmmod(IQ2, carriers, IFFTsize, GuardPeriod, ...
            RealComplex, fast_mode);
         
         %If the modulation is real, then the effective bandwidth of the 
         %OFDM spectrum is 2*the number of carriers.
         %This is done to calculate the correct amount of noise to add
         if strcmp(RealComplex,'real')
            BWscale = 2*Ncarriers/IFFTsize;
         else
            BWscale = Ncarriers/IFFTsize;
         end
         %Convert from a matrix form of one symbol per column to 
         %a single time vector
         outsig = reshape(outsymbol,1,size(outsymbol,1)*size(outsymbol,2));
         
         %===============================================
         %		Add clipping distortion to the signal
         %===============================================
         if ClipDistFlag         
            outsig = clipdist(outsig,OutBackoffdB);
         end
         %======================================
         %		Add AWGN to the signal
         %======================================
         [outsigrx noise] = addnoise(outsig,SNRdB,BWscale);
         
         % outsigrx = [0 outsigrx(1:end-1)];	%Add a small time error
         
         %Change the time domain data into matrix form, one symbol per column.
         outsymbolrx = reshape(outsigrx,(IFFTsize+GuardPeriod),length(outsigrx)/(IFFTsize+GuardPeriod));
         
         %==========================================               
         %		Demodulate the OFDM signal
         %==========================================
         %Strip off the guardperiod
         %This will be the lower rows of the matrix. Each column is a symbol
         %This simulation assumes perfect time synchronization
         NoGuard = outsymbolrx(GuardPeriod+(1:IFFTsize),:);
         %Apply the FFT
         fftdata = fft(NoGuard);
         %Now keep the carriers which were used
         IQrx = fftdata(carriers,:);          
         
         %=========================================
         %	Perform channel characterisation
         %=========================================
         %From the pilot symbols at the start of the transmission
         if NumRefSymb > 1
            ChannResp = (mean(IQrx(:,1:NumRefSymb)')')./(mean(IQ2(:,1:NumRefSymb)')');
         else
            ChannResp = (IQrx(:,1)./IQ2(:,1));
         end
         
         IQrx2 = IQrx(:,NumRefSymb+1:end)./repmat(ChannResp,1,size(IQrx,2)-NumRefSymb);
         
         IQerr = (IQrx2-IQ);
         
         if k > 1
            carrierSNR = carrierSNR + 20*log10(mean(abs(IQ'))./mean(abs(IQerr')));	%Take the mean of the
            %data before dividing the results, to prevent a lot of div by 0 results, which
            %give infinite SNR.
         else
            carrierSNR = 20*log10(mean(abs(IQ'))./mean(abs(IQerr')));
         end
         disp([LoopVariable ': ' sprintf('%3g',LoopList(l)) ', ' num2str(l) ' of ' ...
               num2str(length(LoopList)) ', Calc: ' num2str(k) ' of ' num2str(Ntrials) ' Trials'])
      end
      AvgCarrierSNR = carrierSNR/Ntrials;
      EffSNR(l,l2) = mean(AvgCarrierSNR);
   end
end
%figure(1)
%subplot(2,1,1)
%plot(abs(ChannResp))
%subplot(2,1,2)
%plot(angle(ChannResp))

figure(1)
clf
h = plot(LoopList,EffSNR);
grid on

xlabel(xlabel_text)
ylabel('Effective SNR (dB)')
title(title_text)
legend(h,legend_str,legend_pos)
axis(axis_range);
setplotstyle;
plotm(h,MarkerSpacing)
savefig(plot_filename)
%disp(['Effective SNR : ' num2str(EffSNR) ' dB']);