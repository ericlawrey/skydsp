%This script shows the number of taps required for different 
%window function to achieve the the same rate of roll off as a
%box car window, when used for FIR filters.
%Window		Trans. Width, from -6 dBc to -20 dBc, normalised to boxcar
%Boxcar            1
%Hanning       2.1491
%Hamming       2.0439
%Triangle      2.3596
%Blackman      2.6667
%Blackh4       3.1404
%Lawrey5       3.4123
%Lawrey6       3.8509

N = 40;		%Number of filter taps
Fc = 0.4;
B = fir1(N,Fc,boxcar(N+1));
H = freqz(B,1,2^14);
F = linspace(0,1,length(H));
h1 = plot(F,20*log10(abs(H)));

NB = round(3.1404*N);
B = fir1(NB,Fc,blackh4(NB+1));
H = freqz(B,1,2^14);

hold on
h2 = plot(F,20*log10(abs(H)),'r');
legend([h1,h2],'boxcar: 40 taps','blackh4: 126 taps');
xlabel('Frequency (1 = Nyquist)');
ylabel('Power (dB)');
ylim([-150 10]);
hold off
setplotstyle
%savefig('s0073_filt20dB')