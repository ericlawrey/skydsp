%This script plots the frequency response of two window fuctions
N = 128;		%Number of filter taps
B = lawrey5(N);
B = B/sum(B);
H = fft(B,2^14);
F = linspace(0,N/2,length(H)/2);
h1 = plot(F,20*log10(abs(H(1:end/2))));

%NB = round(3.1404*N);
B = lawrey6(N);
B = B/sum(B);
H = fft(B,2^14);

hold on
h2 = plot(F,20*log10(abs(H(1:end/2))),'r');
legend([h1,h2],'Lawrey5','Lawrey6');
xlabel('Frequency (1 = 1/Symbol Time)');
ylabel('Power (dB)');
ylim([-180 0]);
hold off
setplotstyle
%plotm([h1,h2],100)
xlim([0,15])
set(h1,'linewidth',1.5)
set(h2,'linewidth',3)
legend
set(gca,'xtick',[0:1:15])
grid on