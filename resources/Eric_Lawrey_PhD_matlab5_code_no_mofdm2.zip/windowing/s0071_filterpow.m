N = 50;			%Number alpha values to simulate, using N too large makes the
% result non monotonic, causing the simulation to crash. N = 200, is too large.
%Npeaks = 1;	%Keep data on the first Npeaks sidelobes
FilterLength = 128;
WindLength = FilterLength+1;	%Window length
FreqPoints = 2^15;	%A large number of points is needed to accurately
%							find the nulls
PowList = [0.4 0.5 0.6 0.7 0.8 0.9 0.95];	%Time width of the window function, for 50% cummulated
%							 power and other listed values
%============================================
%		Kaiser Window function
%============================================
alpha = linspace(1,4,N); %linspace(0,15,N);
NullFreq = zeros(N,3);
SideLobePow = zeros(N,3);
SideLobeFreq = zeros(N,3);
TimeWidth = zeros(N,length(PowList));
for k = 1:length(alpha)
   B = kaiser2(WindLength,'width',alpha(k));   
   B = fir1(FilterLength,0.5,B);
   fft1 = fft(B/sum(B),FreqPoints); 
   Ind6dB = max(find(abs(fft1(1:end/2))>(0.5)));
   Ind3dB = max(find(abs(fft1(1:end/2))>(1/sqrt(2))));
   Ind1dB = max(find(abs(fft1(1:end/2))>(10.^(-1/20))));
   %   Ind20dB = max(find(abs(fft1(1:end/2))>(1/10)));
   IndexList = [Ind1dB Ind3dB Ind6dB];
   for l = 1:length(IndexList)
      index = IndexList(l):length(fft1)/2;
      f = linspace(0, length(B)/4,FreqPoints/4); 
      P = 20*log10(abs(fft1(index)));
      nind = find(diff(sign(diff(abs(fft1(index)))))>0)+1;
      pind = find(diff(sign(diff(abs(fft1(index)))))<0)+1;
      NullFreq(k,l) = f(nind(1));
      SideLobePow(k,l) = P(pind(1))';
      SideLobeFreq(k,l) = f(pind(1));
   end
end

BS = [];
BS(:,1) = boxcar(WindLength);
BS(:,2) = hanning(WindLength);
BS(:,3) = hamming(WindLength);
BS(:,4) = triang(WindLength);
BS(:,5) = blackman(WindLength);
BS(:,6) = blackh4(WindLength);
BS(:,7) = lawrey5(WindLength);
BS(:,8) = lawrey6(WindLength);
Name = strvcat('boxcar','hanning', 'hamming', 'triang', 'blackman', 'blackh4', ...
   'lawrey5', 'lawrey6');

Nw = size(BS,2);
NullFreqStand = zeros(Nw,3);
SideLobePowStand = zeros(Nw,3);
SideLobeFreqStand = zeros(Nw,3);
for k = 1:size(BS,2)
   B = BS(:,k);
   B = fir1(FilterLength,0.5,B);
   fft1 = fft(B/sum(B),FreqPoints); 
   Ind6dB = max(find(abs(fft1(1:end/2))>(0.5)));
   Ind3dB = max(find(abs(fft1(1:end/2))>(1/sqrt(2))));
   Ind1dB = max(find(abs(fft1(1:end/2))>(10.^(-1/20))));
   Ind20dB = max(find(abs(fft1(1:end/2))>(10.^(-20/20))));
   %   Ind20dB = max(find(abs(fft1(1:end/2))>(1/10)));
   IndexList = [Ind1dB Ind3dB Ind6dB Ind20dB];
   for l = 1:length(IndexList)
      index = IndexList(l):length(fft1)/2;
      f = linspace(0, length(B)/4,FreqPoints/4); 
      P = 20*log10(abs(fft1(index)));
      nind = find(diff(sign(diff(abs(fft1(index)))))>0)+1;
      pind = find(diff(sign(diff(abs(fft1(index)))))<0)+1;
      NullFreqStand(k,l) = f(nind(1));
      SideLobePowStand(k,l) = P(pind(1))';
      SideLobeFreqStand(k,l) = f(pind(1));
   end
end

h = plot(alpha,NullFreq);
grid on
ylabel('Filter Transition Width')
xlabel('Window Function Transition Width')
legend(h,'1dB to Null','3dB to Null','6dB to Null',2);
setplotstyle

%plot(cumsum(B.^2)/sum(B.^2),1:WindLength)
%TimeWidth(k,:) = (WindLength-2*interp1(cumsum(B.^2)/sum(B.^2),1:WindLength,0.5-PowList/2,'linear'))/WindLength;
s = SideLobeFreqStand(:,3)-SideLobeFreqStand(:,4);
s = NullFreqStand(:,3)-NullFreqStand(:,4);
disp('Transition Width for FIR filter from -6 dB to -20 dB, normalised to Boxcar')
s2 = s/s(1);
s2str = sprintf(': %5.2f dB',s2);
disp([Name, reshape(s2str,length(s2str)/size(BS,2),size(BS,2)).']);
disp('');
disp('Transition Width of FIR filter  (From X dB point to first null)')
disp('          1dB        3dB       6dB');
disp([Name,repmat(': ',size(BS,2),1),num2str(NullFreqStand(:,1:3),3)])
disp('');
disp('Maximum Side-lobe Power, for FIR filter using window method (dBc)')
disp([Name, repmat(': ',size(BS,2),1), num2str(SideLobePowStand(:,1),4)])


M = 15;
TransWidth = linspace(1,5,M);
BS = zeros(WindLength,M);
for k = 1:M
   BS(:,k) = kaiser2(WindLength,'width',TransWidth(k));
end

Nw = size(BS,2);
NullFreqStand = zeros(Nw,3);
SideLobePowStand = zeros(Nw,3);
SideLobeFreqStand = zeros(Nw,3);
for k = 1:size(BS,2)
   B = BS(:,k);
   B = fir1(FilterLength,0.5,B);
   fft1 = fft(B/sum(B),FreqPoints); 
   %   Ind20dB = max(find(abs(fft1(1:end/2))>(1/10)));
   
   %Not all this needs to be done, just to get the side lobe power for the kaiser window,
   %but this works, and I am supposed to finish my thesis TODAY (12/11/01)
   Ind6dB = max(find(abs(fft1(1:end/2))>(0.5)));
   Ind3dB = max(find(abs(fft1(1:end/2))>(1/sqrt(2))));
   Ind1dB = max(find(abs(fft1(1:end/2))>(10.^(-1/20))));
   Ind20dB = max(find(abs(fft1(1:end/2))>(10.^(-20/20))));
   IndexList = [Ind1dB Ind3dB Ind6dB Ind20dB];
   for l = 1:length(IndexList)
      index = IndexList(l):length(fft1)/2;
      f = linspace(0, length(B)/4,FreqPoints/4); 
      P = 20*log10(abs(fft1(index)));
      nind = find(diff(sign(diff(abs(fft1(index)))))>0)+1;
      pind = find(diff(sign(diff(abs(fft1(index)))))<0)+1;
      NullFreqStand(k,l) = f(nind(1));
      SideLobePowStand(k,l) = P(pind(1))';
      SideLobeFreqStand(k,l) = f(pind(1));
   end
end
figure(2)
h = plot(TransWidth, SideLobePowStand);
xlabel('Window function transition width (Normalised to boxcar)')
ylabel('Max. side-lobe power of FIR filter (dBc)')
title('Side-lobe power for FIR using Kaiser window function')
%set(h,'ydir','reverse');
grid on 
setplotstyle

figure(3)
h = plot(TransWidth, NullFreqStand);
legend(h,'  1 dB to Null', '  3 dB to Null', '  6 dB to Null', '20 dB to Null',2)
grid on 
title('FIR transition width for Kaiser window function')
xlabel('Window function transition width (Normalised to boxcar)')
ylabel('Norm. width for FIR filter to 1st Null')
setplotstyle
plotm(h,[0.25 0.75])

