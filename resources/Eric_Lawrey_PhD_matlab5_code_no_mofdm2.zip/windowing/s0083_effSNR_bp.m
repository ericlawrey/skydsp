%This simulation shows the effective SNR verse subcarrier number as a
%result of band pass filtering of the signal
%

%===========================
%	Default Variabels
%===========================
Nsymbol = 10;				%Number of Symbols to simulate (default)
Ntrials = 80;				%Number of Trials to average the results over. Lowering Nsymbol
%								and increasing Ntrials can be used to minimise the memory useage
%								Memory useage ~(Nsymbol+NumRefSymb)*(IFFTsize+GuardPeriod)*8(bytes 
%								per number)*2(complex)*2(working memory) in Bytes
Ncarriers = 1001;			%Number of carriers to use
IFFTsize = 2048;			%Size of the IFFT used to generate the OFDM signal
%Ncarriers = 53;			%Number of carriers to use
%IFFTsize = 128;			%Size of the IFFT used to generate the OFDM signal

RealComplex = 'complex';	%Whether to generate a 'real' or 'complex' OFDM signal
GPPercent = 10;			%Percentage the Guard Period is of the total symbol time
GuardPeriod = round(IFFTsize*(GPPercent/100)/(1-GPPercent/100));			%Length of the guard period in samples
fast_mode = 0;				%Enabling the fast mode in OFDMMOD (see help ofdmmod)
ClipDistFlag = 0;			%Whether to enable clipping distortion on the signal
OutBackoffdB = 20;			%Output power backoff in dB
TimeOffset = -GuardPeriod/(IFFTsize+GuardPeriod)/2;			%Time Offset error as fraction of total symbol time (ifft & guard)
TimeOffSymbScaleFlag = 1;	%(1) Scale the time offset data as a fraction of the symbol period
%								(0) Use TimeOffset in units of samples
Wrap = abs(ceil(TimeOffset*(IFFTsize+GuardPeriod)));		%Add a bit of trailer signal to allow for the bit chopped by the time offset.
SNRdB = 2000;				%Channel SNR for AWGN in dB
RefScheme = 3;				%Type of pilot symbol used
PilotPowBoost = 1;		%Power boosting of the pilot power
NumRefSymb = 8;			%Number of pilot symbols to use
legend_flag = 1;			%Enable (1) or Disable plotting of the legend
title_text = '';

xticks = 1;		%[0:4:32];		%Xticks marks to put on the plot
yticks = 1;		%[0:10:80];	%If yticks is a scalar the yticks are not set
MarkerSpacing = round(Ncarriers/15);		%Spacing between the markers
BPFilterFlag = 1;			%Flag to enable bandpass filtering of the signal (1) - enabled 
%								(0) - no filtering
TransWidth = 4;			%TransWidth is the transition width of the window function
%								This determines the out of band attenuation 
FiltWidth = 8; 			%FiltWidth width of the bandpass filtering to first null
TitleStr = ['Guard Period ' num2str(GPPercent) '% of total symbol time'];%['Filter transition in carrier spacing (Window Function Width:' num2str(TransWidth) ')'];
plot_filename = 's0052_effSNR_filter';	%File name of the plot generated
CarrierPlotFlag = 1;		%(1) plot the effective SNR as a function of carrier
%								number, rather than the loop variable. If the loop variable
%								is a vector multiple lines are plotted. LoopVariable2 should
%								only be a single value.
%SymbolPlotFlag = 1;
%SymbAvgType = 1;
SavePlotFlag = 0;
%=====================================
%	Loop Variables
%=====================================
%The loop variables overwrite the default values
LoopVariable =  'FiltWidth';

LoopList = [0.5 4 6 8 10];  %For 20%
LoopList = [0.5 8 12 16 20]; %For 10%
%LoopList = [0.5 2 3 4 5]; %For 33.3%
%LoopList = [-0.1];

LockVariables = {};
LockValues = {};
LoopVariable2 = 'Dummy';
LoopList2 = [1];
LockVariables2 = {};%{'IFFTsize', 'Nsymbol','Ntrials'};	%This variable will also change with LoopVariable2
LockValues2 = {};%{[256], [100], [1]};	%These are the values the lock variables will take
%																		The length of each array must match the LoopList length
axis_range = [min(LoopList) max(LoopList) 20 90];	%Plot axis range
legend_pos = 4;					%Position of legend, See help legend

s0051_effSNR
set(gca,'xscale','log');
ylim([20 100]);
xlim([1 300]);
