%This script plot the time waveform of several window functions

%By Eric Lawrey 18/7/2001
N = 500;
Z = 2;
x = linspace(-(Z-1)/N,(N+Z-1)/(N),N+2*Z);
h = plot(x,[zeros(1,Z) boxcar(N)' zeros(1,Z)],'b',x,[zeros(1,Z) triang(N)' zeros(1,Z)],...
   'k',x,[zeros(1,Z) hanning(N)' zeros(1,Z)],'g',x,[zeros(1,Z) blackh4(N)' zeros(1,Z)],'r');
setplotstyle
legend(h,'boxcar','triangle','hanning','blackh4');
axis([-0.05, 1.05 0 1.05])
xlabel('Time (Normalised)');
ylabel('Amplitude');
plotm(h,167);
box off

