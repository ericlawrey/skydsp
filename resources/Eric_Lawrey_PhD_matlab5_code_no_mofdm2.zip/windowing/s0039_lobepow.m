N = 20;			%Number alpha values to simulate, using N too large makes the
% result non monotonic, causing the simulation to crash. N = 200, is too large.
Npeaks = 20;	%Keep data on the first Npeaks sidelobes
WindLength = 128;	%Window length
FreqPoints = 2^15;	%A large number of points is needed to accurately
%							find the nulls
PowList = [0.4 0.5 0.6 0.7 0.8 0.9 0.95];	%Time width of the window function, for 50% cummulated
%							 power and other listed values
%============================================
%		Kaiser Window function
%============================================
alpha = linspace(0,19,N);
%alpha = linspace(20,120,N);
NullFreq = zeros(N,Npeaks);
SideLobePow = zeros(N,Npeaks);
SideLobeFreq = zeros(N,Npeaks);
TimeWidth = zeros(N,length(PowList));
for k = 1:length(alpha)
   B = kaiser(WindLength,alpha(k));
%   B = chebwin(WindLength,alpha(k));
   fft1 = fft(B/sum(B),FreqPoints); 
   f = linspace(0, length(B)/2,FreqPoints/2); 
   P = 20*log10(abs(fft1(1:end/2)));
%   plot(cumsum(B(1:end/2).^2)/sum(B(1:end/2).^2),linspace(0,0.5,length(B)/2));
	width = 1-2*interp1(cumsum(B(1:end/2).^2)/sum(B(1:end/2).^2),...
   linspace(0,0.5,length(B)/2),0.5);
   nind = find(diff(sign(diff(abs(fft1(1:end/2)))))>0)+1;
   pind = find(diff(sign(diff(abs(fft1(1:end/2)))))<0)+1;
   NullFreq(k,:) = f(nind(1:Npeaks));
   SideLobePow(k,:) = P(pind(1:Npeaks))';
   SideLobeFreq(k,:) = f(pind(1:Npeaks));
   plot(cumsum(B.^2)/sum(B.^2),1:WindLength)
   TimeWidth(k,:) = (WindLength-2*interp1(cumsum(B.^2)/sum(B.^2),1:WindLength,0.5-PowList/2,'linear'))/WindLength;
end

%============================================
%      Standard Window Functions
%============================================
BS = [];
BS(:,1) = boxcar(WindLength);
BS(:,2) = hanning(WindLength);
BS(:,3) = hamming(WindLength);
BS(:,4) = triang(WindLength);
BS(:,5) = blackman(WindLength);
BS(:,6) = blackh4(WindLength);
BS(:,7) = lawrey5(WindLength);
BS(:,8) = lawrey6(WindLength);
Nw = size(BS,2);
Name = strvcat('boxcar','hanning', 'hamming', 'triang', 'blackman', 'blackh4', ...
  'lawrey5', 'lawrey6');
NullFreqStand = zeros(Nw,Npeaks);
SideLobePowStand = zeros(Nw,Npeaks);
SideLobeFreqStand = zeros(Nw,Npeaks);
for k = 1:size(BS,2)
   B = BS(:,k);   
   fft1 = fft(B/sum(B),8192); 
   f = linspace(0, length(B)/2,8192/2); 
   P = 20*log10(abs(fft1(1:end/2)));
%   plot(cumsum(B(1:end/2).^2)/sum(B(1:end/2).^2),linspace(0,0.5,length(B)/2));
	width = 1-2*interp1(cumsum(B(1:end/2).^2)/sum(B(1:end/2).^2),...
	   linspace(0,0.5,length(B)/2),0.5);
   nind = find(diff(sign(diff(abs(fft1(1:end/2)))))>0)+1;
   pind = find(diff(sign(diff(abs(fft1(1:end/2)))))<0)+1;
   NullFreqStand(k,:) = f(nind(1:Npeaks));
   SideLobePowStand(k,:) = P(pind(1:Npeaks))';
   SideLobeFreqStand(k,:) = f(pind(1:Npeaks));
end



figure(1)
h = plot(NullFreq(:,1),SideLobePow(:,1),...
   NullFreqStand(1,1),max(SideLobePowStand(1,:)),'rx',...
   NullFreqStand(2,1),max(SideLobePowStand(2,:)),'go',...
   NullFreqStand(3,1),max(SideLobePowStand(3,:)),'k^',...
   NullFreqStand(4,1),max(SideLobePowStand(4,:)),'m+',...
   NullFreqStand(5,1),max(SideLobePowStand(5,:)),'db',...
   NullFreqStand(6,1),max(SideLobePowStand(6,:)),'pr',...
   NullFreqStand(7,1),max(SideLobePowStand(7,:)),'sg',...
   NullFreqStand(8,1),max(SideLobePowStand(8,:)),'vk');
xlabel('Transition width of the window (normalised to boxcar)')
ylabel('First Sidelobe Power (dB)')
title('Transition Width from peak to first null'); 
legend(h,'Kaiser','Boxcar','Hanning','Hamming','Triangle','Blackman','Blackh4',...
   'Lawrey5','Lawrey6');
axis tight
setplotstyle(2.5,1,18)
P = polyfit(NullFreq(:,1),SideLobePow(:,1),1);
text(1.5, -105, ['y = ' num2str(P(1),4) '.x+' num2str(P(2),4) ' (dB)'],'fontsize',24);
grid on
set(gca,'ytick',[-150:10:-10]);
set(gca,'xtick',[1:0.5:6]);
disp('Transition width of window functionDC to first Null (normalised to 1/ symbol time)');
disp([Name repmat(': ',size(BS,2),1) num2str(NullFreqStand(:,1),4)])
disp('')
disp('Maximum Side-Lobe Power for window function (dBc)');
disp([Name repmat(': ',size(BS,2),1) num2str(SideLobePowStand(:,1),4)])