%This script calculate the window loss off a variety of window functions

%Copyright Eric Lawrey (18/7/2001)
N = 4096;
SinPow = 20*log10(N/2)';
a = sin(2*pi*(0:N-1)*1/8);
WindowFunc = {'boxcar','hanning','hamming','triang','blackman','blackh4','lawrey5','lawrey6'};
Wloss = [];
disp('Window    Power loss (dB)')
for k = 1:length(WindowFunc)
   Wloss(k) = eval(['SinPow-max(20*log10(abs(fft(a.*' WindowFunc{k} '(N)''))))']);
   s = [WindowFunc{k} ':    '];
   disp([s(1:10) num2str(Wloss(k),5)]);
end