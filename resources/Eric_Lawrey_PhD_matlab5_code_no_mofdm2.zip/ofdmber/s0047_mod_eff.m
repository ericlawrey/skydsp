%
%Copyright Eric Lawrey April 2001.

BERlist = [ 1e-5];
simfiles = {'s0041_coh_qam','s0041_coh_psk'};
%simfiles = {'s0041_coh_qam'};
SavePlotFlag = 1;
%FileName = 's0042_RefDetTable.txt';
%Dimensions of EBNRcutoff
% 1 - Cut off EBNR for each BER (1e-2 1e-3 1e-4 1e-5}
% 2 - Modulation scheme, BPSK,QPSK,16QAM,64QAM,256QAM
legendlist = {'Coherent QAM','Coherent PSK','Shannon''s Limit'};
colourlist = 'rbgkyc';
markerlist = 'xo^sd.+';
totbits = 0;
bits = 0;
h = [];
for f = 1:length(simfiles)
   load(simfiles{f});
   NumMods = length(ModsUsed);
   EBNRcutoff = zeros(length(BERlist),NumMods);
   for k = 1:NumMods
      warning off
      Ber = log10(BERall(:,k));
      ind = find(Ber>-7);
      Ber2 = Ber(ind);
      EBNRdB2 = EBNRdB(ind);
      EBNRcutoff(:,k) = interp1(Ber2,EBNRdB2,log10(BERlist),'linear')';
      warning on
   end
   NbitsList = round(log2(Nconstellation(ModNumberList)));
   bits = bits + sum(sum(NwordsUsed.*repmat(NbitsList,size(NwordsUsed,1),1)));
   %Plot the SNR verses the number of bits/Hz
   h(f) = plot(NbitsList,EBNRcutoff+repmat(10*log10(NbitsList),length(BERlist),1),...
      [colourlist(f) markerlist(f) '-']);
   hold on
end
hold off
S = 10*log10(2.^(1:12));	%Calculate Shannons Information limit
hold on
h(f+1) = plot(1:12,S,'color',[0.6 0 0.6]);
hold off
axis tight
legend(h,legendlist,4);
xlabel('Modulation Spectral Efficiency (bits/Hz/sec)')
ylabel('SNR for BER < 1x10^-^5 (dB)');
setplotstyle(2,1.2,15);
grid on
set(gca,'xtick',[1:12])
if SavePlotFlag
   savefig('s0047_mod_eff')
end

%disp(['Results saved in file : ' FileName]);
disp(['Total Bits based on NwordsUsed : ' num2str(bits)])
