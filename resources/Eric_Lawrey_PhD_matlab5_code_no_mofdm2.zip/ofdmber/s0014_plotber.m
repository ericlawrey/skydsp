%S0014_PLOTBER, This script plots the BER verses SNR for a number of modulation schemes.
%The data is loaded from coh_ber_snr2.mat. This data was generated
%using simulation. The simulation data can be regenerated using s0013_bersim and 
%All even bit QAM schemes (such as 16QAM, 64QAM, 256QAM, etc)
%use gray coding. Odd order ones use a cross IQ mapping, with data mapping
%being sequential. See data2iqmap for the IQ plots of each moduation scheme
%i.e.
% If no output is used DATA2IQMAP plots the IQ plot instead of generating the output 
% table.
% i.e. DATA2IQMAP('32QAM')
% will generate a plot of 32QAM
%
% Contents of s0041_coh_qam are:
%  BERall               85x12          8160  double array
%  BitSimThreshold       1x1              8  double array
%  BitsReq               1x1              8  double array
%  DiffFlag              1x1              8  double array
%  DispRate              1x1              8  double array
%  EBNRIndex             1x1              8  double array
%  EBNRdB                1x85           680  double array
%  GuardPeriod           1x1              8  double array
%  IFFTsize              1x1              8  double array
%  InLineChanChar        1x1              8  double array
%  MaxRuns               1x1              8  double array
%  MaxTests              1x12            96  double array
%  ModCatergory          1x19           152  double array
%  ModIndex              1x1              8  double array
%  ModNumberList         1x12            96  double array
%  ModType               1x19          1952  cell array
%  ModsUsed              1x12          1236  cell array
%  Ncarriers             1x1              8  double array
%  Nconstellation        1x19           152  double array
%  Ntaps                 1x1              8  double array
%  NumRefSymb            1x1              8  double array
%  NumRuns               1x1              8  double array
%  Nwords                1x1              8  double array
%  NwordsUsed           85x12          8160  double array
%  OFDMflag              1x1              8  double array
%  PrevENBRcheck         1x1              8  double array
%  RealComplex           1x7             14  char array
%  RefScheme             1x1              8  double array
%  SERall               85x12          8160  double array
%  SNRtest               1x1              8  double array
%  TotalTime             1x1              8  double array
%  biterrors            85x12          8160  double array
%  decay                 1x1              8  double array
%  dellist               1x3             24  double array
%  delspread             1x1              8  double array
%  errorstotal          85x12          8160  double array
%  fast_mode             1x1              8  double array
%  limits                1x2             16  double array
%  totbitsim             1x1              8  double array
%
% Most of these parameters are stored to make this a restartable
% simulation with separate simulation files.
% The important variables for plotting are:
% EBNRdB - SNR in dB that each BER test was run
% BERall - bit error rate of each modulation scheme. Each mod scheme
% is a different column. The modulation used in each column is
% given by ModsUsed
% ModsUsed - modulation scheme used for each test (cell array of strings)
% SERall - symbol error rate for each modulation scheme
%
% Copyright Eric Lawrey (c) September 2000, Eric.Lawey@jcu.edu.au
Diff_Coh = 1;	%1 = Plot coherent modulation schemes,
%					 0 = Plot Differential modulation schemes
QAM_PSK = 1;	%1 = plot PSK data
%					0 = QAM data

%Find the data file containing the simulated BER tests
if Diff_Coh
   %Coherent modulation
   if QAM_PSK
      %PSK modulation
      filename = 's0041_coh_psk';
      load([filename '.mat'])
      plot_axis = {[0 40 1e-6 0.5]};
      Xtick_values = {[0:2:38]};
      plot_list = {1:size(BERall,2)};
      plot_text = {{'8' '16' '32' '64' '128' '256'}};
      text_x = {[10.2 14 19 24 28.5 34]};
      text_y = {ones(1,6)*1.3e-4};
      plot_title = {'Coherent Phase Shift Keyiing'};
   else
      %QAM modulation
      filename = 's0041_coh_qam';     
      load([filename '.mat'])
      plot_axis = {[0 19 1e-6 0.3], [10 34 1e-6 0.3]};
      Xtick_values = {[0:1:18], [10:2:34]};
      plot_list = {1:6, 7:size(BERall,2)};
      %plot_text = {};
      plot_text = {{'BPSK' 'QPSK' '8' '16' '32' '64'} {'128','256','512','1024','2048','4096'}};
      text_x = {[5.4 6 9.5 11 13.2 15.2] [16.5 19.5 22.1 24.1 26.8 29.2]};
      text_y = {[4e-4 1.3e-4 1.3e-4 1.3e-4 1.3e-4 1.3e-4], [ones(1,6)*1.3e-4]};
      plot_title = {'Coherent Quadrature Amplitude Modulation',...
            'Coherent Quadrature Amplitude Modulation'};
   end
else
   %Differential modulation
   if QAM_PSK
      %PSK modulation
      filename = 's0041_diff_psk';
      load([filename '.mat'])
      plot_axis = {[4 43 1e-6 0.5]};
      Xtick_values = {[4:2:42]};
      plot_list = {1:size(BERall,2)};
      plot_text = {{'8' '16' '32' '64' '128' '256'}};
      text_x = {[10.2 14 19 24 28.5 34]+2.8};
      text_y = {ones(1,6)*1.4e-4};
      plot_title = {'Differential Phase Shift Keyiing'};
   else
      %QAM modulation
      filename = 's0041_diff_QAM';
      load([filename '.mat'])
      plot_axis = {[0 37.5 1e-6 0.5]};
      Xtick_values = {[0:2:36]};
      plot_list = {1:size(BERall,2)};
      plot_text = {{'BPSK' 'QPSK' '16' '64' '256' '1024','4096'}};
      text_x = {[5.3 10 13.3 17.5 22 26 31]};
      text_y = {[1.4e-4 1.4e-3 ones(1,5)*1.4e-4]};
      plot_title = {'Differential QAM'};
   end
end

plot_filename = filename;

lw = 1.5; %Linewidth used on the plots
fs = 0.8; %Font scaling used on the plots

for k = 1:length(plot_list)
   figure(k);
   clf
   %List of modulation schemes to put on the first plot
   Mods = plot_list{k};
   h = semilogy(EBNRdB(:),BERall(:,Mods));
   ylabel('Bit Error Rate');
   xlabel('Energy per Bit to Noise Ratio (dB)');
   %title('Coherent Phase Modulation');
   %xax = [-10 50];
   axis(plot_axis{k})
   set(gca,'xtick', Xtick_values{k});
   grid on
   
   %Make the font sizes bigger and the lines thicker
   setplotstyle(lw,fs)
   if ~isempty(plot_text)
      text(text_x{k},text_y{k},plot_text{k},'fontsize',20);
   end
   title(plot_title{k})
   %The figure is capture off the screen so you should maximise 
   %the size manually
   if length(plot_list) > 1
      savefig([plot_filename num2str(k)]);
   else
      savefig(plot_filename);
   end
end



