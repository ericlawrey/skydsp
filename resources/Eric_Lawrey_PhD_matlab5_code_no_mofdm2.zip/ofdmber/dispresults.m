set(h_simfile,'string',SimFile);
set(h_modulation,'string',ModString);
set(h_EBNR,'string',sprintf('%0.3g dB',EBNRdB(k)));
if SNRtest
   set(h_EBNRText,'string','SNR:')
else
   set(h_EBNRText,'string','EBNR:')
end
if length(OutBackoffdB)>1
	set(h_words,'string',sprintf('%0.8g',NwordsUsed(k,m,b)));
	set(h_totalerrors,'string',num2str(biterrors(k,m,b)));
else
   set(h_words,'string',sprintf('%0.8g',NwordsUsed(k,m)));
	set(h_totalerrors,'string',num2str(biterrors(k,m)));
end   
Hrs = floor(TotalTime/3600);
Mins = floor((TotalTime - Hrs*3600)/60);
Sec = round(TotalTime - (Hrs*3600+Mins*60));
set(h_TotalTime,'string',sprintf('%4d:%2d:%2d',Hrs,Mins,round(Sec)));
set(h_TotalBits,'string',num2str(totbitsim));
if ClipDistFlag
   set(h_OutBackoffdB,'string',num2str(OutBackoffdB(b)));
end

