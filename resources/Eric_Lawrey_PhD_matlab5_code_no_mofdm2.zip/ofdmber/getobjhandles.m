gc = get(gcf,'children');
h_simfile = findobj(gc, 'flat', 'tag', 'simfile');
h_modulation = findobj(gc, 'flat', 'tag', 'modulation');
h_EBNR = findobj(gc, 'flat', 'tag', 'EBNR');
h_EBNRText = findobj(gc, 'flat','tag','EBNRText');
h_words = findobj(gc, 'flat', 'tag', 'words');
h_totalerrors = findobj(gc, 'flat', 'tag', 'totalerrors');
h_TotalTime = findobj(gc, 'flat', 'tag', 'TotalTime');
h_TotalBits = findobj(gc, 'flat', 'tag', 'TotalBits');
h_TotalTime = findobj(gc, 'flat', 'tag', 'TotalTime');
h_axes1 = findobj(gc, 'flat', 'tag', 'Axes1');
h_axes2 = findobj(gc, 'flat', 'tag', 'Axes2');
h_OutBackoffdB = findobj(gc, 'flat','tag','OutBackoffdB');
h_OutBackoffdBText = findobj(gc, 'flat','tag','OutBackoffdBtext');




