%This is a testing script to verify the operation of the DATA2IQMAP and IQ2DATA functions
ModType = {'BPSK', 'QPSK', 'S8QAM', '8QAM', '16QAM', '32QAM', '64QAM', '128QAM', '256QAM',...
      '512QAM','1024QAM','2048QAM','4096QAM','8PSK', '16PSK', '32PSK', '64PSK', '128PSK', '256PSK'};
Nwords = [ 2 4 8 8 16 32 64 128 256 512 1024 2048 4096 8 16 32 64 128 256];

%ModType = {'8QAM'};
%Nwords = [8];
tic
for k = 1:length(ModType)
   D = 0:(Nwords(k)-1);
%   D = floor(rand(1,10000)*Nwords);
   M = data2iqmap(char(ModType(k)));
   IQ = M(D+1);
%   plot(IQ);
   
%   drawnow;
   Do = iq2data(IQ,char(ModType(k)));
   errors = length(find(abs(Do-D)>0));
   errind = find(abs(Do-D)>0);
   if errors>0
      s = ['Demodulation failed for : ' char(ModType(k)),', Errors : ' num2str(errors)];
      disp(['Dout : ' num2str(Do(errind(1:min(20,length(errind)))))]);
      disp(['Din : ' num2str(D(errind((1:min(20,length(errind))))))]);
      
   else
      s = ['No Errors for : ' char(ModType(k))];
   end
   disp(s);
   title(s);
end

toc
      