%This script combines the results in simulating the BER for different numbers of 
%pilot symbols for coherent modulation. This script find the EBNR cut offs 
%corresponding to different BERs (typically 1e-2, 1e-3, 1e-4, 1e-5). This 
%difference between this EBNR and the EBNR for perfect channel equalisation
%is calculated. This degradation is then saved to a text file, which can be
%loaded into excel and then in to word.
%
%Copyright Eric Lawrey April 2001.

BERlist = [1e-2 1e-3 1e-4 1e-5];
simfiles = {'coh_ber_snr_ofdm0','coh_ber_snr_ofdm1','coh_ber_snr_ofdm2', ...
      'coh_ber_snr_ofdm3','coh_ber_snr_ofdm4','coh_ber_snr_ofdm8'};

FileName = 's0042_RefDetTable.txt';
NumRefList = zeros(1,length(simfiles));
NumMods = 5;
%Dimensions of EBNRcutoff
% 1 - Number of Reference Pilot symbols, Inf, 1 2 3 4 8
% 2 - Cut off EBNR for each BER (1e-2 1e-3 1e-4 1e-5}
% 3 - Modulation scheme, BPSK,QPSK,16QAM,64QAM,256QAM
totbits = 0;
EBNRcutoff = zeros(length(simfiles),length(BERlist),NumMods);
bits = 0;
for f = 1:length(simfiles)
   load(simfiles{f});
   NumRefList(f) = NumRefSymb;
   for k = 1:NumMods
      warning off
      EBNRcutoff(f,:,k) = interp1(log10(BERall(:,k)),EBNRdB,log10(BERlist),'linear');
      warning on
   end
   NbitsList = round(log2(Nconstellation(ModNumberList)));
   bits = bits + sum(sum(NwordsUsed.*repmat(NbitsList,size(NwordsUsed,1),1)));
end
Precision = 0.05;
ModString = {'BPSK','QPSK','16QAM','64QAM','256QAM'};
fid = fopen(FileName,'w');
for m = 1:NumMods
   RefNoChanNoise = repmat(EBNRcutoff(1,:,m),size(EBNRcutoff,1)-1,1);
   RefDetrement = round((EBNRcutoff(2:end,:,m)-RefNoChanNoise)/Precision)*Precision;
   fprintf(fid, [ModString{m} ,'\r\n']);
   fprintf(fid, '#ref, ');
   fprintf(fid,'%6.0d, ',BERlist);
   fprintf(fid,'\r\n');
   for k = 1:size(RefDetrement,1)
      fprintf(fid, '%4g, ', NumRefList(k+1));
      fprintf(fid, '%6.2f, ', RefDetrement(k,:));
      fprintf(fid,'\r\n');
   end
end
fclose(fid);

disp(['Results saved in file : ' FileName]);
disp(['Total Bits based on NwordsUsed : ' num2str(bits)])