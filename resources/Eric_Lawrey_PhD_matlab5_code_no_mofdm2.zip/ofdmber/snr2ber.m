function BERinterp = snr2ber(SNR,ModEff)
%SNR2BER Find the BER for a particular SNR for coherent modulation
% BER = snr2ber(SNR,ModEff)
% This assumes perfect timing, and synchronisation. These results are
% form previously simulated results stored in s0041_coh_qam.
%
% This gives the BER for coherent QAM modulation. i.e.
% ModEff   Modulation Scheme
%   1          BPSK
%   2          QPSK
%   3          8QAM (Optimal)
%   4          16QAM
%   5          32QAM
%   6          64QAM
%   7         128QAM
%   8         256QAM
%   9         512QAM
%  10        1024QAM
%  11        2048QAM
%  12        4096QAM
%
% Each of the even number of bit modulation schemes (ModEff = 2,4,6,8,10,12) 
% used gray coding to minimise their BER. The odd modulation schemes used
% linear mapping between the data words and the IQ constellation.
%
% Interpolation is used to estimate the BER from the simulation table.
%
% The BER is only valid down to approximately 1e-6. The simulation is 
% valid for EBNR down to -6dB, thus the lower limit for the SNR depends 
% on the modulation scheme. For 8 bits/Hz this limit is 3dB. Below this 
% limit linear extrapolation is used. This appears to be reasonably good 
% to -6dB. The error rate is capped at a BER of 0.5
%
% BER below the simulation threshold (about 1e-6) will return a NaN.
%
% If ModEff is a matrix than SNR should be a matrix of the same size

% Copyright (c) Eric Lawrey 2001
% James Cook Univerisity
% Email: Eric.Lawrey@jcu.edu.au

load s0041_coh_qam
ModBitsHz = log2(Nconstellation(ModNumberList));

if length(ModEff(:))>1
   if size(ModEff)~=size(SNR)
      error('ModEff must be the same size as SNR, if they are both vectors or matrices')
   end
   ModList = unique(ModEff(:));
   BERinterp = zeros(size(SNR));
   %Use a recursive alogorithm to minimise code duplication
   for k = 1:length(ModList)
      DataIndex = find(ModEff==ModList(k));
      BERinterp(DataIndex) = snr2ber(SNR(DataIndex),ModList(k));
   end
else
   ModIndex = find(ModEff==ModBitsHz);
   if isempty(ModIndex)
      error(['No Modulation found to match given Modulation Efficiency (' num2str(ModEff)]);
   end
   if length(ModIndex)>2
      error('Duplicate Modulation scheme found (This shouldn''t happen)');
   end
   
   EBNR = SNR-10*log10(ModBitsHz(ModIndex));
   BER = BERall(:,ModIndex);
   I = find(BER>0);
   EBNRI = EBNRdB(I);
   BERinterp = 10.^(interp1(EBNRI,log10(BER(I)),EBNR,'linear'));
   IlowEBNR = find(EBNR<min(EBNRI));
   if length(IlowEBNR)>0
      P = polyfit(EBNRI(1:2),BER(1:2)',1);
      BERinterp(IlowEBNR) = min(polyval(P,EBNR(IlowEBNR)),0.5);
   end
end

