%S0012_BERWRITE Converts saved BER data from s0041_ofdmsim as a comma separated file.
%This script converts the Bit Error Rate and Symbol Error Rate data from
%the stored simulation results which are stored in Mat files. To a comma 
%separated file which can be loaded into a spead sheet package.

%List of files to convert, from stored simulation results to text file format
file_list = {'s0041_coh_psk.mat', 's0041_coh_qam.mat', 's0041_diff_psk.mat', ...
      's0041_diff_qam.mat'};

%Filename of the text files to generate
filename = {'s0012_coh_psk.txt','s0041_coh_qam.txt', 's0041_diff_psk.txt', ...
      's0041_diff_qam.txt'};
for f = 1:length(file_list)
   load(file_list{f})
   fid = fopen(filename{f},'w');	%Open the text file for writing
   
   %Print the Title of each column of data, which is the name of the 
   %modulation scheme.
   fprintf(fid,' EBNR (dB), ');
   for k = 1:length(ModsUsed)
      fprintf(fid,'%11s, ',ModsUsed{k});
   end
   
   fprintf(fid,'\r\n');		%New line
   
   %Print the table out to the file
   for k = 1:length(EBNRdB)
      fprintf(fid,'%10.2f, ', EBNRdB(k));
      for l = 1:size(BERall,2)
         if BERall(k,l) > 0
            fprintf(fid,'%11.4e, ', BERall(k,l));
         else
            fprintf(fid,'%11s, ','');
         end
         
      end
      fprintf(fid,'\r\n');
   end
   fclose(fid);
end