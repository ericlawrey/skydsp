%NEWSIM Sets up new simulation file for study BER verses Noise for OFDM
% This script simulates and measures the Bit Error Rate and Symbol Error Rate for a range of 
% modulation schemes. This simulation measured the performance as a function of white guassian
% noise and assumes, zero frequency error, zero timing errors, no
% distortion. The values in old simulations can be looked at by loading them into the matlab
% work space, i.e. load xxxx.mat
% A particular variable can be modified by using:
% variable = new value;
% save xxxx.mat variable -append 
%
% Copyright Eric Lawrey June 2001

%Tested configurations
%OFDM BPSK Coherent
%	'complex', Ncarriers = 2,8,24, IFFTsize = 32
%BPSK Coherent NO OFDM, verified against theory
%BPSK Differential NO OFDM, verified against theory
%BPSK Coherent, Differential with OFDM, real and complex, verified to match with no OFDM
% tested for IFFTsize of 1,2,8,64
%QPSK coherent, OFDM, and No OFDM, verified to have the same BER for the same EBNR as BPSK

%==============================================
%		Reference Initialisation
%==============================================
%List of all modulation scheme that can be simulated. This list is actually determined
%by the modulator (data2iqmap) and demodulator (iq2data) scripts.
ModType = {'BPSK', 'QPSK', 'S8QAM', '8QAM', '16QAM', '32QAM', '64QAM', '128QAM', '256QAM','512QAM',...
      '1024QAM','2048QAM','4096QAM','8PSK', '16PSK', '32PSK', '64PSK', '128PSK', '256PSK'};
Nconstellation = [ 2 4 8 8 16 32 64 128 256 512 1024 2048 4096 8 16 32 64 128 256];

%ModCatergory is a list indicating for each modulation type what type of transmitter 
%and receiver are needed.
%	0	PSK
%	1	Square QAM
%	2	Other type of QAM (i.e. odd number of bits)
ModCatergory = [0 0 2 2 1 2 1 2 1 2 1 2 1 0 0 0 0 0 0];

%==============================================
%		Simulation data
%==============================================
%Actual modulation schemes to simulate. Put the index (corresponding to ModType) of the
%modulation schemes to simulate. If the simulation is run in parallel on several
%computers each one can be made to simulation just a couple of modulation schemes.
%For example: ModNumberList = [2,4,5]; will simulate QPSK, 8QAM, and 32QAM.
ModNumberList = [5]; %[1,2,5,7,9,11,13];

SNRtest = 0;		%Use SNR instead of energy per bit to noise ratio, if SNRtest = 0
%                  simulate EBNR, if SNRtest = 1, simulate SNR. The simulated values 
%                  used are in EBNRdB regardless of SNRtest.

%Energy per Bit to Noise Ratio (EBNR) in dB is the list of noise levels to 
%simulate. This list is sorted into increasing order so that if the
%simulation gets zero errors for two successive tests, it assumes that because the
%EBNRdB is increasing, the rest of the test will also give zero. This assumption greatly 
%speeds up the simulation, when trying to compare low and high modulation schemes.
EBNRdB = [200]; %-10*log10(1+2/IFFTsize);%4:0.25:4.5115;

MaxRuns = 1000;	%Number of times to simulate all modulation schemes before
						%finally quitting.
Nwords = 10000;	%Number of words to simulate for each test.
MaxTests = [ones(1,length(ModNumberList))*25];		
%						Maximum number test runs to perform (Nwords each test) before moving to 
%						next SNR. MaxTests can be made an array allowing the maximum test
%						to be specified for each modulation scheme. This is usefile for simulation
%						all the modulation schemes, as some of the them simulate much faster than
%						others. 2048QAM is especially slow.
BitsReq = 1000;	%Number of error bit to accumulate before moving to the next SNR

BitSimThreshold  = 100000;	%Total number of simulated bits before checks are made into
%									whether the BER is too low to bother simulating each EBNR.
PrevENBRcheck = 1;	%Number of lower EBNR simulations which must have 0 errors before
%							deciding that there is no point simulating that EBNR, as the error rate
%							is too low. 

DispRate = 1;		%Number of tests to perform (each test simulates Nwords) before displaying an
%						update of simulation progress

OFDMflag = 1;		%Flag to indicate whether to use OFDM modulation (1) or baseband matched
%						 filter simulation (0). Base band match filter is a single carrier transmission
%                  centred at DC (no actual carrier). It is un-bandpass filtered in the channel
%                  and decoded using and integrate and dump matched filter. Theoretically this
%                  single carrier transmission should have the same performance as OFDM.  
Ncarriers = 100;	%Number of subcarriers for the OFDM simulation
IFFTsize = 512;	%IFFT size to use, this determines the oversampling of the waveform
%						For real waveform simulation Ncarriers must be < IFFTsize/2
GuardPeriod = 32;	%Guard Period (Flat Guard Period) (samples)
RealComplex = 'complex';	%Whether to use a real OFDM waveform (no complex components)
%						or a complex waveform. The output of a DSP to go into a digital upconverter
%    					is always a complex signal. However the output RF signal is always real.
%						Complex must be used if the signal is centred around DC. Use 'real', for real,
%						and 'complex' for complex.
fast_mode = 1;		%Flag to set whether input checking is done in OFDMMOD. Use 0 = debug mode.
%						Doesn't make much different to speed for vectorised code.
FileOut = 's0041_test.mat';	%Name of the simulation file to generate
DiffFlag = 0;		%1 = Use differential modulation, Differentially coherent detection of 
%						differentially encoded PSK
%						0 = Use absolute vectors, Coherent detection of PSK
% See Sklar,B, "Digital Communications, Fundamentals and Applications", Prentice Hall, New Jersey, 
% 1988, pg 161, for explaination

TotalTime = 0;		%Keep a record of the simulation time (sec). This is simply for display purposes.

InLineChanChar = 1;	%NOTE: THIS IS CURRENTLY NOT IMPLEMENTED
%						Use Inline channel characterisation for coherent demodulation. This
%						means that noise on the channel will effect the accuracy of the characterisation.
%						Setting InLineChanChar will result in the characterisation being separate from
%						the main transmission and will not be sujected to noise.
%						Currently the channel equalisation used for the coherent demodulation is
%                 included in the transmission, and so is affected by the channel noise. The
%                 effect of channel noise can be minimised by either boosting the pilot
%                 symbol power (PilotPowBoost) or increase the number of pilot symbols at the
%                 start of each symbol (NumRefSymb)
%
NumRefSymb = 1;	%Number of reference pilot symbols to use. The more reference symbols the lower
%						the noise on the channel characterisation, as the measurements are averaged.
%						if NumRefSymb = 0 then don't use any equalisation, this only works if there
%						is no time errors, amplitude scaling, phase rotations etc. This is useful for
%                 measuring the ideal performance of OFDM in AWGN. With only the addition of
%                 AWGN, there is no channel distortion and hence no need for equalisation. 
%						This is only used for coherent modulation, i.e. if DiffFlag = 0
%
PilotPowBoost = 1;	%Number of times more power is put into the reference symbols. Again only
%						used for coherent modulation, (linear). Boosting the pilot power reduces the
%                 efects of channel noise on the channel equalisation.
%
RefScheme = 1;		%Reference Pilot Symbol Scheme, See Genref for more details.
% 						RefScheme 
%   					0 - S. Narahashi and T. Nojima phasing scheme
%   					1 - Use the low crest factor phasing scheme developed
%       					using genetic algorithms. This algorithm only allows
%       					for carrier numbers which have been simulated and stored
%       					in s0019_low_CF_DMT_phase_table.mat.
%   					2 - Use random phase angles
%============Not Implemented Yet====================
%Multipath simulation
Ntaps = 40;					%Number of taps to use in the multipath impulse.
delspread = 3;				%Time constant of the exponential impulses
dellist = [1 16 25];		%Time of the impulses
decay = 16;					%Overall decay
limits = [0.1 0.9];		%Limits to use for calculating the delay spread
%===================================================
%Distortion simulation
ClipDistFlag = 1;	%Flag to turn on signal clipping. 1 - Enable signal clipping. This is to
%						simulate distortion in the output transmitter amplifier. 0 - disable clipping
OutBackoffdB = [4];	%Amount of power backoff from peak power, before the signal is clipped (dB).
%						For example, if OutBackoffdB = 10dB, then the signal is clipped until the
%						Output Power Backoff is 10dB. 
%==============================================================
%	These variables keep a record of the simulation progress
%==============================================================
if (length(OutBackoffdB) > 1)
   errorstotal = zeros(length(EBNRdB),length(ModNumberList),length(OutBackoffdB));
else
   errorstotal = zeros(length(EBNRdB),length(ModNumberList));
end

NwordsUsed = errorstotal;
biterrors = errorstotal;
BERall = errorstotal; 
SERall = BERall; 
totbitsim = 0;		%Set the bit simulation counter to zero
ModIndex = 1;		%Current modulation being simulated
NumRuns = 0;		%Number of simulation runs currently performed
EBNRIndex = 1;		%Initialise the EBNR simulation index
BackOffIndex = 1;	%Initialise the BackOff index
TotalTime = 0;		%Initialise the timer to zero
SaveFlag = 1;
if exist(FileOut,'file')
   Button = questdlg(['Do you want to overwrite existing simulation file ?' 10 ...
         'file : ' FileOut],'Replace File','Replace','Cancel','Replace');
   switch Button
   case 'Replace'
      SaveFlag = 1;
   case 'Cancel'
      SaveFlag = 0;
   end
end
if DiffFlag
   ModsUsed = cell(1,length(ModNumberList));
   for k = 1:length(ModNumberList)
      ModsUsed{k} = ['D' char(ModType(ModNumberList(k)))];
   end
else
   ModsUsed = ModType(ModNumberList);
end

   
if SaveFlag
   save(FileOut, 'ModType','Nconstellation','ModCatergory','Nwords','MaxTests','BitsReq','DispRate',...
      'OFDMflag','Ncarriers','IFFTsize','GuardPeriod','RealComplex','fast_mode','DiffFlag',...
      'SNRtest','EBNRdB','ModNumberList','errorstotal','NwordsUsed','biterrors','BERall',...
      'SERall','totbitsim','Ntaps','delspread','dellist','decay','limits','MaxRuns','NumRuns',...
      'ModIndex','EBNRIndex','ModsUsed','TotalTime','InLineChanChar','NumRefSymb','RefScheme',...
      'BitSimThreshold','PrevENBRcheck','ClipDistFlag','OutBackoffdB','BackOffIndex','PilotPowBoost');
   disp(['New simulation file saved to ', FileOut])
else
   disp('No simulation file saved')
end