%plotresults
% This script plots the BER performance to the simulation GUI

axes(h_axes1);	%Set the current axes to the top right one in the GUI
if length(OutBackoffdB) > 1
   %This will not work if both OutBackoffdB and EBNRdB is varied
   if length(EBNRdB) >1
      error('The simulation can not plot multiple EBNRdB and multiple OutBackoffdB')
   end
   h = semilogy(OutBackoffdB,squeeze(SERall));
   set(h_OutBackoffdBText,'visible','on')
else
   h = semilogy(EBNRdB,SERall);
   set(h_OutBackoffdBText,'visible','off')
end
legend(h,ModsUsed,3);
grid on;
title(['Symbol Error Rate']);
if length(OutBackoffdB) > 1
   xlabel('Output Back off (dB)')
else
   if SNRtest == 0
      xlabel('Energy per bit to Noise Ratio (dB)');
   else
      xlabel('SNR (dB)');
   end
end
axis tight
ylabel('Symbol Error Rate');

axes(h_axes2);
if length(OutBackoffdB) > 1
   %This will not work if both OutBackoffdB and EBNRdB is varied
   if length(EBNRdB) >1
      error('The simulation can not plot multiple EBNRdB and multiple OutBackoffdB')
   end
   h = semilogy(OutBackoffdB,squeeze(BERall));
   set(h_OutBackoffdBText,'visible','on')
else
   h = semilogy(EBNRdB,BERall);
   set(h_OutBackoffdBText,'visible','off')
end
legend(h,ModsUsed,3);
grid on;
title(['Bit Error Rate']);
if length(OutBackoffdB) > 1
   xlabel('Output Back off (dB)')
else
   if SNRtest == 0
      xlabel('Energy per bit to Noise Ratio (dB)');
   else
      xlabel('SNR (dB)');
   end
end
ylabel('Bit Error Rate');
drawnow


