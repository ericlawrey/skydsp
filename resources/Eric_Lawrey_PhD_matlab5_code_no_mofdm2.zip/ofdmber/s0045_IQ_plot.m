%This script plots and saves diagrams of all the modulation schemes that data2iqmap
%can generate. This is a list of the most common modulation schemes used in OFDM
%transmission.
%
%Copyright Eric Lawrey April 2001
ModType = {'BPSK', 'QPSK', 'S8QAM', '8QAM', '16QAM', '32QAM', '64QAM', '128QAM', '256QAM','512QAM',...
      '1024QAM','2048QAM','4096QAM','8PSK', '16PSK', '32PSK', '64PSK', '128PSK', '256PSK'};
for k = 1:length(ModType)
   data2iqmap(ModType{k});		%This plots the IQ map for the modulation scheme. See
   %									data2iqmap help
   setplotsize(700,660)
   savefig(['s0045_' ModType{k} '_IQ_Plot'])	%Save the figure to tif and emf
end
