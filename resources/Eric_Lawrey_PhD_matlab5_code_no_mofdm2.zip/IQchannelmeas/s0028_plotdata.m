function s0028_plotdata
%This funcion plots the radio channel measurements made. It reads in comma separated
%data captured from the Tektronix Digital CRO TDS 380 in spread sheet compatible format
%and plots the results, ready for inclusion into the thesis. 
% 
%USES:
% SETPLOTSTYLE
% SAVEFIG
% BLACKH4
%Copyright (c) 2000 Eric Lawrey 

%These flags determine which sets of data are plotted.
FreqPlotFlag = 0;		%Flag sets whether to plot frequency data
TimePlotFlag = 1;		%Flag sets whether to plot time data
SpecgramFlag = 0;		%Flag sets whether to plot specgram of the IQ channel
SavePlotFlag = 0;		%Flag to enable (1) or diable saving of the plots
ColourMap = 'hot';	%Colour map to use for plotting the specgram
CRange = [-40 0];		%Range for the specgram in dB for normalised data.
DopplerAxis = [-85 -5];	%Yrange for the doppler spread plot
ImpYlim = [-150 -70];
SaveFormat = {'jpg','emf'};
prefix = 'tek';
postfix = '.csv';
%Each channel measurement uses several files. The result from the network 
%analyser was I and Q of the channel which were stored in separate files. 
%These files are read in as pairs. 
%Filenums = [I1 Q1 I2 Q2 I3 Q3 ....]. 
Filenums =   [4   5   10  11  8   9   12  13  14  15  16  17  20  21  22  23  26  27  28  29 ...
      32  33  30  31  42  43  44  45  48  49  50  51  ]; %52  53];

%As well as this calibration data was captured to establish the zeroing of 
%the IQ data. This is very important as a slight offset in the
%zero, changes the depth of the frequency selective fading nulls very significantly. 
%The CalibNums specify the calibration files to use for each of the captured channel
%data. These are also in I Q pairs.
CalibNums =  [2   3   6   7   6   7   6   7   2   3   2   3   18  19  18  19  24  25  24  25 ...
      24  25  24  25  40  41  40  41  40  41  40  41  ]; %40  41];

%The gain setting of the spectrum analyser is sepcifed by Gain, and is used to scale
%the channel gain so that results taken with different gain settings can be compared.   
Gain = 		 [-20     -30     -30     -30     -20     -20     -15     -15     -10     -10     ...
      -10     -10     -14     -20     -5      -5      ]; %dB %-10  -10];
%TimeFreqFlag specifies if the data captured was a frequency sweep or a time sweep. This
%script creates different plots depending on whether the data is time or freq data.
%1 - Time data, 0 - Freq sweep
TimeFreqFlag = 	 [1       1       1       1       1       1       1       1       1       1       ...
      1       1       0       0       0       0       ]; %0];
% TimeFreqFlag - Specifies whether the plot is a time (zero span), 
%  TimeFreqFlag = 1, or frequency plot, TimeFreqFlag = 0. 
%  TimeFreqFlag can be a singular value (All plots will be the same), or 
%  a vector specifying for each file whether it is a time or frequency plot

%Because of the hardware setup the capture data from the digital CRO does not 
%specify the frequency sweep information. StartFreq is the frequency corresponding
%to the start of the frequency sweep.
StartFreq =  [0       0       0       0       0       0       0       0       0       0 ...
      0       0       600e6   800e6   800e6   800e6   ]; %800e6];
%BW is the bandwidth of the sweep. This is used to calculate the ranges of frequencies
%captured
BW = 			 [0       0       0       0       0       0       0       0       0       0 ...
      0       0       500e6   200e6   200e6   200e6   ]; %200e6];
%The CRO and the spectrum analyser were not time locked to each other. The faster the sweep
%time on the spectrum analyser the shorter the time waveform on the CRO. The sweep rate was
%adjusted so that it covered most the capture time of the CRO, however to obtain better
%estimation of the actual frequency for each data point, the time at which the sweep completed
%was estimated by looking at the captured data. FreqPoints is the number of data points over
%which the frequency sweep occured. For analysing new data set this to 1000 (number of 
%data points from the Tektronix TDS380) and zoom in to find out where the sweep completed.
FreqPoints = [1000*ones(1,length(BW)-4)   892 960 980 980];

%This section specifys line markers and text to be placed on each of the graphs
TextList = [1 2 3 4 5 6 8 9];	%This is the list of the plots to place the text on. Each element
% in TextList should have an entry in PlotText, BoundaryTimes, TextY, and TextX

%List of x locations to place a vertical line, to mark boundaries of different sections of the
%waveform
BoundaryTimes = {...
      [1.0 4.6 5.7 9.5],...
      [1.1 4.3 5.5 9.0],...
      [2.9 4.2 5.6],...
      [2.8 3.5 8.5],...
      [2.2 4 5.2],...
      [3.6 4.2 9.0],...
      [4.4 5.3],...
      [3.1 4.1 9]};
%Text to place of the graphs. The number of text string for each graph must
%match the number specified in TextY and TextX
PlotText = {{'pause', 'walk to tx','paused','walk back to start'}...
      {'pause', 'walk to tx','paused','walk back to start','pause'}...
      {'Walk to tx', '& sat down', 'lent', 'forward','paused','pretend typing'}...
      {'Walk from (1) to (2)', 'P','Walk from (2) to (3)','pause'}...
      {'Walk to tx', '& sat down', 'lent forward','paused','pretend typing'}...
      {'Walk from (1) to (2)', 'P','Walk from (2) to (3)','pause'}...
      {'Walk from (1) to (2)', 'P','Walk from (2) to (1)'}...
      {'Walk from (1) to (2)', 'P','Walk from (2) to (3)','pause'}};
%Location to place the text
TextY = {...
      [-57.5 -57.5 -56.5 -57.5],...
      [-76 -76 -76 -76 -76],...
      [-103 -107.5 -103 -107.5 -105 -105],...
      [-64 -76 -77 -76],...
      [-62.5 -63.4 -57.5 -63 -63]...
      [-60.4 -57.5 -60.4 -60.4]...
      [-84 -84 -84]...
      [-47 -85 -85 -85]};
TextX = {...
      [0.1 2.5 4.65 6.3],...
      [0.1 2.5 4.35 6.3, 9.1],...
      [0.3 0.3 2.95 2.95 4.3 6.5],...
      [0.1 3 4.2 8.7],...
      [0.2 0.2 2.3 4.1 6.1],...
      [0.1 3.7 6.1 9.1]...
      [0.5 4.6 7.1]...
      [0.1 3.2 4.2,9.1]};

LoopGain = 27;			%Overall Loop gain of the system in dB, antennas, coax, pre-amp, etc
Gain = Gain-LoopGain;
%The Descript are added as the title of each plot 
Descript = 	 {'(Local Maxima) Walked to tx, stopped, walked back to start';...
      '(Local Minima) Walked to tx, stopped, walked back to start';...
      '(Local Minima) Walked to tx, sat down and pretended to type';...
      '(Local Minima) Walking in the same room as Tx and Rx in an L shape';...
      '(Local Maxima) Walked to tx, sat down and pretended to type';...
      '(Local Maxima) Walking in the same room as Tx and Rx in an L shape';...
      'Walked Tx across room and back again';...
      'Walked Tx across room and back again';...
      'Walked with the Tx in an L shape';...
      'Waved Tx antenna backwards and forwards quickly at arms length';...
      'Waved Tx is half circular path, back and forth very quickly';...
      'Walked Tx out of room and back again';...
      '5.7m across room';...
      '5.7m across room';...
      '3.5m from receiver toward entrance door';...
      '5.5m outside room behind wall';...
   };  %'Averaged response over a 1.5m x 2m area';...
%TrackRate for each simulation specifies the number of samples between channel tracking.
%[min samples between tracking, maximum samples between tracking]
TrackRate = {[2,30],[2,30],[2,30],[2,30],[2,30],[2,30],[2,100],[2,30],[2,30],[2,30],[2,30],[2,15]};
TrackSimNum = 12;		%Number of tracking rate simulation to run between min TrackRate and max TrackRate
%							The actual Track Rates used is derived from intlogspace(TrackRate(1),TrackRate(2),TrackSimNum)

%This is a list of files to compare when looking at the RMS Power error due to
%changing the tracking rate. The numbers correspond to the file processing order
%not the number in the file names
TrackPlotList = {[1 2],...
      [5 3],...
      [6 4],...
      [7 8 9 12]};

LegendPos = [1 1 1 1 ];
LegendList = {...
      {'Local Maximum', 'Local Minimum'}...
      {'Local Maximum', 'Local Minimum'}...
      {'Local Maximum', 'Local Minimum'}...
      {'Across Room (500 S/s)','Across Room (100 S/s)', 'In L shape (100 S/s)','Out of room (50 S/s)'}};

DescriptComp = {'Walked to tx, stopped, walked back to start',...
      'Walked to tx, sat down and pretended to type',...
      'Walking in the same room as Tx and Rx in an L shape',...
      'Walking with the transmitter'};
DistribList = 1-[0.9 0.98 0.995 0.999];	%Record the Tracking Error for these probability distribution levels
LegendDist = {'90%','98%','99.5','99.9%'};	%Legend string for track error plots

% Filenames - cell array containing the filenames of the files to plot
% For Example:
% Filenames = {'c:\uni2000\measurements\test.txt',...
%              'test2.txt'; 'test3.txt', 'test4.txt'}
% filenames has two rows. The file pairs are treated as I Q data.
Filenames = cell(2,length(Filenums)/2);
Savenames = cell(2,length(Filenums)/2);
%Calib files
CalibFiles = cell(2,length(Filenums)/2);
LogList = [1 2 3 4 5 6 7 8 10 15 20 30 50 70 100 150 200 300 400 500];
z = '00000';
for l = 1:2
   for k = 1:2:length(Filenums)
      s = num2str(Filenums(k+l-1));
      zn = z(1:(5-length(s)));
      Filenames{l,(k+1)/2} = [prefix zn s postfix];
      Savenames{l,(k+1)/2} = [prefix zn s];
      s = num2str(CalibNums(k+l-1));
      zn = z(1:(5-length(s)));
      CalibFiles{l,(k+1)/2} = [prefix zn s postfix];
   end
end

%If TimeFreqFlag is a singular value make it a vector, so there is one value for each
%filename
if length(TimeFreqFlag) == 1
   disp('Length = 1')
   TimeFreqFlag = ones(1,size(Filenames,2))*TimeFreqFlag;
end

%Check that we have the correct number of TimeFreqFlag
if (length(TimeFreqFlag) ~= size(Filenames,2))
   error('The length of TimeFreqFlag does not match the number of files given in Filenames');
end

%N = 1024;
GainLin = 10.^(Gain/10);


NtimePlots = sum(TimeFreqFlag);
RMSPowErrList = cell(1,NtimePlots);
SampTime = cell(1,NtimePlots);


%Data is complex and two files must be loaded
for k = 1:size(Filenames,2)
   if ((TimeFreqFlag(k) == 1)&(TimePlotFlag))|((TimeFreqFlag(k) == 0)&(FreqPlotFlag))
      disp(['Horz : ' Filenames{1,k}])
      Horz = rddata(Filenames{1,k}); 
      disp(['Horz Calib : ' Filenames{1,k}])
      HorzCalib = rddata(CalibFiles{1,k});
      disp(['Vert : ' Filenames{1,k}])
      Vert = rddata(Filenames{2,k});
      disp(['Vert Calib : ' Filenames{1,k}])
      VertCalib = rddata(CalibFiles{2,k});
      %Average the calibration data. It should be constant over the sample data
      Hcalib = mean(HorzCalib(:,2));
      Vcalib = mean(VertCalib(:,2));
      Time1 = Horz(:,1);
      Time2 = Vert(:,1);
      if sum(Time1-Time2) > eps*1e6
         disp('Problem with the Horz and Vert data files, time scales don''t match');
         error(['Vert : ' Filenames{2,k} ', Horz : ' Filenames{1,k}])
      end
      
      ComplexData = (Horz(:,2)-Hcalib+(Vert(:,2)-Vcalib)*sqrt(-1))*sqrt(GainLin(k));
      
      if TimeFreqFlag(k) == 0
         Time1 = linspace(StartFreq(k),StartFreq(k)+BW(k),FreqPoints(k));
         ComplexData = ComplexData(1:FreqPoints(k));
      end
      %if k==7
      %   ComplexData = filtfilt(ones(1,10)/10,1,ComplexData);
      %end
      %if k==8
      %   ComplexData = upsamp(ComplexData,5);
      %   Time1 = linspace(min(Time1),max(Time1),length(Time1)*5);
      %end
      
      Power = 10*log10(abs(ComplexData).^2)';
%      Power = filtfilt(ones(1,10)/10,1,Power);
      %=========================================
      % Signal Power verses Time or Frequency
      %=========================================
      %Plot the data
      figure(1);
      subplot(2,1,1)
      h = plot(Time1,Power);
      set(h,'linewidth',2)
      axis tight
      title([Descript{k}]);
      if TimeFreqFlag(k) == 1
         xlabel('Time (sec)');
         ylabel('Power (dB)');
      else
         xlabel('Frequency (Hz)');
         ylabel('Power (dB)');
      end
      xlim([min(Time1),max(Time1)])
%      setplotstyle
      %=================================
      % Add text to the plot
      %=================================
      ind = find(k==TextList);
      if ~isempty(ind)
         XT = TextX{ind};
         YT = TextY{ind};
         S = PlotText{ind};
         text(XT,YT,S,'fontsize',18)
         hold on
         BT = BoundaryTimes{ind};
         B = repmat(BT,2,1);	%Make two rows
         yl = ylim;
         Y = [ones(1,length(BT))*yl(1); ones(1,length(BT))*yl(2)];
         %B
         %Y
         h = line(B,Y);
         %makearrow
         set(h,'color',[1,0,0],'linewidth',3)
         hold off
      end
      
      grid on
      
      %============================================
      % Plot phase verses time or frequency
      %============================================
      subplot(2,1,2)
      plot(Time1,unwrap(angle(ComplexData),0.95*pi));
      xlim([min(Time1),max(Time1)])
      %Set the font size, and line widths
      if TimeFreqFlag(k) == 1
         xlabel('Time (sec)');
         ylabel('Phase (Radians)');
      else
         xlabel('Frequency (Hz)');
         ylabel('Phase (Radians)');
      end
      grid on
      setplotstyle
      
      %This works best at screen resolutions >= 1024x768
      if SavePlotFlag
         savefig(['s0028_' Savenames{1,k} '_PowPhase'],SaveFormat);
      end
      
      %pause
      
      %================================================
      % Tracking Error Calculation and plotting
      %================================================
      if TimeFreqFlag(k) == 1
         TR = intlogspace(TrackRate{k}(1),TrackRate{k}(2),TrackSimNum);
         RMSPowerr = zeros(1,length(TR));         
       	EstError = zeros(length(TR),length(DistribList));
         for t = 1:length(TR)
            RMSPowerrTemp = zeros(1,TR(t)-1);
            TrackError = [];	%This is very poor coding, but will work
            %Average the error for going through all possible sample offsets.
            %This is to get a better averaging of data
            for o = 1:(TR(t)-1)
               Powert = Power(o:end-TR(t)+o-1);
               PowerSamp = Powert(1:TR(t):(end-TR(t)+1));	%Decimate the measured data
               r = repmat(PowerSamp,TR(t),1);	%Duplicate is back up to the
               PS = reshape(r,1,length(r(:)));			%measured rate to calc the error
               
               Power2 = Powert(1:length(PS));
               TrackError(o,:) = Power2-PS;		%This will be slow but will work.
               
               %plot(TrackError(o,:));
               %xlabel(['Track Period: ' num2str(TR(t)) ', Offset: ' num2str(o)])
               %pause
               RMSPowerrTemp(o) = sqrt(mean((Power2-PS).^2));
            end
            %plot(TrackError.');
%            T = TrackError(:);
%            ind = find(T==0);
%            T(ind) = [];
%            [N,X] = hist(T,100);
%            stairs(X,N/sum(N));
%            set(gca,'yscale','log');
%            ylim([1e-4, 1])
%            xlabel(['Tracking step: ' num2str(TR(t)) ', Std: ' num2str(std(T)) ', TR: ' num2str((1/(Time1(2)-Time1(1)))./TR(t))])
%            if (k == 7)|(k==8)
%               pause
%            end
            
            [Y,I] = sort(TrackError(:));
			
				for k1 = 1:length(DistribList)
				   EstError(t,k1) = Y(round(DistribList(k1)*length(Y)));
				end
            RMSPowerr(t) = mean(RMSPowerrTemp);
            %disp(['Calculated Rate ' num2str(t) ' of ' num2str(length(TR)) ]); 
         end
         figure(6)
         TrackRate2 = (1/(Time1(2)-Time1(1)))./TR;
         %plot(1./TrackRate2,RMSPowerr,'.b-');
         if k == 7
            disp('dsfs')
         end
         MarkerList = {'none','o','x','^','d','s'};
         colourlist = {'r',[0 0.8 0],'b','k','m','c','y'};
         
			%         semilogx(TrackRate2,RMSPowerr,'b-');
			hs = semilogx(TrackRate2,EstError);
         for ks = 1:length(hs)
            set(hs(ks),'marker',MarkerList{ks},'color',colourlist{ks});
         end
         
         g = get(gcf,'currentaxes');
         x = [min(TrackRate2) max(TrackRate2)];
         ind = find(LogList>=x(1)&(LogList<=x(2)));
         %Find a list of log tick mark numbers which match the plot
         %Matlab seems to have a bug in that if you set the tick marks
         %to a value smaller than the x scale left hand size it places
         %all the tick marks at the wrong location
         set(g,'xtick',LogList(ind))
         axis tight
         title(Descript{k})
         %xlim([min(1./TrackRate2),max(1./TrackRate2)]);
         xlabel('Tracking Sample Rate (Hz)');
         ylabel('Tracking Error (dB)');
         %Set the font size, and line widths
         grid on
         legend(hs,LegendDist,1);
         setplotstyle(1.5,1,15)
         if SavePlotFlag
            savefig(['s0028_' Savenames{1,k} '_Track'],SaveFormat);
         end
%         if (k==7)|(k==8)
%            pause
%         end
         
      RMSPowErrList{k} = RMSPowerr';
      SampTime{k} = (1./TrackRate2)';   
      end
      
      
      
      %=========================================================
      % Plot Doppler (change in phase with time) and I Q data
      %=========================================================
      Nsamp = 8;		%Use the phase difference between Nsamp time samples
      if TimeFreqFlag(k) == 1
         %Time data
         figure(2)
         subplot(2,1,1)
         uph = unwrap(angle(ComplexData),0.95*pi);
         phdiff = -uph(1:end-Nsamp)+uph(Nsamp+1:end);	%Radians/sample
         tstep = (Time1(Nsamp+1)-Time1(1));
         Doppler = phdiff/tstep/(2*pi);			%Doppler in Hz
         plot(Time1((1:end-Nsamp)+round(Nsamp/2)),Doppler);
         axis tight
         title(Descript{k})
         xlim([min(Time1),max(Time1)]);
         xlabel('Time (sec)');
         ylabel('Doppler (Hz)');
         %Set the font size, and line widths
         grid on
         setplotstyle
         
         subplot(2,1,2)
         h = plot(Time1,real(ComplexData),'r',Time1,imag(ComplexData),'b');
         axis tight
         xlabel('Time (sec)')
         ylabel('Rx Amplitude')
         xlim([min(Time1),max(Time1)]);
         grid on
         legend(h,'real','imag')
         setplotstyle
         set(h(2),'linewidth',1)
         legend
         
         %This works best at screen resolutions >= 1024x768
         if SavePlotFlag
            savefig(['s0028_' Savenames{1,k} '_Doppler'],SaveFormat);
         end
         
         %=================================
         % Plot doppler spectrum
         %=================================
         figure(3)
         clf
         imagData = ComplexData;
         M = 4096; 
         wd = (imagData.*(blackh4(length(imagData))));
         fftData = fft(wd,M);
         t = linspace(min(Time1),max(Time1),M);
         Fs = 1/(Time1(2)-Time1(1));
         Freq = linspace(-Fs,Fs,M);
         h = plot(Freq,20*log10(fftshift(abs(fftData))),'b');
         axis tight
         title(Descript{k})
         xlabel('Doppler Frequency (Hz)');
         ylabel('Power Density (dB)');
         ylim(DopplerAxis)
         grid on
         setplotstyle
         if SavePlotFlag
            savefig(['s0028_' Savenames{1,k} '_DopplerSpec'],SaveFormat);
         end
         if SpecgramFlag
         figure(4)
         Fsize = 256;
         RMSSig = sqrt(mean(abs(ComplexData).^2))*sqrt(Fsize)*2;
         [B,F,T] = specgram(ComplexData/RMSSig,Fsize,Fs,kaiser2(Fsize/4,'width',2),Fsize/4-1);
         %size(B)
         
         %         size(B((Fsize/2+1):end,:)) 
         %         size(B(1:Fsize/2,end))
         %Only show the frequencies centered around 0 Hz, to show the doppler better
         I1 = (3/4*Fsize):Fsize;
         I2 = 1:Fsize/4;
         F1 = [0:(Fsize/2) -((Fsize/2)-1):1:-1]*Fs/Fsize; % linspace(0,,Fsize);
         F2 = [F1(I1) F1(I2)];
         %Fs
         B2 = [B(I1,:); B(I2,:)];
         imagesc(T,F2,20*log10(abs([B(I1,:); B(I2,:)])));
         xlabel('Time (sec)')
         ylabel('Doppler Spectrum (Hz)')
         %imagesc(T,F2,20*log10(abs(B)));
         caxis(CRange)
         %c = caxis;
         %caxis([c(2)-50 c(2)]);
         h = colorbar('vert')
         h_cb = get(h,'ylabel');
         set(h_cb,'string','Power (dB)');
         title(Descript{k})
         setplotstyle   
         if SavePlotFlag
            savefig(['s0028_' Savenames{1,k} '_DopplerSpecGram'],SaveFormat);
         end
         end
      %   Dop = zeros(1,size(B2,2));
      %   for kf = 1:size(B2,2)
      %      Dop(kf) = sum(F2.*(abs(B2(:,kf)').^2))/sum(abs(B2(:,kf)).^2);
      %   end
      
      
      %   figure(5)
      %   plot(T,Dop);
         
         
      else
         figure(2)
         subplot(2,1,1)
         uph = unwrap(angle(ComplexData),0.95*pi);
         phdiff = uph(1:end-Nsamp)-uph(Nsamp+1:end);	%Radians/sample
         tstep = (Time1(Nsamp+1)-Time1(1))*2*pi;
         Doppler = phdiff/tstep;			%Doppler in Hz
         plot(Time1(round(Nsamp/2):end-round(Nsamp/2)-1),Doppler);
         title(Descript{k})
         axis tight
         xlim([min(Time1),max(Time1)]);
         xlabel('Frequency (Hz)');
         ylabel('Group Delay (sec)');
         %Set the font size, and line widths
         grid on
         setplotstyle
         
         subplot(2,1,2)
         h = plot(Time1,real(ComplexData),'r',Time1,imag(ComplexData),'b');
         axis tight
         xlim([min(Time1),max(Time1)]);
         xlabel('Frequency (Hz)');
         ylabel('Rx Amplitude');
         grid on
         legend(h,'real','imag')
         setplotstyle
         set(h(2),'linewidth',1)
         legend
         %This works best at screen resolutions >= 1024x768
         if SavePlotFlag
            savefig(['s0028_' Savenames{1,k} '_GroupDel'],SaveFormat);
         end
         
         %===============================================
         % Plot impulse response
         %===============================================
         figure(3)
         clf
         imagData = ComplexData;
         M = 4096; 
         N = 2;
         wd = (imagData.*(blackh4(length(imagData))));
         ifftData = fftshift(ifft(wd,M));
         Fs = BW(k)*2*M/length(imagData);
         t = (0:1/Fs:(length(ifftData)-1)*(1/Fs))*1e9;
         wd2 = (imagData);
         %ifftData2 = ifft(wd2,M);
         ifftData = ifftData(ceil(M/N/2)+1:ceil(M/N*1.5));
         t = t(1:length(ifftData));
         h = plot(t,20*log10(abs((ifftData(1:end)))),'b');
         axis tight
         title(Descript{k})
         xlabel('Time (nsec)');
         ylabel('Rx Amplitude');
         ylim(ImpYlim)
         grid on
         setplotstyle
         if SavePlotFlag
            savefig(['s0028_' Savenames{1,k} '_Impulse'],SaveFormat);
         end
         
      end
   end
end

if 0	%Dont run this code, too lazy to comment out
colourlist = 'rgbkmcy';
markerlist = '.x+^dsv';
for k = 1:length(TrackPlotList)
   figure(3)
   T = TrackPlotList{k};
   h = [];
   clf
   for l = 1:length(T)
      h1 = semilogx(1./SampTime{T(l)},RMSPowErrList{T(l)},[markerlist(l),colourlist(l) '-']);
      hold on
      h = [h h1];
   end
   hold off
   L = LegendList{k};
   legend(h,L,LegendPos(k));
   axis tight
   title(DescriptComp{k})
   %   xlim([min(1./TrackRate),max(1./TrackRate)]);
   xlabel('Tracking sample rate (Hz)');
   ylabel('RMS power error (dB)');
   %Set the font size, and line widths
   grid on
   setplotstyle(2,1,18)
   g = get(gcf,'currentaxes');
   x = xlim;
   ind = find(LogList>=x(1)&(LogList<=x(2)));
   %Find a list of log tick mark numbers which match the plot
   %Matlab seems to have a bug in that if you set the tick marks
   %to a value smaller than the x scale left hand size it places
   %all the tick marks at the wrong location
   set(g,'xtick',LogList(ind))
   if SavePlotFlag
      savefig(['s0028_' num2str(k) '_TrackComp'],SaveFormat);
   end
   
end
end
function Data = rddata(filename)
fid = fopen(filename,'r');
Data = [];
k = 1;
while 1
   line = fgetl(fid);
   if ~isstr(line), break, end
   Data(k,:) = str2num(line);
   k = k+1;
end
fclose(fid);