randn('seed',9873972)
s = randn(1,1000);
%s = sin(2*pi*(1:2^13)*0.01);
[b,a] = butter(2,0.02);
s2 = filter(b,a,s);
%plot(s2)
Order = 2;
BackLength = 3;

ForwardPred = 20;
BackStep = ForwardPred;
Result = zeros(1,length(s2));
x = 1:length(s);
y = s2;
for k = ((BackLength-1)*BackStep+1):ForwardPred:length(s2)-ForwardPred
   Backind = k-((BackLength-1)*BackStep):BackStep:k;
   Forwardind = k+1:k+ForwardPred;
   p = polyfit(x(Backind),y(Backind),Order);
   Result(Forwardind) = polyval(p,x(Forwardind));
end
figure(1)
plot(x,Result,'b',x,y,'r')
figure(2)
psd(Result,1024,1,blackh4(1024))
RMSerr = sqrt(mean((Result-y).^2));
disp(['RMS error : ' num2str(RMSerr)])