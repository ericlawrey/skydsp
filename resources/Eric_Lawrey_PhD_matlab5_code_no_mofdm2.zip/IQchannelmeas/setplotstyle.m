function setplotstyle(PlotLinewidth,FontScale,MarkerSize)
%SETPLOTSTYLE maximises the plot and sets the fonts and linewidths 
% setplotstyle(PlotLinewidth,FontScale)
% This script maximises the current plot and sets the font and line widths
% so that the plot is suitable for screen capture and embedding into a document
% Set the PlotLinewidth to [] if the linewidths of the lines are not to be modified
% Version 2.2
% Copyright Eric Lawrey (c) September 2000, Eric.Lawrey@jcu.edu.au

% 13/12/00
% Added the optional to change the markersize

if nargin <1
   PlotLinewidth = 1.5;
end
if nargin < 2
   FontScale = 1;
end

if nargin < 3
   MarkerSize = 24;
end

setstyle(PlotLinewidth,FontScale,MarkerSize)

legend		%This updates the legend with the new fonts and line thicknesses
%           If the plot has no legend this has no effect.
setstyle(PlotLinewidth,FontScale,MarkerSize)		%Update the outline of the legend. 

function setstyle(PlotLinewidth,FontScale,MarkerSize)
scnsize = get(0,'screensize');
yoff = 28;
yheader = 67;
maxsize = [scnsize(1) scnsize(2)+yoff scnsize(3) scnsize(4)-(yoff+yheader)];
set(gcf,'position', maxsize)
TitleFontSize = 24*FontScale;
LabelFontSize = 24*FontScale;
AxesFontSize = 22*FontScale;
AxesLinewidth = 3;

%MarkerSize = 24;
FigColour = [1 1 1];
h_fig = gcf;

h_fig_child = get(h_fig,'children');
h_xlabel = get(h_fig_child,'Xlabel');
h_ylabel = get(h_fig_child,'Ylabel');
h_zlabel = get(h_fig_child,'Zlabel');
h_title = get(h_fig_child,'title');
h_lines = get(h_fig_child,'children');

set(h_fig_child,'fontsize',AxesFontSize,'linewidth',AxesLinewidth);
%Set the attributes of the figures children and the lines on the plots
%which are the children of the children of the figure
set(h_fig,'color',FigColour);
if length(h_fig_child)>1 
   for k = 1:length(h_fig_child)
      set(h_xlabel{k},'Fontsize',LabelFontSize);
      set(h_ylabel{k},'Fontsize',LabelFontSize);
      set(h_zlabel{k},'Fontsize',LabelFontSize);
      set(h_title{k},'Fontsize',TitleFontSize);
      type = get(h_lines{k},'type');
      if strcmp(type,'line')&(~isempty(PlotLinewidth))
	      set(h_lines{k},'linewidth',PlotLinewidth);
         set(h_lines{k},'Markersize',MarkerSize);
      end    
   end
else
   set(h_xlabel,'Fontsize',LabelFontSize);
   set(h_ylabel,'Fontsize',LabelFontSize);
   set(h_zlabel,'Fontsize',LabelFontSize);
   set(h_title,'Fontsize',TitleFontSize);
   type = get(h_lines,'type');
   if strcmp(type,'line')&(~isempty(PlotLinewidth))
      set(h_lines,'linewidth',PlotLinewidth);
      set(h_lines,'Markersize',MarkerSize);
   end
   %If the fonts are large the dimensions of the plot need to be adjusted .
   ca = get(h_fig,'currentaxes');
   set(ca,'position',[0.13 0.11 0.77 0.77]);
end
set(h_fig,'PaperUnits', 'inches',...
	'PaperOrientation', 'landscape',...
	'PaperPosition',[0.25 0.25 11.1929 7.76772],...
   'PaperPositionMode', 'manual',...
   'PaperType', 'a4letter');
