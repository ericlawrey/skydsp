function savefig(filename,imagetype)
%SAVEFIG saves the current figure as an image of a specified type
% savefig(filename,imagetype)
% filename: names of the image file to save the figure as.
% imagetype:
% 'default', saves the image in TIF format and EMF format (default if
%     imagetype not specified)
% 'tif', saves the image in TIF format only
% 'jpg', saves the image in JPG format
% 'emf', saves the image in Enhanced Meta File (EMF) format
%
% imagetype can also be a cell array specifying a number of formats
% to save in. This speeds up saving a plot in multiple file formats
% For example imagetype = {'tif','jpg'} would save two files, a TIF
% format image and a JPG image.
% This image is captured off the plot on the screen, so to get
% highest resolution, set the screen resolution high and maximise
% the figure size.
% The file extension on the filename is removed, if on exists. An
% extension matching the image type is added.
%
% See also SETPLOTSTYLE

%Copyright Eric Lawrey July 2000
%version 1.4
%Modifications
%27/7/2000
%Added imagetype as an option, allowing the imahe to be saved as a jpg
%7/8/00
%Removed the automatic removal of text after any periods '.' in the file
%name, as it was causing problems.
%7/9/00
%Updated the commenting to match the new options added on 27/7/00. Added
%back removal of file extension, but now using fileparts for find the 
%extension. Also the extension is only removed if it is less than 4 
%characters including the '.'. This should still be backwards compatible.
%11/12/00
%Added tonal scaling to the image so that figures setup using setplotstyle
%have pure white as the background. This involve scaling the image by
%255/248. I don't know if this will be a problem with images.
%12/12/00
%Added the option of specifying imagetype as a cell array. This allows
%multiple file formats to be saved in one go.
%30/5/01
%Add the option to save in bmp file format

if nargin<2
   imagetype = 'default';
end

f = getframe(gcf);
[pathn,file,ext,ver] = fileparts(filename);
%Remove any file extension, and add the approapriate extension
%Only remove the extension if it is 4 characters in length. If
%it is longer than this assume that it is not an extension. I
%previously have trouble with extension removal, where it was removing
%numbering with decimal points in the number
if length(ext) > 4
   T = [file ext];
else
   T = file;
end
%Scale so that 248,248,248 (RGB) is pure white. Get frame appears to be
%returning the graphs with pure white as 248 instead of 255, so correct
%for this.
f.cdata = round(double(f.cdata)/248);
f.cdata = clip(f.cdata,0,1);
T = filename;
if iscell(imagetype)
   for k = 1:length(imagetype)
      savepic(f.cdata,T,imagetype{k});
   end
else
   savepic(f.cdata,T,imagetype);
end

function savepic(f,T,imagetype)
switch lower(imagetype)
   case 'default'
		imwrite(f,[T '.tif'],'tif','compression','packbits');
      saveas(gcf,T,'emf')
   case 'tif'
      imwrite(f,[T '.tif'],'tif','compression','packbits');
   case 'jpg'
      imwrite(f,[T '.jpg'],'jpg','quality',100);
   case 'bmp'
      imwrite(f,[T, '.bmp']);
   case 'emf'
      saveas(gcf,T,'emf')
   otherwise
      error(['Unsupported file type: ' imagetype]);
end      
   
function y = clip(x,low,high)
%CLIP clips the input signal to a lower and upper limit
%y = clip(x,low,high)
%Clips the signal x to a lower limit of 'low' and an upper
%limit of 'high'
y = x;
%Clip on the lower side
ind = find(x<low);
y(ind) = ones(size(ind))*low;

%clip high signals
ind = find(x>high);
y(ind) = ones(size(ind))*high;