function plotdata(Filenames,TimeFreqFlag,CalibFiles,Descript,Gain,StartFreq,BW,FreqPoints)
%PLOTDATA This plots data captured from the Tekronics Spectrum Analyser
% plotdata(Filenames,TimeFreqFlag)
% Filenames - cell array containing the filenames of the files to plot
% For Example:
% Filenames = {'c:\uni2000\measurements\test.txt',...
%              'test2.txt'}
% If filenames has two rows the file pairs are treated as I Q data.
% TimeFreqFlag - Specifies whether the plot is a time (zero span), 
%  TimeFreqFlag = 1, or frequency plot, TimeFreqFlag = 0. 
%  TimeFreqFlag can be a singular value (All plots will be the same), or 
%  a vector specifying for each file whether it is a time or frequency plot
%  If TimeFreqFlag is unspecified the data is assumed to be a frequency plot

%Copyright Eric Lawrey Sept 2000
%Version 2.0

if nargin < 2
   TimeFreqFlag = 0;		%Assume frequency plot by default
end

%If TimeFreqFlag is a singular value make it a vector, so there is one value for each
%filename
if length(TimeFreqFlag) == 1
   disp('Length = 1')
   TimeFreqFlag = ones(1,size(Filenames,2))*TimeFreqFlag;
end

%Check that we have the correct number of TimeFreqFlag
if (length(TimeFreqFlag) ~= size(Filenames,2))
   error('The length of TimeFreqFlag does not match the number of files given in Filenames');
end

N = 1024;
GainLin = 10.^(Gain/10);

if size(Filenames,1)== 2
   %Data is complex and two files must be loaded
   for k = 1:size(Filenames,2)
      disp(['Horz : ' Filenames{1,k}])
      Horz = rddata(Filenames{1,k}); %,NumPoints,2);
      disp(['Horz Calib : ' Filenames{1,k}])
      HorzCalib = rddata(CalibFiles{1,k});
      disp(['Vert : ' Filenames{1,k}])
      Vert = rddata(Filenames{2,k});
      disp(['Vert Calib : ' Filenames{1,k}])
      VertCalib = rddata(CalibFiles{2,k});
      %Average the calibration data. It should be constant over the sample data
      Hcalib = mean(HorzCalib(:,2));
      Vcalib = mean(VertCalib(:,2));
      %Hcalib = 0.512;
      %Vcalib = 0;
      Time1 = Horz(:,1);
      Time2 = Vert(:,1);
      if sum(Time1-Time2) > eps*1e6
         disp('Problem with the Horz and Vert data files, time scales don''t match');
         error(['Vert : ' Filenames{2,k} ', Horz : ' Filenames{1,k}])
      end
      
      ComplexData = (Horz(:,2)-Hcalib+(Vert(:,2)-Vcalib)*sqrt(-1))*sqrt(GainLin(k));
      
      if TimeFreqFlag(k) == 0
         Time1 = linspace(StartFreq(k),StartFreq(k)+BW(k),FreqPoints(k));
         ComplexData = ComplexData(1:FreqPoints(k));
      end
      
      %Plot the data
      figure(1);
      subplot(2,1,1)
      plot(Time1,10*log10(abs(ComplexData).^2));
      axis tight
      %ylim([0 max(Ydata(:,k))])
      title([Descript{k}]);
      if TimeFreqFlag(k) == 1
         xlabel('Time (sec)');
         ylabel('Power (dB)');
      else
         xlabel('Frequency (Hz)');
         ylabel('Power (dB)');
      end
      xlim([min(Time1),max(Time1)])
      grid on
      
      subplot(2,1,2)
      plot(Time1,unwrap(angle(ComplexData),0.95*pi));
      xlim([min(Time1),max(Time1)])
      %Set the font size, and line widths
      if TimeFreqFlag(k) == 1
         xlabel('Time (sec)');
         ylabel('Phase (Radians)');
      else
         xlabel('Frequency (Hz)');
         ylabel('Phase (Radians)');
      end
      grid on
      setplotstyle
      
      %This works best at screen resolutions >= 1024x768
      savefig(['s0026_' Filenames{1,k} '_PowPhase'],'jpg');
      savefig(['s0026_' Filenames{1,k} '_PowPhase'],'emf');
      
      
      Nsamp = 4;		%Use the phase difference between Nsamp time samples
      if TimeFreqFlag(k) == 1
         %Time data
         figure(2)
         subplot(2,1,1)
         uph = unwrap(angle(ComplexData),0.95*pi);
         phdiff = -uph(1:end-Nsamp)+uph(Nsamp+1:end);	%Radians/sample
         tstep = (Time1(Nsamp+1)-Time1(1));
         Doppler = phdiff/tstep/(2*pi);			%Doppler in Hz
         plot(Time1((1:end-Nsamp)+round(Nsamp/2)),Doppler);
         axis tight
         title(Descript{k})
         xlim([min(Time1),max(Time1)]);
         xlabel('Time (sec)');
         ylabel('Doppler (Hz)');
         %Set the font size, and line widths
         grid on
         setplotstyle
         
         subplot(2,1,2)
         h = plot(Time1,real(ComplexData),'r',Time1,imag(ComplexData),'b');
         axis tight
         xlabel('Time (sec)')
         ylabel('Rx Amplitude')
         xlim([min(Time1),max(Time1)]);
         grid on
         legend(h,'real','imag')
         setplotstyle
         set(h(2),'linewidth',1)
         legend
         
         %This works best at screen resolutions >= 1024x768
         savefig(['s0026_' Filenames{1,k} '_Doppler'],'jpg');
         savefig(['s0026_' Filenames{1,k} '_Doppler'],'emf');
      else
         figure(2)
         subplot(2,1,1)
         uph = unwrap(angle(ComplexData),0.95*pi);
         phdiff = uph(1:end-Nsamp)-uph(Nsamp+1:end);	%Radians/sample
         tstep = (Time1(Nsamp+1)-Time1(1))*2*pi;
         Doppler = phdiff/tstep;			%Doppler in Hz
         plot(Time1(round(Nsamp/2):end-round(Nsamp/2)-1),Doppler);
         title(Descript{k})
         axis tight
         xlim([min(Time1),max(Time1)]);
         xlabel('Frequency (Hz)');
         ylabel('Group Delay (sec)');
         %Set the font size, and line widths
         grid on
         setplotstyle
         
         subplot(2,1,2)
         h = plot(Time1,real(ComplexData),'r',Time1,imag(ComplexData),'b');
         axis tight
         xlim([min(Time1),max(Time1)]);
         grid on
         legend(h,'real','imag')
         setplotstyle
         set(h(2),'linewidth',1)
         legend
         %This works best at screen resolutions >= 1024x768
         savefig(['s0026_' Filenames{1,k} '_Doppler'],'jpg');
         savefig(['s0026_' Filenames{1,k} '_Doppler'],'emf');
      end
   end
else
   %Load all the files into the Frequency and Ydata matrices. Each column being on set of data
   for k = 1:length(Filenames)
      filename = Filenames{k};
      filename
      R = rddata(filename) %,NumPoints,2);
      if TimeFreqFlag(k) == 1
         %Time data gets scales by 1e-6 in the 'readtek' program during capture because it
         %assumes the data is frequency and needs to be scaled to MHz. Scale data back.
         Xdata = R(:,1)*1e6;
         Ydata = R(:,2)*1e6;
      else
         Xdata = R(:,1);
         Ydata = R(:,2);
      end
      
      %Plot the data
      figure(1);
      plot(Xdata,Ydata);
      axis tight
      %ylim([0 max(Ydata(:,k))])
      title(['Data File : ' filename]);
      if TimeFreqFlag(k) == 1
         xlabel('Time (sec)');
         ylabel('Received Ydata (uV)');
      else
         xlabel('Frequency (MHz)');
         ylabel('Power (dBm)');
      end
      %Set the font size, and line widths
      grid on
      setplotstyle
      
      %This works best at screen resolutions >= 1024x768
      savefig([Filenames{k}],'jpg');
      savefig([Filenames{k}],'emf');
      
      %If the data is a time plot calculate the spectrum of the
      %waveform. Plot the specgram and the normal spectrum
      if TimeFreqFlag(k) == 1
         figure(2);
         SampPeriod = Xdata(2,k) - Xdata(1,k);
         p = (Ydata(:,k));
         N = 128; specgram(p,N*8,1/SampPeriod,blackman(N),N-1)
         caxis('auto');
         c = caxis;
         caxis([c(2)-50 c(2)]);
         
         xlabel('Time (sec)')
         ylabel('Frequency (Hz)')
         setplotstyle
         %plot(20*log10(abs(f(1:256))))
         figure(3)
         [Pxx,Fxx] = psd(p,256,1/SampPeriod);
         Plog = 10*log10(Pxx);
         plot(Fxx,Plog-Plog(1))
         xlabel('Frequency (Hz)')
         ylabel('Normalised Ydata (dB)')
         setplotstyle
         pause
      end
   end
end

function Data = rddata(filename)
fid = fopen(filename,'r');
Data = [];
k = 1;
while 1
   line = fgetl(fid);
   if ~isstr(line), break, end
   Data(k,:) = str2num(line);
   k = k+1;
end
fclose(fid);