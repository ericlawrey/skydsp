The simulation scripts developed for this thesis use a common set of functions located in the common directory. Inorder to set the path to this directory, run the install script (located in this directory) with in matlab. This install script adds an "addpath" command to the startup.m script located in the matlab work directory. The "startup" script is executed every time matlab is loaded, and so the path to the common directory will always be available. 

All of the scripts that produce simulated results have been given a filename of the form s00xx_yyyy, such as s0059_aofdm. The first part of the file name (s00xx) is a script number. This is a unique identifier that allows the scripts and the resulting plots to be easily cross referenced. The second part of the script name is a short decription of the function of the script. 

All the plots in the thesis that were generated using Matlab scripts have the script number in the caption of the figure. The location of the script can be easily found using a search tool (From explorer use : Tools\Find\Files and Folders)

Any other way of easily determining the functionality of the scrips is to browse the directories and look at the image files. Each image file (usually TIF, EMF, or JPG) is a simulation result. The start of the filename for each of the image files contains the script number used to generate it.

This download does not contain the code for adaptive modulation, adaptive user allocation, and
adaptive bandwidth. This is part of the multiuser OFDM simulation, which can be downloaded separately.
This was separated out due to the large size of the measured data files.


AccessPointRepeaters
====================
This directory contains the results shown in chapter 5 of the thesis. This includes plotting of the measured and simulated results.
S0010_SHADOW raytraces to find shadowing and interference between radio transmitters. This uses input initialisation files to setup the simulation parameters. There are several example initialisation files, such as r0011_1tx2GHz.m, which simulates the effect of an interferer on a WLAN system. This is the simulation used at the end of Chapter 5.

To make a new simulation simply copy one of the initalisation files, then modify the simulation parameters, and run in s0010_shadow

CFreduction
===========
This directory contains the simulations scripts and results for chapter 7 on the use of peak reduction carriers to reduce the CF of data carrying OFDM signals. This work was done in early 1999, before the scripting number scheme was implemented. The simulation plots were produced in excel. These results required a large amount of processing, and so it was run on many computers (the uni supercomputer, the engineering lab and my own machine). As a result there were a lot of simulation scripts. Each script corresponded to a single task on one of these machines. 

Common
======
This contains a range of general purpose functions used throughout this thesis. These functions each contain a fairly large amount of commenting, which can be read in Matlab using help XXX, where XXX is the function name.

Distortion
==========
This contains all the simulations on measuring the performance of OFDM when subjected to clipping distortion.
Freqerr
=======
Small simulation for measuring the effects of frequency offset errors on an OFDM transmission.

GA_CFreduction
==============
This is the results and simulation scripts for the results shown in chapter 6. New simulation can be run using paprsim.m. To do this edit paprsim and add a simulation case. There is a bit of an explaination in the comments. 

Introduction
============
These are just a few scripts used in the introduction to OFDM for generating several diagrams

IQchannelmeas
=============
The complex channel response of a short range radio link was measured (see chapter 3 (end section)). The measurement results and the plots are contained in this directory. There are several additional measurements not presented in the thesis. An extract of my journal is shown in the "journal" directory. This provides a very brief outline of each of the measurments.

ofdmber
=======
This directory contains the simulations investigating the BER performance of OFDM as a function of AWGN. 

paprestimation
==============
These simulation files show the CF distribution of OFDM signals, and investigate the accuracy of CF estimation using interpolation.

sphere
======
This plots the spherical expansion of an RF pulse.

timeerror
=========
The results in this directory show plots of different pilot reference symbols (phasing schemes), and the performance of an OFDM system verse a time offset.

timesync
========
This contains a simulation showing the performance of multipath on the effective SNR of an OFDM signal. It shows the effects of different length guard periods. The s0082 simulator in fact contains a full OFDM simulator with frequency estimation, time synchronisation, equalisation, etc. 

Also in this directory is a set of measurement that were taken, measuring the time synchronisation of different pilot symbols when used for null symbol synchronisation, the same as that used in DAB.

windowing
=========
The simulations in this directory look at the performance of different window functions, the effects of bandpass filtering of OFDM and the effects of raised cosine windowing on the band width of the signals.