%This script plots an IQ plot of 16QAM with noise added
%The boundary lines shown in the thesis were added by hand.
%Copyright Eric Lawrey 14/8/2001
N = 5000;				%Number of points on plot
ModType = '16QAM';	%Modulation scheme to plot (any from data2iqmap can be plotted)
SNR = 18;				%SNR of the channel

[ModTable,BitHzOut] = data2iqmap(ModType);
Data = ceil(rand(1,N)*(2^BitHzOut));
%size(ModTable)
q = ModTable(Data);
Y = addnoise(q,SNR);
h = plot(Y,'.r');
title(['I-Q diagram for ' upper(ModType)]);
axis equal;
xlabel('Real');
ylabel('Imaginary');
axis([-1 1 -1 1]*1.4);
hold on
h2 = plot(q,'xb');
hold off
setplotstyle(1.5,1,12);
set(h2,'markersize',15,'linewidth',3)