%This script creates a diagram showing OFDM signals in the time domain.
%This shows that each of the carriers in the signal have an integer
%number of cycles making them orthogonal.
M = 32;
Nc = [1:4];
t = 0:M-1;
fc = Nc*(1/M);
pc = [ones(1,length(Nc))*0];
c = zeros(length(Nc),M);
textlista = {'(1a)','(2a)','(3a)','(4a)','5(a)'};
textlistb = {'(1b)','(2b)','(3b)','(4b)','5(b)'};
figure(1)
for k = 1:length(fc)
   c(k,:) = sin(2*pi*t*fc(k)+pc(k));
   a = subplot(length(fc)+1,2,k*2-1);
   h = plot(c(k,:),'-b.');
   axis tight;
   set(a,'xtick',[5:5:30]);
   set(a,'xticklabel',['','','','','','']);
   set(a,'linewidth',2);
   set(h,'linewidth',2);
   set(a,'fontsize',18);
   ht = text(-5,0,textlista(k));
   set(ht,'fontsize',18,'fontweight','bold')
   
   a = subplot(length(fc)+1,2,k*2);
   f1 = abs(fft(c(k,:)));
	h = bar(0:M/2-1,f1(1:M/2));
   xlim([0 M/2]);
   set(a,'xtick',[0:16]);
   set(a,'xticklabel',{'','','','','','','','','','','','','','','','',''});
   set(a,'linewidth',2);
   set(h,'linewidth',2);
   set(a,'fontsize',18);
   ht = text(-4,10,textlistb(k));
   set(ht,'fontsize',18,'fontweight','bold')
end
a = subplot(length(fc)+1,2,(length(fc)+1)*2-1);
h = plot(sum(c),'-b.');
axis tight
xlabel('Time waveform (32 samples)');
set(a,'xtick',[5:5:30]);
set(a,'linewidth',2);
set(h,'linewidth',2);
set(a,'fontsize',18);
ht = text(-5,0,textlista(k));
set(ht,'fontsize',18,'fontweight','bold')
   
a = subplot(length(fc)+1,2,(length(fc)+1)*2);
f1 = abs(fft(sum(c)));
h = bar(0:M/2-1,f1(1:M/2));
xlim([0 M/2]);
xlabel('Carrier Frequency (using 32 point FFT)')
set(a,'xtick',[0:16]);
set(a,'xticklabel',{'0','','2','','4','','6','','8','','10','','12','','14','','16'});
set(a,'linewidth',2);
set(h,'linewidth',2);
set(a,'fontsize',18);
ht = text(-4,10,textlistb(k));
set(ht,'fontsize',18,'fontweight','bold')
savefig('s0036_OFDMtime');
   