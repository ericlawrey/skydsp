%This script plots the results of a doppler measurement. This experiment was done using
%the Marconi 2032 signal generator, and the TDS380 CRO. 
Dist = [0:0.05:1.7];			%Distance in metres
VoltRx = [6.24 11.5 15.13 17.5 18.08 15.4 12.7 8.2 5.69 8.64 12.4 15.9 17.8 17.9 ...
      17.7 16.6 15.6 16.06 15.09 14.47 12.41 9.86 8.34 8.16 9.48 10.9 11.7 11.65 ...
      10.08 9.75 6.16 6.89 11.74 15.93 17.41];	%Received signal voltage (mV rms)
DelayTxRx = [0.86 0.78 0.84 0.84 0.94 0.98 1.02 1.12 1.5 1.9 2.04 2.16 2.22 2.32 ...
      2.4 2.5 0.1 0.24 0.4 0.52 0.64 0.78 1 1.24 1.44 1.56 1.7 1.84 1.9 2 2.2 ...
      2.68 2.9 3.02 3.08];		%Delay between the transmitter and receiver (in nano sec)
TxSigPow = 256;				%Transmitted power (mV)
Freq = 400e6;					%Frequency in Hz
Imp = 50;						%Impedance (ohms)

Period = 1/Freq;
Prx = ((VoltRx/1000).^2)/Imp;
PrxN = Prx/mean(Prx);
PrxdB = 10*log10(PrxN);

Phase = unwrap(((DelayTxRx/1e9)/Period)*2*pi);
DeltaDist = diff(Dist);
Doppler = diff(Phase)./DeltaDist/2/pi;	%cycles/metre

figure(1);
subplot(2,1,1)
plot(Dist,PrxdB);
xlabel('Distance moved by transmitter (fixed receiver) (m)')
ylabel('Power Rx (dB)')
%subplot(3,2,2)
%plot(Dist,Phase);
xlim([min(Dist),max(Dist)])
subplot(2,1,2)
plot(Dist(2:end),Doppler);
xlabel('Distance moved by transmitter (fixed receiver) (m)')
ylabel('Doppler Shift (cyc/m)')
setplotstyle
xlim([min(Dist),max(Dist)])
savefig('s0025_channel_doppler','default')

