%This script creates a diagram showing OFDM signals in the time domain.
%This shows that each of the carriers in the signal have an integer
%number of cycles making them orthogonal.
M = 64;
Nc = [2 7];
t = 0:M-1;
fc = Nc*(1/M);
pc = [0 pi/2 0];
c = zeros(length(Nc),M);
figure(1)
for k = 1:length(fc)
   c(k,:) = sin(2*pi*t*fc(k)+pc(k));
   subplot(length(fc)+1,1,k)
   plot(t/(M-1),c(k,:))
end
subplot(length(fc)+1,1,length(fc)+1)
plot(t/(M-1),sum(c))
figure(2)
%sub('position',[left bottom width height])
subplot(4,1,1)
f1 = abs(fft(c(1,:)));
bar(0:M/2-1,f1(1:M/2));
xlim([0 M/2])
subplot(4,1,2)
f2 = abs(fft(c(2,:)));
bar(0:M/2-1,f2(1:M/2));
xlim([0 M/2])
subplot(4,1,4)
f3 = abs(fft(c(1,:).*c(2,:)));
bar(0:M/2-1,f3(1:M/2));
xlim([0 M/2])
xlabel('Frequency (Number of cycles per symbol)')
%plot(c(1,:).*c(2,:));