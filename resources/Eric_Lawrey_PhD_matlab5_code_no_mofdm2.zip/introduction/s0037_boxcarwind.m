%This script plots a single carrier OFDM signal, (essentially just 
%a PSK waveform) to demonstrate the effect of time windowing on
%the waveform. 
%The first plot is three symbols (one carrier), showing the phase transients 
%between symbols.
%The second plot shows that a single symbol showing that the it is effectively
% the same as taking a sinewave and windowing it with a retangular window.
N = 256; 	%Number of points for OFDM symbol 
t = 0:N-1;	%Time in samples
freq = 2;		%Number of cycles per symbols
phase = [pi/4 -pi/4 5/8*pi];
time_for_plot = linspace(0,length(phase),length(phase)*N);
s = [];
for k = 1:length(phase)
   s = [s sin(2*pi*t/N*freq+phase(k))];
end
figure(1)
h = plot(time_for_plot,s);
setplotstyle(1.5,0.8);
setplotsize(1000,280);
hax = get(h,'parent');
set(hax,'xtick',[0 1:length(phase)]);
ylim([-1.1 1.1]);
pbaspect([4 1 1])
for k = 1:length(phase)
	ht = text(0.3+k-1, -1.3, ['Symbol ' num2str(k)]);
   set(ht,'fontsize',20);
end
savefig('s0037_PSKsymbols')


w = [zeros(1,N) boxcar(N)' zeros(1,N)];
sine_wave = sin(2*pi*(0:N*3-1)/N*freq+phase(2));
ws = w.*sine_wave;
figure(2)
subplot(3,1,1)
h1 = plot(time_for_plot,w);
ylim([0 1.05])
set(get(h1,'parent'),'box','off');
hax = get(h1,'parent');
set(hax,'xtick',[0 1:length(phase)]);

subplot(3,1,2)
h1 = plot(time_for_plot,sine_wave);
ylim([-1.05 1.05])
hax = get(h1,'parent');
set(hax,'xtick',[0 1:length(phase)]);

subplot(3,1,3)
h1 = plot(time_for_plot,ws);
ylim([-1.05 1.05])
xlabel('Time (symbols)');
setplotstyle(1.5, 0.8, 15, 0)
hax = get(h1,'parent');
set(hax,'xtick',[0 1:length(phase)]);

%This is done after setplotsytle is used. This is a work around the
%limitations of setplotstyle. When I had the text calls before the
%setplotstyle the line width would be thin, for those plots which
%had text added to them.
subplot(3,1,1)
ht = text(-0.3, 0.25, '(a)');
set(ht,'fontsize',22,'fontweight','bold');

subplot(3,1,2)
ht = text(-0.3, -0.5, '(b)');
set(ht,'fontsize',22,'fontweight','bold');

subplot(3,1,3)
ht = text(-0.3, -0.5, '(c)');
set(ht,'fontsize',22,'fontweight','bold');
savefig('s0037_wind')

