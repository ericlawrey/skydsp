%This script generates plots of overlapping sinc functions
%It is configured to plot 3 overlapping sinc functions for
%a header on a web page, thus the lines are very thick.
clear all
close all
filename1 = 's0006_OFDM_overall_ferr_0.1';
M = 1;
Users = 5;
e = 3e-2;
%serr = 0.0;
logplot = 0;		%plot using a log or linear scale
carrplot = 0;		%plot the power from each carrier
finplot = 1;		%Plot the combined power of all users, i.e. the received power
combspec = 0;		%Comb spectrum or group carriers
individplot = 1;	%Set whether to plot individual carriers (1) or not (0)
thickline = 6;
individlines = 2;
fontscale = 1.3;
SaveFlag = 1;		%Flag to enable or disable saving of the plots
N = 2048;
a = (0:N-1);
T = 6*pi;
ymax = 1.44;
ymin = -0.25;
PowFlag = 0;		%1 - plot using power, 0 - plot using amplitude
rand('seed',296042)
FreqError = (round(rand(1,Users))*2-1)*pi*0.1;
%FreqError = ones(1,Users)*0;
%x = a/N*T/pi*2;
CombSig = zeros(1,N);
stoffset = M*Users/2-0.5;
b = (a-N/2)/(N/2)*T;
x = b/pi;
k = 1;
for l = 1:Users
   offset = M*(l-1);
   UserSig = zeros(1,N);
   for k = 1:M
      if combspec
         b2 = b+pi*((k-1)*Users+l-stoffset);
      else
         b2 = b+pi*(k-1+offset-stoffset);
      end
      c = sinc((b2+FreqError(l))/pi);
      CombSig = CombSig+c;
      UserSig = UserSig+c;
   end
   if individplot
      str = 'yrgbmck';
      col = str(rem(l-1,7)+1);
      if logplot
         figure(1)
         hold on
         plot(x,20*log10(abs(UserSig)+e),col);
      else
         figure(1)
         hold on
         if PowFlag
            U = UserSig.^2;
         else
            U = UserSig;
         end
         
         plot(x,U,col);
         %axis([min(x) max(x) min(UserSig)*1.4-0.1 max(UserSig)*1.1])
      end
   end
end

figure(1)
g = get(gcf,'currentaxes');
set(g,'xtick',[-(T/pi):1:T/pi]);
axis tight
ylim([ymin ymax])
setplotstyle(individlines,fontscale)
if finplot
   if logplot
      h = plot(x,20*log10(abs(CombSig)+e),'k');
      set(h,'linewidth',thickline)
   else
      if PowFlag
         C = CombSig.^2;
      else
         C = CombSig;
      end
      
      hb = plot(x,C,'k');
      %set(hb,'linewidth',thickline)
      
   end
end

g = get(gcf,'currentaxes');
set(g,'xtick',[-(T/pi):1:T/pi]);
x2 = [-(T/pi):1:T/pi];
y = interp1(x,CombSig,x2);
axis tight
ylim([ymin ymax])
setplotstyle(individlines,fontscale)
if finplot
   set(hb,'linewidth',thickline)
end

if PowFlag
   Y = y.^2;
else
   Y = y;
end

plot(x2,Y,'ko','markersize',24,'linewidth',4);
hold off
xlabel('Frequency (Carrier spacings)');
ylabel('Tx Amplitude');
hold off
if SaveFlag
   savefig(filename1)
end
