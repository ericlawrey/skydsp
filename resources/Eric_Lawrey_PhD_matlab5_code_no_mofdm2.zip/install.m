%This function installs

mypwd = pwd;
commonpath = [mypwd filesep 'common'];
startuppwd = which('startup.m');
if isempty(startuppwd)
   startuppwd = [matlabroot filesep 'work' filesep 'startup.m'];
   NewFile = 1;
else
   %Check to see if the addpath command has already been added to start.m
   f = fopen(startuppwd,'r');
   if isempty(f)
      error(['Error occurred when attempting to read ' startuppwd]);
   end
   s = fread(f);
   fclose(f);
   I = findstr(s.','These lines have been added to set up the path to the OFDM code');
   %If the path has already been added to the startup then I will not be empty
   if ~isempty(I)
      disp('The path has already been added to the startup file');
      return  
   end
   NewFile = 0;
end

f = fopen(startuppwd,'a');
if isempty(f)
   error(['Error occurred when attempting to append to ' startuppwd]);
end
fprintf(f,'\n%%These lines have been added to set up the path to PhD OFDM code\n');
fprintf(f,'if exist(''%s'',''file'')       %%PhD OFDM code path\n', commonpath);
fprintf(f,'   addpath ''%s''             %%PhD OFDM code path\n', commonpath);
fprintf(f,'   disp(''Adding path to PhD OFDM code'');    %%PhD OFDM code path\n');
fprintf(f,'end                                              %%PhD OFDM code path\n');
fclose(f);
if NewFile
   disp(['There is currently no MATLAB startup file, so creating one at ' startuppwd ]);
   disp('This startup script adds the path to the PhD OFDM code each time matlab is started');
else
   
   disp('The path to the OFDM code has been added to the MATLAB startup file');
end
%Run the startup script
run startup