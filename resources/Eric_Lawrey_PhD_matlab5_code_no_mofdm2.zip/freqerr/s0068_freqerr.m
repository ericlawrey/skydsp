%This simulation plots the Effective SNR of and OFDM as a function of Output Power
%Backoff from 0 to 9.5 dB, for three different number of carriers. 
%
%===========================
%	Default Variabels
%===========================
Nsymbol = 40;				%Number of Symbols to simulate (default)
Ntrials = 25;				%Number of Trials to average the results over. Lowering Nsymbol
%								and increasing Ntrials can be used to minimise the memory useage
%								Memory useage ~(Nsymbol+NumRefSymb)*(IFFTsize+GuardPeriod)*8(bytes 
%								per number)*2(complex)*2(working memory) in Bytes
Ncarriers = 64;			%Number of carriers to use
 
IFFTsize = 128;			%Size of the IFFT used to generate the OFDM signal
RealComplex = 'complex';	%Whether to generate a 'real' or 'complex' OFDM signal
GuardPeriod = 16;			%Length of the guard period in samples
TimeOffset = -GuardPeriod/2;			%Time Offset error in samples (integer), if filtering is used
%								this should be -GuardPeriod/2 for best results
RefScheme = 0;				%Type of pilot symbol used
PilotPowBoost = 10;		%Power boosting of the pilot power (linear units)
NumRefSymb = 1;			%Number of pilot symbols to use
NpilotTones = 6;			%Number of pilot tones to add to each symbol.

fast_mode = 0;				%Enabling the fast mode in OFDMMOD (see help ofdmmod)
PreClipDistFlag = 0;		%Preclip the signal before bandpass filtering. This is
%								to reduce out-of-band spectral spreading caused by
%								distortion in the PA.
PreOutBackoffdB = 4.5;		%Output power backoff in dB

%								This simulates distortion in the Power Amp (PA)
ClipDistFlag = 0;			%Whether to enable clipping distortion on the signal
OutBackoffdB = 6;			%Output power backoff in dB
BPFilterFlag = 0;			%Flag to enable bandpass filtering of the signal (1) - enabled 
%								(0) - no filtering
TransWidth = 2;			%TransWidth is the transition width of the window function
%								This determines the out of band attenuation 
FiltWidth = 8; 			%FiltWidth width of the bandpass filtering to first null



SNRdB = 2000;				%Channel SNR for AWGN in dB
legend_flag = 1;					%Enable (1) or Disable plotting of the legend
title_text = 'Number symbols after pilot reference (Coherent QAM)'; 
%'Frequency Error for different spacing between pilot symbols';
axis_range = [1e-5 1e-1 -10 80];  ; %[0 9.5 0 80];	%Plot axis range
xticks = 1; %[0:1:11];		%Xticks marks to put on the plot, set to scalar for auto
yticks = [-10:10:80];%[0:10:80];		%If yticks is a scalar the yticks are not set
MarkerSpacing = 10;		%Spacing between the markers
plot_filename = 's0068_freqerr';	%File name of the plot generated
SavePlotFlag = 0;			%Flag to enable (1) or disable saving of the plot generated
FreqErrType = 1;
%TitleStr = [num2str(Ncarriers) ' Carriers, Guard 1/8 IFFT size, Filt Width: ',...
%      num2str(FiltWidth), ', Wind Width: ' num2str(TransWidth)];
CarrierPlotFlag = 0;		%(1) plot the effective SNR as a function of carrier
%								number, rather than the loop variable. If the loop variable
%								is a vector multiple lines are plotted. LoopVariable2 should
%								only be a single value.
LogPlotFlag = 1;			%Flag to set whether to make the xaxis in log scale (1) or not (0)
SymbolPlotFlag = 1;
%=====================================
%	Loop Variables
%=====================================
%The loop variables overwrite the default values
LoopVariable = 'FreqOff';		%X axis Loop Variable
LoopList = logspace(-5,-1,20);
%LoopList = 1e-4;
%LoopVariable = 'GuardPeriod';
%LoopList = [8 64];
%LockVariables = {'TimeOffset'};
%LockValues = {-[8 64]/2};

LoopVariable2 = 'Nsymbol';
LoopList2 = [1 4 16 64];
LoopVariable2 = 'Nsymbol';
LoopList2 = [1 4 16 64];
LockVariables2 = {'SymbAvgType'};%{'IFFTsize', 'Nsymbol','Ntrials','GuardPeriod','TimeOffset'};	%This variable will also change with LoopVariable2
LockValues2 = {[1 4 16 64]};%{[16 128 1024], [500 250 100]/4, [2 2 2]/2,[2 16 128],[-1 -8 -64]};	%These are the values the lock variables will take
%																		The length of each array must match the LoopList length

legend_pos = 1;					%Position of legend, See help legend

s0051_effSNR
