%This script plots the cummulative probability distribution of the
%CF of random phase DMT symbols.
tic
ScriptRef = 's0032';
SimType = 1;	%Type of simulation, 1 - measures the distribution over many
%					sizes of Numcarrs then plots the CF distribution verses Number carriers
%					2 - Only measure the result for a couple of different number of carriers
%					and plot the CF distribution.
if SimType == 1
   N = 30;
   Numcarrs = intlogspace(2,1024,N);
else
   %Numcarrs = 2;
   Numcarrs = [8 32 128];	%Number of carriers (There must be an evolved set for the
   %					number of carriers) This script is current set up to plot three
   %					different number of carriers.
   xticks = [2:1:11];
end

QAM_flag = 0;	%Flag to indicate whether to use simulation QAM (1) or PSK (0)
%					for QAM the data vectors are uniformly distributed amplitude in the
%					real and imaginary axis randomly. This will give a square IQ constellation
%					but with no specific modulation.
Ntrials = 200;	%Nsymbol number of OFDM symbols is calculated Ntrials number of times
%					This is split up to limit memory usage, and to give user some feedback on
%					simulation progression, which is display after each trial of Nsymbols.
Nsymbols = 100;	%Number of OFDM symbols to calculate per trial, Total number of
%						symbols calculated is Nsymbols*Ntrials
GuardPeriod = 0;
Oversamp = 4;	%Oversampling of the DMT signals
Offset = 0;  	%Carrier offset from DC. Since we are looking at the magnitude of
%					the waveform (envelope) this has no effect
RealComplex = 1;	%0 = real, 1 = complex
SavePlotFlag = 1;	%Flag to enable (1) or disable (0) saving of the plots
s1 = cell(1,length(Numcarrs));
s2 = s1;

%=========================
%		QAM modulation
%=========================
papr2 = zeros(length(Numcarrs),Ntrials*Nsymbols);
%Change RealComplex so that it is suitable for mkcarriers and ofdmmod
if RealComplex == 1
   RealComplex = 'complex';
else
   RealComplex = 'real';
end

for l = 1:length(Numcarrs)
   Ncarrs = Numcarrs(l);
   IFFTsize = 2.^nextpow2(Ncarrs*Oversamp);	%Pick the IFFT size so that it
   % is at least oversamp times larger than the number of carriers, but is a
   % power of 2.
   carriers = mkcarriers(Ncarrs, IFFTsize, RealComplex);
   for k = 1:Ntrials
      if QAM_flag
         Data_vector = (rand(Ncarrs,Nsymbols)*2-1)+i*(rand(Ncarrs,Nsymbols)*2-1);
      else
%         disp('psk')
         phase = rand(Ncarrs,Nsymbols)*2*pi;
         mag = ones(Ncarrs,Nsymbols);
         [x,y] = pol2cart(phase,mag);
         Data_vector = x+i*y;
      end
      
      outsymbol = ofdmmod(Data_vector,carriers,IFFTsize,GuardPeriod,RealComplex);
      %plot(abs(outsymbol))
      %pause
      offset = (k-1)*Nsymbols+1;
      papr2(l,offset:offset+Nsymbols-1) = calcpapr(outsymbol,1);
      if rem(k,10)==0
      	disp(['Carriers : ' num2str(Ncarrs) ', Calculated : ' num2str(k) ' trials of ' ...
               num2str(Ntrials) ]);
         drawnow
      end
   end
end

paprdB = papr2;
for k = 1:length(Numcarrs)
   s1{k} = [num2str(Numcarrs(k)) ' tones']; 
   s2{k} = [num2str(Numcarrs(k)) ' T, mean:' num2str(mean(paprdB(k,:)'),3)... 
         'dB, STD:' num2str(std(paprdB(k,:)'),3) 'dB']; 
end
%Type string, this is added to the file name of the saved plots
if QAM_flag
   Type_String = 'QAM';
else
   Type_String = 'PSK';
end

if SimType == 1
   m = mean(paprdB');
   s = std(paprdB');
   
   sdB = sort(paprdB');
   Ns = size(paprdB,2);
   Prob99 = interp1(1:Ns,sdB,0.99*Ns);
   Prob01 = interp1(1:Ns,sdB,0.01*Ns);
   Prob90 = interp1(1:Ns,sdB,0.90*Ns);
   Prob10 = interp1(1:Ns,sdB,0.1*Ns);
   Prob001 = interp1(1:Ns,sdB,0.001*Ns);
   Prob999 = interp1(1:Ns,sdB,0.999*Ns);
   
   figure(1)
   clf
   h = semilogx(Numcarrs,Prob999,Numcarrs,Prob99,Numcarrs,Prob90,Numcarrs,m,...
      Numcarrs,Prob10,Numcarrs,Prob01,Numcarrs,Prob001);
   axis tight
   xlabel('Number of tones');
   ylabel('CF (dB)');
   colours = [0 0 0; 0 0 1];
   legend(h,'99.9%','99%','90%','mean','10%','1%','0.1%',4)
   setplotstyle
   set(h(1),'marker','^','markersize',18,'color',colours(1,:));
   set(h(7),'marker','.','markersize',30,'color',colours(2,:));
   set(h(4),'linewidth',5)
   legend
   grid on
   %Turn main markers off and replace them with markers only every several
   %data points
   set(h(1),'marker','none');
   set(h(7),'marker','none');
   hold on
   M = 4;
   h2 = semilogx(Numcarrs(1:M:end),Prob999(1:M:end),Numcarrs(1:M:end),Prob001(1:M:end));
   hold off
   set(h2(1),'marker','^','markersize',18,'linestyle','none','linewidth',1.5,'MarkerEdgeColor',colours(1,:));
   set(h2(2),'marker','.','markersize',30,'linestyle','none','linewidth',1.5,'MarkerEdgeColor',colours(2,:));
   if SavePlotFlag 
      savefig([ScriptRef '_mean_cf_vs_tones_' Type_String],'tif')
   end
   
   hold off
   
   figure(2)
   clf
   h = semilogx(Numcarrs,s);
   axis tight
   xlabel('Number of tones');
   ylabel('standard deviation of CF dist (dB)');
   setplotstyle
   grid on
   if SavePlotFlag 
      savefig([ScriptRef '_std_cf_vs_tones_' Type_String],'tif')
   end
   hold off
else
   %======================================================
   %		Sim type 2 plots
   %======================================================
   figure(1)
   clf
   [n,x] = hist(paprdB',100);
   n2 = n./repmat(sum(n),size(n,1),1);
   c = cumsum(n2);
   h = plot(x,c);
   %Turn on markers so that they will be added to the legend
   set(h(1),'marker','.','markersize',35)
   set(h(2),'marker','^','markersize',18)
   ylabel('Cummulative Prob Distribution');
   xlabel('CF (dB)');
   legend(h,s1,2)
   axis tight
   setplotstyle
   %Turn off markers, and replace them with less of them
   set(h(1),'marker','none')
   set(h(2),'marker','none')
   hold on;
   M = 8;
   h2 = plot(x(1:M:end),c(1:M:end,:));
   %Turn on the markers for the subsampled data, and turned their line off
   set(h2(1),'marker','.','markersize',35,'linewidth',1.5,'linestyle','none');
   set(h2(2),'marker','^','markersize',18,'linewidth',1.5,'linestyle','none');
   set(h2(3),'linestyle','none');
   grid on
   xlim([min(xticks) max(xticks)])
   set(gca,'xtick',xticks);
   if SavePlotFlag
      %I am only saving in tif format because the emf format is stuffing up the
      %legend
      savefig([ScriptRef '_cf_cum_dist_' Type_String],'tif')
	end
   hold off


   
   
   figure(2)
   clf
   [n,x] = hist(paprdB',50);
   n2 = n./repmat(sum(n),size(n,1),1);
   %h = stairs(x,n2);
   h = plot(x,n2);
   %Turn on markers so that they will be added to the legend
   set(h(1),'marker','.','markersize',35)
   set(h(2),'marker','^','markersize',18)
   ylabel('Cummulative Prob Distribution');
   xlabel('CF (dB)');
   legend(h,s2,2);
   axis tight
   yl = ylim;
   ylim([yl(1) yl(2)*1.3])
   setplotstyle
   %Turn off markers, and replace them with less of them
   set(h(1),'marker','none')
   set(h(2),'marker','none')
   hold on;
   M = 5;
   h2 = plot(x(1:M:end),n2(1:M:end,:));
   %Turn on the markers for the subsampled data, and turned their line off
   set(h2(1),'marker','.','markersize',35,'linewidth',1.5,'linestyle','none');
   set(h2(2),'marker','^','markersize',18,'linewidth',1.5,'linestyle','none');
   set(h2(3),'linestyle','none');
   xlim([min(xticks) max(xticks)])
   set(gca,'xtick',xticks);
   grid on
   if SavePlotFlag 
      savefig([ScriptRef '_cf_dist_' Type_String],'tif')
   end
   hold off
end
disp(['Processing time : ' num2str(toc) ' sec'])