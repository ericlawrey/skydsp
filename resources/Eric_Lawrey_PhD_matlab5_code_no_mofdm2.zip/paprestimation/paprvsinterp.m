function [PAPR1,OverSampList1,PAPRErr1] = paprvsinterp(filename,OverSampList,PlotFlag)
%This function plots the PAPR estimation error verses oversample rate
%for an evolved data set or for a symbol with given phases.
%The oversampling is done in the frequency domain. If no output is specified
%the interpolation results will be plotted, captured and saved to
% PAPR_Error_vs_Oversamp_XXX_tone_low_papr.tif and 
% PAPR_vs_Oversamp_XXX_tone_low_papr.tif
% where XXX is the number of tones used
%
% paprvsinterp(filename)
% Loads the data set given by filename. The best symbol with the lowest
% papr used as the symbol to interp.
%
% paprvsinterp(phases)
% Generates a Discrete Multi Tone (DMT) with the phases given, then 
% measures the PAPR of the symbol verses oversampling.
%
% [PAPR, OverSampList, PAPRErr] = paprvsinterp(...)
% Returns the PAPR verses the oversamp rate.
% PAPR - Peak to Average Power Ratio for each Oversample rate. This is really 
% the crest factor in dB
% OverSampList - OverSample rate list used (default is 1:64)
% PAPRErr - Error between each PAPR and the highest PAPR measured
%
% [PAPR] = paprvsinterp(filename,OverSampList,PlotFlag)
% OverSampList specifies the oversample rates to test. This should be
% a vector of OverSample Rates to test. The default is 1:64.
% PlotFlag - Setting this to 1 forces paprvsinterp to plot the figures
% 
% Eric Lawrey, 17/5/00

%This function requires:
% - ofdmmod
% - setplotstyle
% - savefig
% - calcpapr

if isstr(filename)
	load(filename) 
   Ph = PhaseOld(Isurvive(1),:);
else
   Ph = filename;
   Ncarrs = length(Ph);
   complexflag = 1;
   GuardPeriod = 0;
end

if nargin < 2
   OverSampList = 1:1:64;
end

if nargin < 3
   PlotFlag = 0;
end


Amp = ones(1,Ncarrs);

[x,y] = pol2cart(Ph,Amp);
iqdatabest = x+sqrt(-1)*y;

PAPR = zeros(1,length(OverSampList));
if complexflag == 1;
   real_complex = 'complex';
else
   real_complex = 'real';
end
data_carriers = -floor(Ncarrs/2-0.1):floor(Ncarrs/2);
for k = 1:length(OverSampList)
   %Calculate the carrier position for each interpolation rate. 
   %This is needed because the negative carriers are last carriers
   %i.e. for 512 point FFT carriers -10:-1 correspond to 502:512
   data_bins_interp = data_carriers;
   Ind = find(data_carriers<0);
   data_bins_interp(Ind) = data_bins_interp(Ind)+Ncarrs*OverSampList(k);
   data_bins_interp = data_bins_interp+1;
   
   %Convert to a time domain waveform
   refsinterp = ofdmmod(iqdatabest, data_bins_interp, Ncarrs*OverSampList(k),...
      GuardPeriod, real_complex, 1);
   %Find the PAPR of the waveform (actually Crest Factor) because the
   %signal is complex and centered at DC.
   PAPR(k)  = calcpapr(refsinterp,1);
end
mx = max(PAPR);
PAPRErr = PAPR-mx;

if (nargout == 0)|PlotFlag
   figure(1)
   plot(OverSampList,PAPR)
   title(['Low PAPR ' int2str(Ncarrs) ' tone signal, PAPR : ' num2str(mx) 'dB']);
   xlabel('Oversample rate');
   ylabel('PAPR Estimation (dB)');
   grid on
   setplotstyle
   savefig(['PAPR_vs_Oversamp_' int2str(Ncarrs) '_tone_low_papr.tif'])
   
   figure(2)
   semilogy(OverSampList,abs(PAPRErr));
   grid on
   axis([min(OverSampList) max(OverSampList) 1e-6 1e-2])
   
   title(['Low PAPR ' int2str(Ncarrs) ' tone signal, PAPR : ' num2str(mx) 'dB']);
   xlabel('Oversample rate');
   ylabel('PAPR Estimation Error (dB)');
   setplotstyle
   savefig(['PAPR_Error_vs_Oversamp_' int2str(Ncarrs) '_tone_low_papr.tif'])
else
   PAPR1 = PAPR;
   OverSampList1 = OverSampList;
   PAPRErr1 = PAPRErr;
end

if PlotFlag == 1
   PAPR1 = PAPR;
   OverSampList1 = OverSampList;
   PAPRErr1 = PAPRErr;
end
