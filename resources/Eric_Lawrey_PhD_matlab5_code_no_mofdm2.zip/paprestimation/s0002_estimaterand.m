%This script estimates the maximum PAPR (crest factor in dB) error
%for random phase angle DMT signals. It was found that the number 
%of tones used does not effect the answer. The PAPR error is 
%estimated by comparing the PAPR with the maximum found.
%This script took 9100 sec to perform 20000 test trials on a
%650MHz Pentium III. Good results can still be obtained be reducing
%reducing the number of trials (Nrep) to a lower value, such as
%1000. This will reduce the simulation time to about 8 min.

%Copyright Eric Lawrey 1/1/1

%Thus Function Requires:
% paprvsinterp
%  - ofdmmod
% savefig
% setplotstyle

tic
ReqCarrList = [2,8,256];	%List of number of tones to test
Nrep = 20000;		  %Number of trials to run for each number of tones
OverSampList = intlogspace(1,128,15);		%Oversample rate list

PAPRResult = [];
PAPRerrResult = [];

%List of markers to use on the plot
MarkerList = {'.','^','none','x','s','<'};
MarkerSize = [25,18,20,20,20,22];
%List of colours to use for the lines, RGB triplets. There are extra values
%here to accommadate 7 lines on the plot.
ColourList = {[1,0,0],[0,0.8,0],[0,0,1],[0,0,0],[0.8,0,0.8],[0.8,0.8,0],[0,0.8,0.8]};

PAPRerrtemp = zeros(Nrep,length(OverSampList));
CarrListString = cell(1,length(ReqCarrList)+1);
for k = 1:length(ReqCarrList)
      disp(['Number of carriers : ' num2str(ReqCarrList(k))])
      for l = 1:Nrep
         Phase = rand(1,ReqCarrList(k))*2*pi;
         %Phase = linspace(0,rand*ReqCarrList(k)*pi,ReqCarrList(k)); %This will be an 
         %																				band limited impulse
         %Generate oversampled DMT, and measure the PAPR and the Error
         [PAPR,OverSamp,PAPRerr] = paprvsinterp(Phase,OverSampList);
         
         PAPRerrtemp(l,:) = PAPRerr;
         if rem(l,50)==0
            disp(['Rep : ' num2str(l) ' of ' num2str(Nrep)]);
         end
         
      end
      PAPRerrResult = [PAPRerrResult; max(abs(PAPRerrtemp))];
      CarrListString{k} = [num2str(ReqCarrList(k)) ' carriers'];
   end
%==================================================
% Calculate the theoretical error for a sine wave
%==================================================
%This is an estimate for a sinewave (not offset from zero)
CFerrordB = -10*log10(sin((pi/2)*(1-(1./(OverSampList)))).^2);

%This is the estimate made using a sine wave offset from DC
%CF2 = (1+2*sin(pi/2*(1-(1./OverSampList)))+sin(pi/2*(1-(1./OverSampList))).^2)/1.5;
%CFerrordB2 = 10*log10(8/3)-10*log10(CF2);
CF2a = (1+2*sin(pi/2*(1-(1./OverSampList)))+sin(pi/2*(1-(1./OverSampList))).^2);
CFerrordB2a = 10*log10(4)-10*log10(CF2a);
ind = find(OverSampList==1);
CFerrordB(ind) = NaN*ones(1,length(ind));
CarrListString{k+1} = 'Theory';
%==============================
% Plot the results
%==============================
disp(['Processing time : ' num2str(toc) ' sec']);
h = loglog(OverSampList,(abs(PAPRerrResult)),OverSampList,CFerrordB2,'x-');
axis tight
grid on
legend(h, CarrListString)

title(['(Search of ' num2str(Nrep) ' random phase DMT symbols)']);
xlabel('Oversample rate');
ylabel('Worst Crest Factor Estimation Error (dB)');
setplotstyle
for k = 1:length(h)
   set(h(k),'marker',MarkerList{k},'markersize',MarkerSize(k),'color',ColourList{k});
end
legend
set(h(length(ReqCarrList)+1),'markersize',18)
savefig(['s0002_MaxPAPR_Error_vs_Oversamp_rand_phase'])
