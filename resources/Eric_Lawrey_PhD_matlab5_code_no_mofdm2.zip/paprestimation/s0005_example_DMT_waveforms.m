%This script plots some example DMT signals. It shows that the phase 
%of the carriers greatly effects the PAPR of the signal.
ScriptRef = 's0005';
Numcarrs = 26;	%Number of carriers (There must be an evolved set for the
%					number of carriers)
GuardPeriod = 0;
Oversamp = 32;	%Oversampling of the DMT signals
Offset = 100;  %Carrier offset from DC. Since we are looking at the magnitude of
%the waveform (envelope) this has no effect
RealComplex = 1;	%0 = real, 1 = complex
Ph = zeros(3,Numcarrs);
%=======================================
% Calculate real DMT symbols
% Plot LOW PAPR EVOLVED symbol

%Load the evolved low papr phases
savefigflag = 1;
filename = 's0019_low_CF_DMT_phase_table';
load(filename);
%The phase table has the following variables:
%CF - CF for each of the number of tones (accurate to +- 0.001 dB)
%CarrList - List of the number of tones
%Phases - cell array of the phases angles for each on the number of tones

ind = find(CarrList==Numcarrs);
if isempty(ind)
   error(['No record of DMT with ' num2str(Numcarrs) ' in ' filename]);
end
Ph(1,:) = Phases{ind}';

%=======================================
% Calculate real DMT symbols
%Use a random seed so that the random phase plot is repeatable
rand('seed',986544);

%Choose a random phase for each carrier
Ph(2,:) = rand(1,Numcarrs)*2*pi;

%=======================================
% Calculate real DMT symbols
% Plot WORST CASE SYMBOL, i.e. phase = zero

%Chose a random phase for each carrier
Ph(3,:) = zeros(1,Numcarrs);
%Ph(3,:) = linspace(0,2*pi,Numcarrs);
papr2 = [];
for k = 1:3
   [papr, timesig]= phasepapr(Ph(k,:),Oversamp,Offset,RealComplex);
   papr2(k) = papr;
   %Normalise the mean power so that a sinewave would have a peak to peak of 2.
	refnorm = timesig/(sqrt(mean(abs(timesig).^2)));
   if k ==1
      timesig2 = zeros(3,length(refnorm));
   end
   timesig2(k,:) = refnorm';
end
t = linspace(0,1,length(timesig));

%Plot the signal
figure(1)
h1 = plot(t,abs(timesig2'));
legend(h1,['low CF:' num2str(papr2(1),3) 'dB'],['random phase:' num2str(papr2(2),3) 'dB'],...
   ['zero phase:' num2str(papr2(3),3) 'dB'])
xlabel('Time (Normalised to symbol period)');
ylabel('Envelope (Normalised Power)');

setplotstyle(1.5)				%Set up fonts and linewidths
set(h1(2),'marker','.','markersize',35,'color',[0 0.8 0]);	%Turn marker on so it will come up in the legend
set(h1(1),'linewidth',3);	%increase the line width
legend							%redo the legend to update for the new line width
set(h1(2),'marker','none'); %turn off the marker because there are too many of them
axis auto
hold on
%plot a subsampled signal which will have the markers on
M = 32;
plot(t(1:M:end),abs(timesig2(2,1:M:end)),'linestyle','none','marker','.','markersize',25,'color',[0 0.8 0]);
hold off
savefig([ScriptRef '_DMT_' num2str(Numcarrs) '_tones']);