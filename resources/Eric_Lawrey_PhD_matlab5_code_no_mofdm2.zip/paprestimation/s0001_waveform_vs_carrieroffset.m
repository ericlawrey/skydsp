%This script plots the real time domain waveform for evolved low 
%papr references, showing the time waveform for different carrier 
%frequency offsets.
%Copyright Eric Lawrey 4/1/1
clear all
ScriptRef = 's0001';
Ncarrs = 26;
savefigflag = 1;
CarrList2 = [2 32 256];		%List of carrier offsets to plot
filename = 's0019_low_CF_DMT_phase_table';
load(filename) 
%The phase table has the following variables:
%CF - CF for each of the number of tones (accurate to +- 0.001 dB)
%CarrList - List of the number of tones
%Phases - cell array of the phases angles for each on the number of tones

ind = find(CarrList==Ncarrs);
if isempty(ind)
   error(['No record of DMT with ' num2str(Ncarrs) ' in ' filename]);
end
Ph = Phases{ind}';
Amp = ones(1,Ncarrs);
ifftsize = 2^14;
GuardPeriod = 0;
[x,y] = pol2cart(Ph,Amp);
iqdata = x+sqrt(-1)*y;

t = linspace(0,1,ifftsize);

%=======================================
% Calculate complex base band DMT symbol
data_carriers = -floor(Ncarrs/2-0.1):floor(Ncarrs/2);
data_bins_interp = data_carriers;
Ind = find(data_carriers<0);
data_bins_interp(Ind) = data_bins_interp(Ind)+ifftsize;
data_bins_interp = data_bins_interp+1;
real_complex = 'complex';
refsinterp = ofdmmod(iqdata, data_bins_interp, ifftsize, GuardPeriod, real_complex, 1);
refnorm2 = refsinterp/(max(abs(refsinterp)));

%=======================================
% Calculate real DMT symbols
real_complex = 'real';

papr = zeros(size(CarrList2));
for k = 1:length(CarrList2)
	carrmin = CarrList2(k);
	data_carriers = carrmin:(carrmin+Ncarrs-1);
   refsinterp = ofdmmod(iqdata, data_carriers, ifftsize, GuardPeriod, real_complex, 1);
   papr(k) = calcpapr(refsinterp,1);
   refnorm = refsinterp/(max(abs(refsinterp)));
   figure(1)
   h1 = plot(t,real(refnorm));
   figure(1);
	hold on
	h2 = plot(t,real(abs(refnorm2)),'r');
	hold off
   title([num2str(Ncarrs) ' tones, Carrier Offset : ' ...
         num2str(CarrList2(k)) ' tone spacings']);
   xlabel('Time (Normalised to symbol period)');
   ylabel('Amplitude (Normalised to peak)');
   setplotstyle(1.5)
   set(h2,'linewidth',4)
   legend([h1,h2],'Real DMT symbol','Magnitude of Complex Base Band DMT symbol',3)
   axis([0 1 -1.4 1.05])
   if savefigflag
   	savefig([ScriptRef '_carr_offset_' num2str(carrmin) '_for_' num2str(Ncarrs) '_tones']);
   end
   figure(2)
   f = 20*log10(abs(fft(refsinterp))+eps);
   plot(f(1:300));
   title([num2str(Ncarrs) ' tones, Carrier Offset : ' ...
         num2str(CarrList2(k)) ' tone spacings']);
   ylabel('Power (dB)');
   xlabel('Frequency (Normalised to the Carrier Spacing)');
   setplotstyle
   if savefigflag
      savefig([ScriptRef '_carr_offset_' num2str(carrmin) '_for_' num2str(Ncarrs)...
            '_tones_spec']);
   end
end



