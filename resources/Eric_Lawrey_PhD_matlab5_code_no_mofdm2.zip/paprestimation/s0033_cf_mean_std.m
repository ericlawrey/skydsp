%This script plots the cummulative probability distribution of the
%CF of random phase DMT symbols.
%For N = 40 (actually becomes 37 different number of tones) the bench mark
%is about 0.141 seconds per trial, thus 5000 trials takes 5000*0.141 = 707 sec
%This is for oversampling 4 times
tic
ScriptRef = 's0032';
Ntrials = 5000;
N = 40;
Numcarrs = intlogspace(2,1024,N);	%Number of carriers (There must be an evolved set for the
%					number of carriers) This script is current set up to plot three
%					different number of carriers.

GuardPeriod = 0;
Oversamp = 4;	%Oversampling of the DMT signals
Offset = 0;  %Carrier offset from DC. Since we are looking at the magnitude of
%the waveform (envelope) this has no effect
RealComplex = 1;	%0 = real, 1 = complex
papr2 = zeros(length(Numcarrs),Ntrials);
for l = 1:length(Numcarrs)

   for k = 	1:Ntrials%Choose a random phase for each carrier
		Ph = rand(1,Numcarrs(l))*2*pi;
   	[papr, timesig]= phasepapr(Ph,Oversamp,Offset,RealComplex);
      papr2(l,k) = papr;
   end
   
	%if rem(l,2)==0
      disp([num2str(l) ' of ' num2str(length(Numcarrs))]);
      drawnow
   %end     
end
paprdB = 10*log10(papr2);
m = mean(paprdB');
s = std(paprdB');

sdB = sort(paprdB');
Ns = size(paprdB,2);
Prob99 = interp1(1:Ns,sdB,0.99*Ns);
Prob01 = interp1(1:Ns,sdB,0.01*Ns);
Prob90 = interp1(1:Ns,sdB,0.90*Ns);
Prob10 = interp1(1:Ns,sdB,0.1*Ns);
Prob001 = interp1(1:Ns,sdB,0.001*Ns);
Prob999 = interp1(1:Ns,sdB,0.999*Ns);

figure(1)
clf
h = semilogx(Numcarrs,Prob999,Numcarrs,Prob99,Numcarrs,Prob90,Numcarrs,m,...
   Numcarrs,Prob10,Numcarrs,Prob01,Numcarrs,Prob001);
axis tight
xlabel('Number of tones');
ylabel('CF (dB)');
colours = [0 0 0; 0 0 1];
legend(h,'99.9%','99%','90%','mean','10%','1%','0.1%',4)
setplotstyle
set(h(1),'marker','^','markersize',18,'color',colours(1,:));
set(h(7),'marker','.','markersize',30,'color',colours(2,:));
set(h(4),'linewidth',5)
legend
grid on
%Turn main markers off and replace them with markers only every several
%data points
set(h(1),'marker','none');
set(h(7),'marker','none');
hold on
M = 5;
h2 = semilogx(Numcarrs(1:M:end),Prob999(1:M:end),Numcarrs(1:M:end),Prob001(1:M:end));
hold off
set(h2(1),'marker','^','markersize',18,'linestyle','none','linewidth',1.5,'MarkerEdgeColor',colours(1,:));
set(h2(2),'marker','.','markersize',30,'linestyle','none','linewidth',1.5,'MarkerEdgeColor',colours(2,:));

savefig([ScriptRef '_mean_cf_vs_tones'])
hold off

figure(2)
clf
h = semilogx(Numcarrs,s);
axis tight
xlabel('Number of tones');
ylabel('standard deviation of CF dist (dB)');
setplotstyle
grid on
savefig([ScriptRef '_std_cf_vs_tones'])
hold off
disp(['Simulation time: ' num2str(toc) ' sec'])