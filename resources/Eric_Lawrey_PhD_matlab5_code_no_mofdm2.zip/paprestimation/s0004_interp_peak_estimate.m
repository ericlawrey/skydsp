%s0004
%This script demonstrates that interpolation is needed to accurately
%estimate the peak of a signal.
%
%Copyright Eric Lawrey 1/1/1

tmin  = 1;
tmax = 8;

%Generate sinewaves as the signals.
t = linspace(tmin,tmax,tmax);
Fc = 0.24;
ph = 0.9;
y = sin(t*2*pi*Fc+ph);

%Generate the sinewave with more points
%This is the same a if the signal was interpolated, however
%we don't have to worry about transients or that we have a
%very small sample size.
t2 = linspace(tmin,tmax,tmax*4);
y2 = sin(t2*2*pi*Fc+ph);

figure(1)
clf
[h] = plot(t,y,'b-o',t2,y2,'.r-');
axis([tmin tmax, -1.2 1.2]);

[ymx,I] = max(y);
to = t(I);
hl = line([3 to-0.1],[ymx ymx],'color',[0 0 0],'linestyle','-');

[ymx2,I] = max(y2);
ti = t2(I);
hl2 = line([3 ti-0.1],[ymx2 ymx2],'color',[0 0 0],'linestyle','-');

title(['Using interpolation to find the peak accurately']);
xlabel('Time (samples)');
ylabel('Amplitude');
setplotstyle
set(h(1),'linewidth',3);
text(2.2,ymx,sprintf('%1.4f',ymx),'color',[0 0 1],'fontsize',24)
text(2.2,ymx2,sprintf('%1.4f',ymx2),'color',[1 0 0],'fontsize',24)
legend(h,'Original','Interpolated')
savefig(['s0004_Peak_Estimation_using_interp'])
