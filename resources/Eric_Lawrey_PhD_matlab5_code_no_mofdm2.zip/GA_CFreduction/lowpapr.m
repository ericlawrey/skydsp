function [symb, phase] = lowpapr(phmethod,fftsize,Ncarrs,guardperiod,complexflag,err)
%symb = lowpapr(phmethod,fftsize,Ncarrs,guardperiod,complexflag)
%phmethod - phasing method, 
% 1 - S. Narahashi and T. Nojima, ph = (k-1)*(k-2)/(N-1)*pi
% 2 - Newman ph = (pi*(k-1)^2)/N
% 3 - Shapiro-Rudin Phasing scheme, We start with p=11, and repeatly concatenate
%     to p a copy of p with its second half negated
%		eg.   11
%         111-1
%      111-111-11
%  111-111-11111-1-1-11-1
% 0 - random sequence
% [0 X] - The zero indicates to use a random sequence, X is a random seed for
% the random number generator. This allows the same sequence to be used each time.
% This random seed does not effect random numbers generated outside this routine
% In fact the first value in the array is ignored. 

if nargin < 6
   err = zeros(1,Ncarrs);
end

if nargin < 5
   complexflag = 1;
end
if nargin < 4
   guardperiod = 0;
end
if nargin < 3
   Ncarrs = fftsize;
end

if length(phmethod)==1
   phmethod2 = phmethod;
else
   phmethod2 = 0;
   S = randn('state');	%Save the state of the random number generator
   randn('state',phmethod(2));
end

switch phmethod2
case 0 
   phase = rand(1,Ncarrs)*2*pi;
   amp = ones(1,Ncarrs);
case 1
   k = 1:Ncarrs;
   phase = (k-1).*(k-2)/(Ncarrs-1)*pi;
   amp = ones(1,Ncarrs);
case 2
   k = 1:Ncarrs;
   phase = (pi*(k-1).^2)/Ncarrs;
   amp = ones(1,Ncarrs);
case 3
   M = ceil(log2(Ncarrs));
   P = [1,1];
   for k = 1:M
      P = [P P(1:length(P)/2) -P((length(P)/2+1):length(P))];
   end
   %Crop to size
   phase = P(1:Ncarrs);
   phase = (phase+1)/2*pi;	%scale so that -1 => 0 and +1 => pi
   amp = ones(1,Ncarrs);
case 4
   %Erics Method
   k = 1:Ncarrs;
   %
   phase = (pi*(k.^2-k+1))/Ncarrs;
   amp = ones(1,Ncarrs);   
end
if length(phmethod)>1
   randn('state',S);
end

[x,y] = pol2cart(phase+err,amp);
iqdata = x+sqrt(-1)*y;
if complexflag == 1;
   real_complex = 'complex';
else
   real_complex = 'real';
end
fast_mode = 0;

if complexflag == 1
   data_carriers = -floor(Ncarrs/2-eps*100):floor(Ncarrs/2);
   data_bins = data_carriers;
   Ind = find(data_carriers<0);
   data_bins(Ind) = data_bins(Ind)+fftsize;
   data_bins = data_bins+1;
   
else
   data_bins = (-floor(Ncarrs/2-eps*100):floor(Ncarrs/2))+round(fftsize/4);
end
%size(iqdata)
%size(data_bins)
      
symb = ofdmmod(iqdata,data_bins, fftsize, guardperiod, real_complex, fast_mode)';


