function err = analpapr(filename,phmethod,complexflag)
%Returns the difference between an evolved Phase sequence and the starting
%reference phase sequence. 
if isstr(filename)
   load(filename)
   [Y,I]  = min(PAPR);
	p = Phase(I,:);
else
   %Filename is not a string so assume that it is phase data
	p = filename;
	if nargin<3
		error('When giving a carrier phases you must specify all parameters');
	end
end
if size(p,1) > 1
   p = p';
end
IFFTsize = 2.^nextpow2(length(filename));
Ncarrs = length(p);
GuardPeriod = 0;	%Assume no guard period

[symb,phase] = lowpapr(phmethod,IFFTsize,Ncarrs,GuardPeriod,complexflag);

ph1 = rem(phase,2*pi);
I1 = find(ph1>pi);
ph1(I1) = ph1(I1) - ones(size(I1))*2*pi;
I1 = find(ph1<(-pi));
ph1(I1) = ph1(I1) + ones(size(I1))*2*pi;

err = unwrap(unwrap(ph1)-unwrap(p));
%Sometime the data will have an offset from zero which is a multiple
%of pi;
err = err - round(mean(err)/pi)*pi;