function s0021_cfvg
%This script plots the Crest Factor verses generation for 
%multiple evolution runs. It plots the distribution of the
%the crest factor of all the evolution runs. It also plots
%the mean Crest Factor verses generation and compares this with multiple
%evolution runs. This shows the effect of different evolution
%parameters such as sexual reproduction and mutation rates etc.
%Copyright Eric Lawrey 18/10/00 Version 1.1
NoPlot = 1;
CF1 = cfvg('DataRand\phases026_*.mat','DataRand\s0021_asex',NoPlot);
CF2 = cfvg('DataSex\phases026_*.mat','DataSex\s0021_sex',NoPlot);
CF3 = cfvg('DataEv\phases026_P*.mat','DataEv\s0021_pop',NoPlot);
CF4 = cfvg('DataEv2\phases026_K*.mat','DataEv2\s0021_keep',NoPlot);
CF5 = cfvg('DataEv2\phases026_N*.mat','DataEv2\s0021_noise',NoPlot);
CF6 = cfvg('DataEv\phases026_D*.mat','DataEv\s0021_decay',NoPlot);
CF7 = cfvg('DataEv\phases026_V*.mat','DataEv\s0021_variance',NoPlot);
CF8 = cfvg('DataEv\phases026_N2*.mat','DataEv\s0021_noise2',NoPlot);
CF9 = cfvg('DataEv\phases026_K2*.mat','DataEv\s0021_keep2',NoPlot);
CF10 = cfvg('DataEv\phases026_Newman*.mat','DataEv\s0021_newman',NoPlot);
CF11 = cfvg('DataEv\phases026_SNTN*.mat','DataEv\s0021_SNTN',NoPlot);
CF12 = cfvg('DataEv\phases026_Mnoise*.mat','DataEv\s0021_Mnoise',NoPlot);
CF13 = cfvg('DataEv\phases026_Cdecay*.mat','DataEv\s0021_Cdecay',NoPlot);

X = 1:size(CF1,2);
figure(2)
h = semilogx(X,mean(CF1),'b',X,mean(CF2),'r');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',4)
set(h(2),'linewidth',2)
legend(h,'asex','sex');
setplotstyle([])
xlim([1 max(X)])
grid on
savefig('s0021_asex_vs_sex_CF')

figure(3)
h = semilogx(X,mean(CF2),'b',X,mean(CF3),'r');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',4)
set(h(2),'linewidth',2)
legend(h,'Pop = 100','Pop = 600');
setplotstyle([])
xlim([1 max(X)])
grid on
savefig('s0021_pop_increase_CF')

figure(4)
h = semilogx(X,mean(CF2),'b',X,mean(CF4),'r',X,mean(CF9),'k');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',2)
set(h(2),'linewidth',4)
set(h(3),'linewidth',2);

legend(h,'Keep = 30%','Keep = 50%','Keep = 70%');
setplotstyle([])
addmarkers(h(3),10,'.',40)
xlim([1 max(X)])
grid on
savefig('s0021_keep_increase_CF')

figure(5)
h = semilogx(X,mean(CF8),'r',X,mean(CF2),'b',X,mean(CF5),'k');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',2)
set(h(2),'linewidth',4)
set(h(3),'linewidth',2)
legend(h,'Seq Noise = 4','Seq Noise = 2','Seq Noise = 0.5');
setplotstyle([])
addmarkers(h(3),10,'.',40)
xlim([1 max(X)])
grid on
savefig('s0021_noise_decrease_CF')

figure(6)
h = semilogx(X,mean(CF12),'r',X,mean(CF10),'b',X,mean(CF11),'k');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',2)
set(h(2),'linewidth',4)
set(h(3),'linewidth',2)
legend(h,'Random','Newman','Narahashi & Nojima',3);
setplotstyle([])
addmarkers(h(3),10,'.',40)
xlim([1 max(X)])
grid on
savefig('s0021_start_comp_CF')

figure(7)
h = semilogx(X,mean(CF2),'r',X,mean(CF7),'b');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',2)
set(h(2),'linewidth',4)
legend(h,'Noise = X^2','Noise = X^4');
setplotstyle([])
xlim([1 max(X)])
grid on
savefig('s0021_variance_CF')

figure(8)
h = semilogx(X,mean(CF2),'r',X,mean(CF6),'b',X,mean(CF13),'k');
xlabel('Generation')
ylabel('Mean Crest Factor (dB)');
set(h(1),'linewidth',2)
set(h(2),'linewidth',4)
set(h(3),'linewidth',2)
legend(h,'Gen^0^.^6','Gen^0^.^4','Gen^0^.^2');
setplotstyle([])
addmarkers(h(3),10,'.',40)
xlim([1 max(X)])
grid on
savefig('s0021_decay_rate_CF')

figure(9)
[N,x] = hist(CF1(:,end));
bar(x,N/sum(N),1)
xlabel('Crest Factor (dB)')
ylabel('Probability')
title(['Generation : ' num2str(size(CF1,2))]);
setplotstyle
savefig('s0021_CFdist_asex')

function addmarkers(h,Nmarkers,MarkerType,MarkerSize)
%This function adds markers to the line given. The markers are
%spaced out regardless of the number of data points. This is
%useful for plots with many points. This function only works
%for one line with a marker and only for linear and log points

%Nmarkers = 10;
%MarkerType = '.';
%MarkerSize = 40;
%Turn on the markers for the line, and update the legend
%This will make the legend show the correct line and marker.
set(h,'marker',MarkerType,'markersize',MarkerSize*2);
legend
set(h,'marker','none');			%Turn the markers off because there will be
%										too many of them for plots with many points.
x = get(h,'xdata'); y = get(h,'ydata');		%Get the data off the plot
p = get(h,'parent');				%Get the handle of the axes
xscale = get(p,'xscale');		%xscale will be log for a log plot
c = get(h,'color');
%Calculate an index of x and y data points to plot the markers on
if strcmp(xscale,'log')
   ind = unique(round(logspace(log10(min(x)),log10(max(x)),Nmarkers)));
else
   ind = unique(round(linspace(min(x),max(x),Nmarkers)));
end

hold on
if strcmp(xscale,'log')
   semilogx(x(ind),y(ind),'markersize',MarkerSize,'marker',MarkerType,'linestyle','none','color',c)
else
   plot(x(ind),y(ind),'markersize',MarkerSize,'marker',MarkerType,'linestyle','none','color',c)
end
hold off

function PAPRrec = cfvg(Filename,FileOut,NoPlot)
disp(['Loading : ' Filename]);
d = dir(Filename);
%filenames=d.name;
Nfiles = length(d);

Npoints = 2000;
filenames = cell(1,Nfiles);
[pathn,file,ext,ver] = fileparts(Filename);
for k = 1:Nfiles
   filenames{k} = [pathn filesep d(k).name];
end
load(filenames{1})
GenNum = length(BestPAPR);
PAPRrecord = ones(Nfiles,GenNum);

for k = 1:length(filenames)
   load(filenames{k})
   if length(BestPAPR)<GenNum
      PAPRrecord(k,:) = [BestPAPR Nan*ones(1,GenNum-length(BestPAPR))];
   else
      PAPRrecord(k,:) = BestPAPR(1:GenNum);
   end
   
   if rem(k,20) == 0
      disp(['loaded ' num2str(k) ' of ' num2str(Nfiles)]);
   end
   
end
if NoPlot==0
figure(1)
Nplots = ceil(Nfiles/20);
B = plotphos2(1:GenNum,PAPRrecord,1,[640 480],[1 Npoints 0.8 5.1],Nplots,'','Generations','CF (dB)');
savefig(FileOut,'jpg')
end
if nargout>0
   PAPRrec = PAPRrecord;
end

function B = plotphos2(X,Y,Gamma,Size,Axis,M,Title,Xlabel,Ylabel)
clf
set(gcf,'units','pixels');
set(gcf,'position',[80 80 Size(1) Size(2)]);
set(gcf,'color',[1 1 1])
semilogx(X,Y(1:M,:)','k');
axis(Axis);
setplotstyle
f = getframe(gcf);
A = double(f.cdata);
for k = 2+M-1:M:size(Y,1)-M+1
   semilogx(X,Y(k:k+M-1,:)','k');
   xlabel(Xlabel);
   ylabel(Ylabel);
   title(Title);
   setplotstyle
   axis(Axis);
   f = getframe(gcf);
   A = A+double(f.cdata);
end
N = length(2+M-1:M:size(Y,1)-M+1)+1;
A = clip((A/N/255).^(1/Gamma),0,1);

subplot('position',[0 0 1 1])
image(A)
axis off

if nargout == 1
   f = getframe(gcf);
   B = double(f.cdata);
end

