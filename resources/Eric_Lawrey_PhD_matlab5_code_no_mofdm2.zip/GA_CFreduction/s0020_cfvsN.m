%S0020_cfvsN This script plots the crest factor of the
%evolved low CF DMT symbols, verses the carrier number

load s0019_low_CF_DMT_phase_table
semilogx(CarrList,CF)
title('Evolved Crest Factor verses number of tones');
xlabel('Number of tones');
ylabel('Crest Factor (dB)');
setplotstyle
grid on
axis([2 512 0.6 3])

set(gca,'ytick',[0:0.2:3])
set(gca,'xtick',[2 3 4 5 6 7 8 9 10 20 30 40 50 60 70 80 90 100 200 300 400 500]);
set(gca,'xticklabel',{'2','3','4','5','6','7','8','','10','20','30','40','','60',...
      '','','','100','200','300','','500'});
savefig(['s0020_cfvsn']);