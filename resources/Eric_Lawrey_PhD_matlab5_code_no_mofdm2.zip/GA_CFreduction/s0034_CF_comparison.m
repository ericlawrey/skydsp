%These are CF results from 
%S. Narahashi, K. Kumagai and T. Nojima, 'Minimising peak to average ...
%power ratio of multitone signals using steepest descent method', Electronic Letters, 
%Vol. 31, No. 18, pg 1552-1554, 31st August 1995
CFSN = [2.22 1.875 1.97 2.39 1.39 1.57 1.16 1.62 1.2 1.4 ...
      1.31 1.35 1.23 1.19 1.27 1.37 1.2 1.35 1.34 1.38 1.2 1.38];
NcarrsSN = [3:24];
load s0019_low_CF_DMT_phase_table
CFlist = [1:23];
h = plot(NcarrsSN,CFSN,CarrList(CFlist),CF(CFlist));
set(h(1),'marker','o',15)
set(h(2),'marker','^',15)
legend(h,'Steepest Descent','Genetic Algorithm Optimised');
axis tight
grid on
xlabel('Number of tones')
ylabel('Crest Factor (dB)')
set(gca,'ytick',1:0.2:3.6);
set(gca,'xtick',0:2:24)
setplotstyle(1.5,1,15);
savefig('s0034_CF')