function paprsim(arg)
%This script continues the evolution for a set of DMT phase sequences.
%'arg' determines which set of carriers to run. I am using an
%input parameter so that I do not require multiple scripts.
%Each paprsim(x) can be run on a different computer allowing
%parallel processing. Each case in the 'arg' switch statement
%is the carriers which are to run on each machine.
%This simulation is restartable, and can be cancelled at any
%time. The state of the simulation is saved evergy several
%generations (specified by saverate).
%
%-----------------------------------------------------------
% Copyright (c) Eric Lawrey July 2000
% version 2.1

%Each case statement corresponds to the carriers which will be evolved
%by each simulation. Adding more case statements allows paprsim to
%be used to run multiple parallel simulations using the one file.
%For example
% switch arg
% case 1
%    Ncarrs = [2 3 4 5 6];
% case 2
%    Ncarrs = [7 8 32 64];
% end
%
%Using parasim(1) will evolve for 2,3,4,5,6 tones, and paprsim(2) will 
%evolve for 7,8,32,64 tones. These can be executed on different matlab
%sessions on the supercomputer.
%
% NOTE: This simulation allows you to change most of the parameters of the simulation
% such as population etc. Thus if you want to continue the simulation of an old file
% such as those in EvolveFiles2_512 you need to set the conditions to match these
% evolutions. Of course you can change the evolution parameters if you which. Each
% simulation run has a record of all relevant parameter included with the saved file.
% Use:
% clear all
% load EvolveFiles2_512\phasesXXX.mat
% whos
% to look at the variables and history for that evolution, where XXX is the number of
% carriers.
phmethod = 2;				%Newman
% 0 - random
% 1 - S. Narahashi and T. Nojima, ph = (k-1)*(k-2)/(N-1)*pi
% 2 - Newman ph = (pi*(k-1)^2)/N
% 3 - Shapiro-Rudin Phasing scheme, We start with p=11, and repeatly concatenate
%     to p a copy of p with its second half negated
%		eg.   11
%         111-1
%      111-111-11
%  111-111-11111-1-1-11-1

if nargin<1
   error('You must give a simulation number to indicate what to run. Try edit paprsim')
end
%=========================
% These are the parameters to apply to the current simulation. All the evolved sets that
% I was doing used the same evolution parameters, hence the reason they are here. If you
% want different parameters for each data set modifiy these in the SWITCH statement 
% below.

MaxGen = 5000;			%Maximum number of generations that will be simulated
% for a given number of tones. 
FlopsLimit = 200e16;	%Maximum number of flops before stopping
%		This is used for benchmarking the evolution rate. Set it to a large
%    number if no limit is wanted
Pop = 100;				%Population. Number of phase sequences to breed in each generation
KeepPop = 30;			%Number of phase sequences to keep for breeding to get the next generation
Change = 2;				%Randomisation amount added to sequence after sexual reproduction (mutations)
ChangeVariance = 2;	%This must be an integer. The random mutations sequences with one 
%per phase sequence are scaled by another random number. This number gives us more 
%varitation so that most of the population has a small variation allowing tracking 
%into nulls, but some have a large variation to prevent being stuck in local minima. 
%R => Guassian random sequence to be added to a particular phase sequence
%R = randn(1,Phase Sequence Length)*(Rscale)*Change*(GenNum)^(Decay);
%Where GenNum is the number of generations already simulated, Decay is the decay value given.
%Rscale = randn1*randn2....*.....randnN; where N is the ChangeVariance. The change 
%variance spreads the probability distribution from a normal distribution to something 
%which is peaky around zero, but has large outliers. 

% This is decayed with the number of generations in evolvepapr3.
SexualFlag = 0;			%1 = Use sexual reproduction, 0 = Use asexual reproduction
OverSamp = 8;				%Oversample rate for PAPR estimation
saverate = 500;			%Number of generations between saving the results
SRandFlag = 0;				%1 = use rands instead of randn for mutations (see evolvepapr3)
SpreadM = 0;				%Amount of spreading for rands
Decay = 0.6;
SaveMovieFlag = 0;		%Flag to set whether to plot the sequence distribution 
%								and save the results of the plots.
%								This movie shows how the sequence changes with generations
%								however it greatly slows down the simulation rate.
MovieFile = 'imag\imag'; %Directory and start of the filename of the images in the
%								movie. To make a movie these files must be combined in 
%								a video editing package.
%MovieFrameList = [1:2:128 132:4:256 264:8:512 (512+16):16:1024 (1024+32):32:2048];
l = logspace(0,log10(5000),250);
MovieFrameList = unique(round(l));
%Number of generations before moving on to the next simulation
%Calculate more generations for lower number of carriers other wise
%most of the time will be spent calculating the simulations for
%large number of carriers


DataDir = 'DataRand'; %Directory where the phases files are stored

FileMod = ''; %ending on the filename
switch arg
case 1
   Ncarrs = [12 13 20 23 24 27 28 32 40 56 62 68 72 76 80]; 
case 2
   Ncarrs = [84 88 92 96 100 104 108 ];
case 3
   Ncarrs = [112 116 120 124 128 136 144 152 160];
case 4
   Ncarr = [168 176 184 192 200 208 216];
case 5
   Ncarrs = [224 232 240 248 256 272];
case 6
   Ncarrs = [288 304 320 336 352];
case 7
   Ncarrs = [368 384 400 416 432];
case 8 
   Ncarrs = [448 464 480 496 512];
case 9 
   Ncarrs = [64];
case 10
   Ncarrs = [26*ones(1,400)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
case 11
   Ncarrs = 26;
   phmethod = [0 sum(clock*100)];	%Use random phase angle
case 12
   Ncarrs = [26*ones(1,400)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataSex';
   SexualFlag = 1;
case 13
   %Bigger Population
   Pop = 600;
   KeepPop = 200;
   Ncarrs = [26*ones(1,1000)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv';
   SexualFlag = 1;
   FileMod = 'P';
case 14
   %Bigger KeepPop
   Pop = 100;
   KeepPop = 50;
   Ncarrs = [26*ones(1,1000)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv2';
   SexualFlag = 1;
   FileMod = 'K';
case 15
   %Smaller Noise
   Pop = 100;
   KeepPop = 30;
   Ncarrs = [26*ones(1,1000)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   Change = 0.5;
   DataDir = 'DataEv2';
   SexualFlag = 1;
   FileMod = 'N';
case 16
   %Slower Noise decay
   Pop = 100;
   KeepPop = 30;
   Ncarrs = [26*ones(1,100)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.4;
   FileMod = 'D';
case 17
   %Increased Noise variance
   Pop = 100;
   KeepPop = 30;
   Ncarrs = [26*ones(1,100)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.6;
	ChangeVariance = 4;
   FileMod = 'V';
case 18
   %Increased Noise Again
   Pop = 100;
   KeepPop = 30;
   Ncarrs = [26*ones(1,100)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.6;
   Change = 8;
   FileMod = 'N2';
case 19
   %Increased Keep Pop
   Pop = 100;
   KeepPop = 70;
   Ncarrs = [26*ones(1,100)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv';
   SexualFlag = 1;
   FileMod = 'K2';  
case 20
   %Newman Phasing as starting point
   Pop = 1000;
   KeepPop = 500;
   Ncarrs = [26*ones(1,25)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = 2;	%Use newmans phasing scheme
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.6;
   Change = 0.5;
	FileMod = 'Newman';   
case 21
   %Newman Phasing as starting point
   Pop = 1000;
   KeepPop = 500;
   Ncarrs = [26*ones(1,25)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = 1;	%Use S. Narahashi and T. Nojima phasing scheme
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.6;
   Change = 0.5;
   FileMod = 'SNTN';  
case 22
   %Newman Phasing as starting point
   Pop = 1000;
   KeepPop = 500;
   Ncarrs = [26*ones(1,25)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = 1;	%Use S. Narahashi and T. Nojima phasing scheme
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.6;
   Change = 2;
   FileMod = 'SNTNN'; 
case 23
   %Random Phasing as starting point
   Pop = 1000;
   KeepPop = 500;
   Ncarrs = [26*ones(1,25)];
   phmethod = [0 28763412];	%Use random phase angle
   %phmethod = 2;	%Use newmans phasing scheme
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.6;
   Change = 4;
   FileMod = 'Mnoise';  
case 24
   %Slower Noise decay
   Pop = 100;
   KeepPop = 30;
   Ncarrs = [26*ones(1,100)];
   %phmethod = [0 28763412];	%Use random phase angle
   phmethod = [0 sum(clock*100)];	%Use random phase angle
   DataDir = 'DataEv';
   SexualFlag = 1;
   Decay = 0.2;
   FileMod = 'Cdecay';
case 25
   Pop = 2000;
   KeepPop = 1000;
   Ncarrs = [17 19 17 19 17 19];
   phmethod = 1;
   DataDir = 'DataEvNew'
   SexualFlag = 1;
   Decay = 0.6;
   Change = 2;
   FileMod = 'new';
   rdisp = 200*ones(size(Ncarrs));
   saverate = 50;			%Number of generations between saving the results
   Ngenerations = 200*ones(size(Ncarrs));
case 26
   Pop = 200;
   KeepPop = 100;
   Ncarrs = [32];
   phmethod = 2;
   DataDir = ''
   SexualFlag = 1;
   Decay = 0.6;
   Change = 2;
   FileMod = '';
   rdisp = 200*ones(size(Ncarrs));
   saverate = 50;			%Number of generations between saving the results
   Ngenerations = 200*ones(size(Ncarrs));   
end

%Ngenerations = max(round((1./Ncarrs)*16),1);	%Number of generations to
% calculate before returning to paprsim, and proceeding to the next number
% of carriers. This is used as a crude task schedular, so that for sets
% which have a set of different number of tones, each one gets a reasonable
% amount of processing time.

%Ngenerations = 1000*ones(size(Ncarrs));

%Increase the screen refresh rate for large numbers of carriers
%rdisp = max(round(4000./Ncarrs),1);
%rdisp = (Pop-1)*ones(size(Ncarrs));
%rdisp = 100*ones(size(Ncarrs));
%-------------------------------------------------------------------------
% All paprmeters have been set
%-------------------------------------------------------------------------

%Each paprsim(x) has an initialisation file for recording which carrier
%number it was up to. This is to prevent it from restarting a the start of
%the carrier list each time the simulation is stopped and started.
inifilename = ['paprsimini' int2str(arg) '.mat'];
if exist(inifilename,'file')
   %Load the current simulation state
   load(inifilename)
else   
   Ncurrent = 1;
end

%If Ncurrent is bigger than Ncarrs than the number of carriers in the simulation
%must have changed, therefore set Ncurrent start again.
if Ncurrent > length(Ncarrs)
   Ncurrent = 1;
end
NotFinished = 1;		%Flag to indicate if all simulations are complete
FinishedSet = zeros(size(Ncarrs));
while NotFinished
   s = [int2str(Ncarrs(Ncurrent))];
   z = '000';
   s2 = [z(1:(length(z)-length(s))) s];
   %filename = ['phases' s2 '.mat'];
   filename = ['phases' s2 '_' FileMod num2str(Ncurrent) '.mat'];
   refsfile = [DataDir filesep filename];
   disp(['File: ' refsfile])
   simparameters = {Pop, KeepPop, Change,SexualFlag, Ncarrs(Ncurrent), phmethod, OverSamp...
         rdisp(Ncurrent), saverate, Ngenerations(Ncurrent), MaxGen, SRandFlag, SpreadM, ...
         FlopsLimit, Decay, SaveMovieFlag, MovieFrameList, MovieFile};
   FinishedSet(Ncurrent) = evolvepapr3(refsfile,simparameters);

	%Check if all simulations are complete
   if sum(FinishedSet) == length(Ncarrs)
      NotFinished = 0;
      disp('Completed All Simulations');
   end
   
   Ncurrent = Ncurrent+1;
   %Start the set of tone simulations again after doing all of them
   if Ncurrent > length(Ncarrs)
      Ncurrent = 1;
   end
   save(inifilename,'Ncurrent')
end
