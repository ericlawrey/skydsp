function FinishedFlag = evolvepapr3(refsfile,simparameters)
%EVOLVEPAPR3 Calculates evolved generations for Ultra Low PAPR DMT signals
%   FinishedFlag = evolvepapr3(refsfile,simparameters)
%   FinishedFlag: Indicates whether the maximum number of generations have been
%      completed for the file given in refsfile. FinishedFlag = 1, Maximum Number
%      generations completed, FinishedFlag = 0, still simulations to complete.
%   simparameters = {Pop, KeepPop, Change,SexualFlag, Ncarrs, phmethod, OverSamp...
%      rdisp, saverate, Ngenerations, MaxGen, SRandFlag, SpreadM, FlopsLimit, ...
%      Decay, SaveMovieFlag, MovieFrameList, MovieFile};
%   simparameters is a cell array so that variables contained in it can be an array
%   refsfile : filename to save simulation result to.
%   Pop: Population to use for the next generation = simparameters(1);
%   KeepPop: Number of Sequences to keep after each generation = simparameters(2);
%   Change: Amount of randomise noise added to the Phase (in radians). This is
%      effectively asexual mutations. Set to 0 for no mutations. simparameters(3);
%   SexualFlag: 1 = use sexual reproduction. This is done by pairing sequences.
%      A random splice location then used and applied to the two sequences. The 
%      resulting output is the combination of the first section from sequence 1 
%      and the second section of sequence 2. 
%      0 = Don't use sexual reproduction, only asexual mutations. 
%      simparameters(4);
%   Ncarrs: Number of carriers to simulate. simparameters(5)
%   phmethod: Starting phasing method
%      0 - random
%      1 - S. Narahashi and T. Nojima, ph = (k-1)*(k-2)/(N-1)*pi
%      2 - Newman ph = (pi*(k-1)^2)/N
%      3 - Shapiro-Rudin Phasing scheme
%   OverSamp: Oversampling of the carriers in the time domain. This is done to improve
%      the accuracy in measuring the PAPR. By oversampling to true peaks in the signal
%      can be accurately found. The base length of the time domain signal is made to 
%      be the next power of 2 of the number of carriers*OverSamp.
%      This indirectly sets the accuracy of the PAPR estimations. Oversampling by
%		  > 16 times gives an error bound on the PAPR of about 0.001dB.
%      simparameters(7);
%   rdisp: Number papr estimations to calculate before displaying the progress of
%      the simulation. rdisp should be 1 for large number of carriers (> 256) in order for the
%      display refresh of about 1-2 sec. rdisp can be larger for smaller number of carriers
%      simparameters(8);
%   saverate: Number of generations to calculate before saving a working back up the
%      simulation. saverate should be less than or equal to Ngenerations. If it is 
%      bigger it will be reduced to Ngenerations. simparameters(9);
%   Ngenerations: Number of generations to calculate before exiting the simulation.
%      Settings Ngenerations allows a higher level simulation to loop through different
%      simulations each with a different number of carriers. simparameters(10);
%   MaxGen: Maximum number of generations to simulate. evolvepapr3 will exit if the
%      number of generations calculated in greater or equal to MaxGen. simparameters(11);
%   SRandFlag: Flag to set whether to use gaussian noise for mutations (see Change) or
%      to use an adjusted distribution which is wider spread than the normal distribution
%      probability distribution function.
%      The noise is generated the same as randn except that multiple gaussian random numbers are
%      multipled together to produce a random number with a high probability of being near zero,
%      and a small probability of being large. Multipling the random numbers make the standard 
%      deviation the same but the probability of large variations is increased
%      simparameters(12);		%1 - use randns 0 - use randn for change. 
%	 SpreadM Spreading used for randns. X1*X2*X3*.....XM where X is a gaussian random variable 
%      and M is SpreadM. simparameters(13) 
%	 FlopsLimit: Simulation will stop once the total Flops reaches this limit. This is useful
%      for comparing is it is better to use a larger or smaller population. One has more
%      diversity where as the other has more generations. With FlopsLimit the simulation
%      can be stopped after a set number of calculations to compare which gives the lowest
%      PAPR for a given number of calculations.
%   Decay: This is the decay rate of the random mutations. 
%      Mutation amount = Change/((NumGenerations)^(Decay))
%   SaveMovieFlag: This generates a movie. The evolve sequences are plotted after each data save
%      and saved as an image. This can be used to create a moview of how the sequences
%      evolve with generations.
%   MovieFrameList: List of all the generations to plot for the movie. For example:
%      MoviewFrameList = [1:16 18:2:32];
%      This list should be sorted. I am not sorting it here because it would only get
%		 resorted many times each time this function is run.
%   MovieFile: Directory and start of the file names of the frame images. For example:
%      MovieFile = 'imag\imag' Would save the images to a directory called imag and whould
%      have frame filename like imag00001.jpg etc.
%
%-----------------------------------------------------------------------------------------
%   Copyright (c) Eric Lawrey July 2000
%   Version 3.2

%Randomise based on the clock
c = clock;
randn('seed',sum(c)*10);
rand('seed',sum(c)*20);
complexflag = 1;	%Use complex for all calculations
GuardPeriod = 0;

PlotsFlag = 1;	   %Generate plots
if nargin < 2
   error('evolvepapr3 requires at least two inputs');
end

%===========================================
%  OPEN EXISTING FILE
%===========================================
if exist(refsfile,'file')
   if exist([refsfile '.bak'],'file')
      disp('============================================================');
      disp(['Backup exists for : ' refsfile]);
      disp('This indicates that a save failure occurred during the last');
      disp('run of the simulation. Simulation file could be corrupt.');
      disp('Simulation will continue from the saved backup instead');
      disp('============================================================');
      %Load the backup file. If it is corrupt the script will fail here
      load([refsfile '.bak']);
      disp('Backup Loaded successfully');
      %Make a copy of the backup over the orginal simulations script. We have to 
      %copy it before we delete the backup because the script could be cancelled
      %before the next file save.
      status = copyfile([refsfile '.bak'],refsfile);
      if status == 0
         error('Copying of backup over original simulation file failed, fatal error');
      else
         disp('Copied backup over original simulation file');
         %delete the backup so that this procedure will not occur forever
         delete([refsfile '.bak']);
         disp('Deleted backup file')
      end

   else
      %Load the precalculated generations
      load(refsfile);
      disp(['Loading Filename : ' refsfile]);
   end
   Pop = simparameters{1};
   KeepPop = simparameters{2};
   Change = simparameters{3};
   SexualFlag = simparameters{4};
   %Ncarrs fixed during the simulation
   %phmethod fixed at startup
   OverSamp = simparameters{7};
   rdisp = simparameters{8};
   saverate = simparameters{9};
   Ngenerations = simparameters{10};
   MaxGen = simparameters{11};
   SRandFlag = simparameters{12};		%1 - use randns 0 - use randn for change. 
	SpreadM = simparameters{13};		   %Spreading used for randns
   FlopsLimit = simparameters{14};
   Decay = simparameters{15};
   SaveMovieFlag = simparameters{16}; 
   MovieFrameList = simparameters{17};
   MovieFile = simparameters{18};
   Ncarrs = size(Phase,2);  
   %For old simulation files without a delay record add one to them.
   if ~exist('DecayRecord','var')
      DecayRecord = [];
   end
   
%===========================================
%  NEW FILE
%===========================================
else
   %New file given so get the simulation data
   disp(['New File : ' refsfile]);
   Pop = simparameters{1};
   KeepPop = simparameters{2};
   Change = simparameters{3};
   SexualFlag = simparameters{4};
   Ncarrs = simparameters{5};
   phmethod = simparameters{6};
   OverSamp = simparameters{7};
   rdisp = simparameters{8};
   saverate = simparameters{9};
   Ngenerations = simparameters{10};
   MaxGen = simparameters{11};
   SRandFlag = simparameters{12};		%1 - use randns 0 - use randn for change. 
   SpreadM = simparameters{13};		   %Spreading used for randns
   FlopsLimit = simparameters{14};
   Decay = simparameters{15};
   SaveMovieFlag = simparameters{16};   
   MovieFrameList = simparameters{17};
   MovieFile = simparameters{18};
   SymbLen = 2.^nextpow2(Ncarrs);
   %Create an initial population of references
   if length(phmethod)>1
      S = rand('state');
      rand('seed',phmethod(2));
      Phase = rand(Pop,Ncarrs)*2*pi;
      rand('state',S)
   else
      [symb, Phase] = lowpapr(phmethod,SymbLen,Ncarrs,GuardPeriod,complexflag);
      Phase = repmat(Phase,Pop,1)+randn(Pop,Ncarrs)*Change;
   end
   
   
   %Initialise record keeping variables
   PopPAPR = [];
   BestPAPR = [];
   BestPHASE = [];
   ChangeRecord = [];
   PopRecord = [];
   KeepPopRecord = [];
   SexualFlagRecord = [];
   SRandFlagRecord = [];
   SpreadMRecord = [];
   FlopsRecord = [];
   TimeRecord = [];
   DecayRecord = [];   
end

%===================================
% Check the number of generations
% quit if reached number required
%===================================
GenNum = length(PopPAPR)+1;
if (GenNum >= MaxGen)|(sum(FlopsRecord)>=FlopsLimit)
   if (GenNum > MaxGen)
   	%Number of required generations completed so exit the function
   	disp(['Completed Max generations for ' num2str(Ncarrs)]);
   	FinishedFlag = 1;
	else
    	%Number of required FLOPS completed so exit the function
   	disp(['Completed Max FLOPS for ' num2str(Ncarrs)]);
      FinishedFlag = 1;
   end
   
else
   FinishedFlag = 0;
   %================================
   % Set up variables which will be 
   % constant in each generation
   %================================ 
   if saverate > Ngenerations
      saverate = Ngenerations;
   end
   
   %Setup whether the signal is complex or not. This is for use with OFDMMOD later.
   if complexflag == 1;
      real_complex = 'complex';
   else
      real_complex = 'real';
   end
   
   %===================================
   % Calculate the specified number of
   % generations before exiting
   %===================================
   for g = 1:Ngenerations

      FlopsStartGen = flops;	%Record the number of flops at the start of the generation
      tic;							   %Start timer for the generation timing
      
      GenNum = length(PopPAPR)+1;
      
      %Calculate how much random variation is to be added to the
      %phase during reproduction for the next generation
      %Use a decaying profile so that the noise decreases with
      %the number of generations.
      ChangeFac = Change/((GenNum).^Decay);
      
      %================================
      % Display Generation information
      %================================
      disp(['Calculating Generation : ' int2str(length(PopPAPR)+1)]);
      s = sprintf('Pop: %5d, KeepPop: %5d, Total Flops: %6d, Time doing Calcs: %4.2f mins,',...
         Pop,KeepPop, sum(FlopsRecord),sum(TimeRecord)/60);
      disp(s);
      s = sprintf('Change: %6f, Complex Wave flag : %1d',...
         ChangeFac,complexflag);
      disp(s);
      s = sprintf('OFDM symbols, with : %d carriers', Ncarrs);
      disp(s)
      drawnow
      
      %If it is the first generation than we can not calculate the next
      %generation yet as we haven't evalulated the performance of the
      %current first generation yet.
      if GenNum > 1
         %Calculate the Phase sequences for the current generation based on
         %the previous generation
         Phase = nextgenphase(PAPR,KeepPop,Pop,Phase,ChangeFac,SexualFlag,...
   		    SRandFlag,SpreadM);
      end
      PAPR = meas_papr(Phase, OverSamp, real_complex, GuardPeriod, rdisp, GenNum, refsfile,BestPAPR);
      
      %Calculate the average PAPR over the entire population
      PopPAPR = [PopPAPR mean(PAPR)];
      
      [Y,Ir] = min(PAPR);
      %Keep a record of the PAPR of the best sequence. 
      BestPAPR = [BestPAPR Y];
      %Keep a record of the best phase sequence for each generation
      BestPHASE = [BestPHASE Phase(Ir,:)'];
      %Keep a record of the random noise added for each generation
      ChangeRecord = [ChangeRecord ChangeFac];
      
      PopRecord = [PopRecord Pop];
	   KeepPopRecord = [KeepPopRecord KeepPop];
   	SexualFlagRecord = [SexualFlagRecord SexualFlag];
	   SRandFlagRecord = [SRandFlagRecord SRandFlag];
      SpreadMRecord = [SpreadMRecord SpreadM];
      FlopsRecord = [FlopsRecord flops-FlopsStartGen];
      TimeRecord = [TimeRecord toc];
      %Keep a record of the Decay used. Include a list of the generations
      %because it is an addition to the old files.
      temp = [Decay; GenNum];
      DecayRecord = [DecayRecord temp];
      
      if SaveMovieFlag
               if ~isempty(find(GenNum==MovieFrameList))
            figure(2)
            p = Phase(1:end/200:end,:);
            p = rem(p,2*pi);
            ind = find(p>pi);
            p(ind) = p(ind)-2*pi;
            ind = find(p<-pi);
            p(ind) = p(ind)+2*pi;            
            plotphos(p,2,[320,240],[1,size(p,2),-pi,pi]);
            FrameNum = min(find(GenNum==MovieFrameList));
            s = [int2str(FrameNum)];
   			z = '0000';
			   s2 = [z(1:(length(z)-length(s))) s];
            fileN = [MovieFile s2 '.jpg'];
            title(['Generation: ' sprintf('%5d',GenNum) ', Best CF: ' sprintf('%5.3f dB',BestPAPR(end))],'fontsize',14);
            f = getframe(gcf);
			   B = double(f.cdata);
            imwrite(B/248,fileN,'jpg','quality',100);
         	end
            end

      %==================================
      % Save the state of the simulation
      %==================================
      %Saving the state allows the simulation to be cancelled and restarted
      %at any time with out loosing too much. Only save the data after every
      %'saverate' generations. Saving after every generation can slow down
      %the simulation particularly if the number of carriers is small.
      %Only store essential variables.
      if rem(g,saverate)==0,
      
         if PlotsFlag
            G = 1:GenNum;
            figure(1);
            subplot(2,2,1)
            plot(G,PopPAPR); title('Population PAPR'); axis tight;
            
            subplot(2,2,2)
            timesig = timewave(Phase(Ir,:), OverSamp, real_complex, GuardPeriod);
            plot(abs(timesig)); title('Best Ref'); axis tight;
            
            subplot(2,2,3)
            semilogx(G,abs(BestPAPR)); title('Best ref PAPR'); axis tight;
            
            subplot(2,2,4)
            if length(phmethod)<2
	            err = analpapr(Phase(Ir,:),phmethod,complexflag);
               plot(err);	title('Evolved Phase Difference'); axis tight
            else
               plot(unwrap(Phase(Ir,:)));
               title('Evolve Phase');
            end
                  		%plot(Phase(1:end/100:end,:)')            
            drawnow
                  %Make a backup of the old simulated data, so that if the systems crashes
         %during the save it will not corrupt the simulation data.
         %This happened often on the supercomputer and when saving over a network.
         if exist(refsfile,'file')      
         	status = copyfile(refsfile,[refsfile '.bak']);
         	if status == 0
            	error(['Backup save of ' refsfile ' failed']);
            end
         end
         save(refsfile,'Phase','PopPAPR','BestPAPR','PAPR','complexflag',...
            'BestPHASE','phmethod','ChangeRecord','PopRecord','KeepPopRecord', ...
            'SexualFlagRecord','SRandFlagRecord','SpreadMRecord','FlopsRecord','TimeRecord',...
            'DecayRecord');
         delete([refsfile '.bak']);
         
         disp('Data Saved')   
         end
      end
   end
end



%******************************************************************************************


function Phase = nextgenphase(badness,KeepPop,NextGenPop,PhaseOld,ChangeFac,SexualFlag,...
   SRandFlag,SpreadM)
%=============================================
% Calculate the phases of the next generation
% This sections updates the Phase variable
%=============================================
Ncarrs = size(PhaseOld,2);
Pop = size(PhaseOld,1);
%Sort the PAPR of the previous generation to decide
%who survives 
[Y,Isurvive] = sort(badness);

if SexualFlag == 1
   %Keep and index of the best phases
   M1 = Isurvive(round(rand(1,NextGenPop)*KeepPop+0.5));
   M2 = Isurvive(round(rand(1,NextGenPop)*KeepPop+0.5));
   
   %Pick random splice points along the phase sequences
   SpliceLoc = round((Ncarrs-1)*rand(1,NextGenPop)+0.5);
   
   %Generate a pairs of phase matrices for the survivors
   R1 = PhaseOld(M1,:);
   R2 = PhaseOld(M2,:);
   
   Phase = zeros(NextGenPop,Ncarrs);
   
   %Sexually combine spliced phase sequences.
   %Take the first part of the phase sequence from R1 and the second
   %part from R2. The splice location is based on SpliceLoc.
   for k = 1:NextGenPop
      Phase(k,:) = [R1(k,1:SpliceLoc(k)) R2(k,(SpliceLoc(k)+1):Ncarrs)];
   end
else
   M1 = Isurvive(round(rand(1,NextGenPop)*KeepPop+0.5));
   Phase = PhaseOld(M1,:);
end


%Add a small random phase change
if SRandFlag == 1
   Phase = Phase+randns(size(Phase,1),size(Phase,2),SpreadM)*ChangeFac;
else
   RandScale = repmat(randns(size(Phase,1),1,4),1,size(Phase,2));
   Phase = Phase+randn(size(Phase))*ChangeFac.*RandScale;
end


%***********************************************************************************



function PAPR = meas_papr(Phase, OverSamp, real_complex, GuardPeriod, rdisp, GenNum, ...
   refsfile,BestPAPR)
%=============================================
% Measure the PAPR for the current generation
% This function returns the PAPR for each of 
% the Phase sequences given
%=============================================  
fast_mode = 1;		%Enable warnings in OFDMMOD, 0 - enable warnings, 
%							 1 - disable warnings (faster)
Pop = size(Phase,1);			%Population
Ncarrs = size(Phase,2);		%Number of Carriers
SymbLen = 2.^nextpow2(Ncarrs*OverSamp); %base IFFT size before oversampling

%Convert the phase information in to complex I/Q format
%Assume constant carrier power.
Amp = ones(Pop,Ncarrs)/sqrt(Ncarrs);
[x,y] = pol2cart(Phase,Amp);
iqdata = x+sqrt(-1)*y;
      
% Calculate the indexes of the carriers
if ~strcmp(real_complex,'real')
   data_bins_interp = [(-floor(Ncarrs/2-0.1):-1)+SymbLen 0:floor(Ncarrs/2)]+1;
else
   data_bins_interp = (-floor(Ncarrs/2-0.1):floor(Ncarrs/2))+round(SymbLen/4);
end

PAPR = zeros(1,Pop);
for k = 1:Pop
   %Find the Time Domain waveform of each phase sequence. Only do one a time to
   %minimise memory requirements.
   refsinterp = ofdmmod(iqdata(k,:), data_bins_interp, SymbLen, GuardPeriod, ...
      real_complex, fast_mode);
   %Over sampling of the waveform has been done in OFDMMOD by using a
   %larger FFT, and zero padding in the frequency domain. Thus we don't 
   %need to interpolate further in calcpapr.
   PAPR(k)  = calcpapr(refsinterp,1);
   
   %==============================
   % Display calculation progress
   %==============================
   if rem(k,rdisp) == 0
      if GenNum <= 1
         s = sprintf('P:%3d of %3d G:%3d %15s',...
            k,Pop,GenNum,refsfile);
         disp(s)
      else
         s = sprintf('P:%3d of %3d G:%3d PAPR:%5.3f %15s',...
            k,Pop,GenNum,BestPAPR(GenNum-1),refsfile);
         disp(s)
      end
      drawnow
   end
end

function r = randns(N,M,S)
%This function is the same as randn except that multiple gaussian random numbers are
%multipled together to produce a random number with a high probability of being near zero,
%and a small probability of being large. Multipling the random numbers make the standard deviation
%the same but the probability of large variations is increased
r = randn(N,M);
for k = 1:(S-1)
   r = r.*randn(N,M);
end

function timesig = timewave(Phase, OverSamp, real_complex, GuardPeriod)
%This function is used to calculate the waveform for a particular phase
%sequence.
Pop = size(Phase,1);			%Population
Ncarrs = size(Phase,2);		%Number of Carriers
SymbLen = 2.^nextpow2(Ncarrs*OverSamp); %base IFFT size before oversampling

%Convert the phase information in to complex I/Q format
%Assume constant carrier power.
Amp = ones(Pop,Ncarrs)/sqrt(Ncarrs);
[x,y] = pol2cart(Phase,Amp);
iqdata = x+sqrt(-1)*y;
      
% Calculate the indexes of the carriers
if ~strcmp(real_complex,'real')
   data_bins_interp = [(-floor(Ncarrs/2-0.1):-1)+SymbLen 0:floor(Ncarrs/2)]+1;
else
   data_bins_interp = (-floor(Ncarrs/2-0.1):floor(Ncarrs/2))+round(SymbLen/4);
end
fast_mode = 0;
%Find the Time Domain waveform of the phase sequence.
timesig = ofdmmod(iqdata, data_bins_interp, SymbLen, GuardPeriod, ...
      real_complex, fast_mode);