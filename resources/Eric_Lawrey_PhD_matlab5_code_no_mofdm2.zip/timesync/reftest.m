Nc = 64;
IFFTsize = 64;
c = mkcarriers(Nc,IFFTsize,'complex');
IQData = genref(Nc,3);
g = ofdmmod(IQData, c,IFFTsize,0,'complex');
a = [zeros(1,200) g.' g.' zeros(1,200)];
o2 = tmsyncds(a,IFFTsize);
[delpro] = gensimpimp(Ntaps,delspread);
filter(delpro,1,
plot(abs(o2))