%Simulate 
%Timothy M. Schmidl and Donald C. Cox, "Robust Frequency and Timing Synchronization for OFDM",
%IEEE Transactions on Communications, Vol. 45, No. 12, December 1997

%Construct the synchronisation block of two symbols. First symbol only uses every
%even carrier, resulting in duplicate 1st and 2nd half of the symbol. Second symbol
%also transmits of the odd carriers with a separate PN sequence.

%This script is called by other scripts containing the constant setups. I did this
%so that I could setup multiple simulations easily

%This is a list of some of the variables which can be set.
%TimeRandFlag -  (1) used random time offset, upto a maximum of MaxTimeOffset
%                (0) just use the value in MaxTimeOffset. Default = 1
%MaxTimeOffset - Sets the amount of time offset. If TimeRandFlag is set than
%                the time offset will be random up to a maximum of TimeOffset.
%                If not set the time offset will correspond to the value set
%                by MaxTimeOffset. The units of MaxTimeOffset are in symbols
%                Default = SymbPerFrm.
%TailSig       - Number of frames of zero signal to add to the end. This allows
%                The time synchroniser to use the entire block of frames for 
%                Synchronisation. Default = 0;
%ClipDistFlag  - Flag to enable clipping of the output of the transmitter.
%                Default = 0;
%OutBackoffdB  - Amount of clipping. The signal is clipped until the signal has
%                a crest factor of OutBackoffdB (dB). If OutBackoffdB is greater
%                the crest factor of the signal than no distortion occurs
%RefPowBoost   - Amount of power boosting to apply to the synchronisation (dB)
%					  symbol. If a low CF phasing scheme is used than the reference
%                can be boosted by 3dB while still maintaining a peak power
%                lower than most data symbols. Default = 0 dB                
%EnableFreqLockFlag Flag to enable or disable the frequency locking system
%                (1) - Use the frequency lock system.
%                (0) - Don't Do any frequency locking. The frequency error
%                will correspond to freqoffset
%                DEFAULT = 1
%FineFreqLock    Chooses the frequenncy locking to be used super fine frequency locking
%                'MeasFreq' is a record of all the frequency lock methods
%                1 - frequency estimate from looking at the symbol sync
%                waveform, using the combined symbol and frame sync time offset.
%                2 - frequency estimate from looking at the frame sync
%                waveform, using the frame sync time offset.
%                3 - is the frequency estimate from looking at the frame sync
%                waveform using the combined symbol and frame sync time offset.
%                DEFAULT = 3
%EnableSuperFineFreqLock  (1) Enable superfine lock, (0) Use Fine Freq locking instead
%                Enables Superfine frequency locking. This uses the frame
%                sync symbols from neighbouring frames to estimate the frequency 
%                accurately. This estimates the frequency to about 100 times the
%                accuracy of the fine lock. Unfortuately it only locks provided
%                the initial frequency accuracy is with in 1/N symbol in a frame
%                DEFAULT = 1;
%EnableTimeLockFlag Flag to enable perfect timing. 
%                (0) - Don't perform any time locking, time error is
%                set by MaxTimeOffset. EnableFreqLockFlag must be set to 0.
%                (1) - Use time sync from OFDM waveform. 
%                (2) - Perform time sync calculation from OFDM waveform. This allows
%                the frequency locking system to be enabled, but use perfect timing.
%TimeSyncLock    Sets the time locking method to use for final processing
%                'SyncTimeOffset' is a record of the performance of all the time
%                synchronisers. (Same method is used for both the frame and 
%                symbol detection
%                1-3 uses both the frame time sync signal and the symbol sync
%                to get a fine time lock
%                1 - Uses Peak detection
%                2 - Uses mid way between 90% of peak to 90% of peak
%                3 - Uses RMS centre of mass between 90% of peak to 90% of peak
%                4-6 uses just the frame time sync signal (effectively course lock)
%                4 - Uses Peak detection
%                5 - Uses mid way between 90% of peak to 90% of peak
%                6 - Uses RMS centre of mass between 90% of peak to 90% of peak

%Known Bugs
%29/7/2001 By Eric Lawrey
%Only works for even number of NumCarrs

if (NFrms+TailSig-NAvg)<NframesDisp
   disp(['NframesDisp (' num2str(NframesDisp) ') must be less than NFrms+TailSig-NAvg (',...
         num2str(NFrms+TailSig-NAvg) ')']);
   error('The simulation length is too short to display time sync waveform')
end

%Legacy compatibility. Set defaults for new variables added to the simulation
if ~exist('NAvg','var')
   NAvg = 1;
end
if ~exist('SymbAvg','var')
   SymbAvg = 0;
end

if ~exist('dellist','var')
   dellist = 1;
end
if ~exist('decay','var')
   decay = Inf;
end
if ~exist('TimeRandFlag','var')
   TimeRandFlag = 1;
end
if ~exist('MaxTimeOffset','var')
   MaxTimeOffset = SymbPerFrm;
end

if ~exist('TailSig','var')
   TailSig = 0;
end

if ~exist('ClipDistFlag','var');
   ClipDistFlag = 0;
end

if ~exist('OutBackoffdB','var');
   OutBackoffdB = 30;
end

if ~exist('RefPowBoost','var');
   RefPowBoost = 0;
end

if ~exist('FineFreqLock','var')
   FineFreqLock = 3;
end

if ~exist('TimeSyncLock','var')
   TimeSyncLock = 2;
end

if ~exist('EnableFreqLockFlag','var')
   EnableFreqLockFlag = 1;
end

if ~exist('EnableTimeLockFlag','var')
   EnableTimeLockFlag = 1;
end

if ~exist('EnableSuperFineFreqLock','var');
   EnableSuperFineFreqLock = 1;
end


TimeErr = zeros(Trials,3);			%Matrix of measured time error, 
%                                 column 1, peak search
%                                 column 2, mean of Threshold fraction of peak 
%                                           to Threshold fraction of peak
%                                 column 3, centre of mass between 90% to 90%
TimeErrS = zeros(Trials,3);		%Matrix of measured time error, Symbol Corr
%                                 column 1, peak search
%                                 column 2, mean of Threshold fraction of peak 
%                                           to Threshold fraction of peak
%                                 column 3, centre of mass between 90% to 90%
if length(Guard)>1
   GuardPeriod = Guard(1)+Guard(2)*2-Guard(3);
else
   GuardPeriod = Guard;
   
end

SyncSymb = 2;

TotSymbPerFrm = SymbPerFrm+SyncSymb;				%Total Number of symbols per frame
TotSymb = TotSymbPerFrm;								%Total Number of symbols simulated
SymbLength = IFFTsize+GuardPeriod;					%Number of Samples per symbol
FrmLength = (TotSymb)*(SymbLength); 				%Number of samples per Frame
DataSymbPerFrm = SymbPerFrm+1;						%Number of data symbols per frame
Nsamp = SymbLength*TotSymb*NFrms;

MeasFreq = zeros(Trials,3);			%Record of rough freq sync
SyncTimeOffset = zeros(Trials,6);	%Record of meas time offset used for sync
BlockFreqEst = zeros(1,Trials);		%Record of Super fine frequency lock
TimeOffset = zeros(1,Trials);			%Record of the actual time offset
CarrierSNR = zeros(NumCarr,Trials); %Record of the average Carrier SNR over each OFDM block
SymbolSNR = zeros(DataSymbPerFrm,Trials); %Record of the SNR of each symbol in a frame
%                                          this will show degradation in SNR with time
%                                          for frequency offsets
DelPow = zeros(Trials,Ntaps);
if GuardPeriod > IFFTsize/4
   disp('Long Guard Period: The timing algorithm can only utilise max time error of IFFT/4');
   warning('Thus a long guard period will not be used to its maximum potential');
end

if (EnableFreqLockFlag==1)&(EnableTimeLockFlag==0)
   disp('Frequency locking (EnableFreqLockFlag) from the waveform can''t')
   error('be enabled with timing disabled (EnableTimeLockFlag)')
end

%SampPerSymb = IFFTsize+GuardPeriod;
for m = 1:Trials
   
   %#########################################################################
   %#####################       TRANSMITTER        ##########################
   %#########################################################################
   ModMap=data2iqmap('QPSK');			%Generate IQ vector table
   DataCarriers = mkcarriers(NumCarr,IFFTsize,RealComplex);
   
   %==================================================================
   %  Generate Timing Symbol, which has duplicate 1st and 2nd half
   %==================================================================
   %NumCarr = [Number of Carriers, Spacing between carriers, Offset];
   EvenCarriers = mkcarriers([ceil(NumCarr/2),2,0],IFFTsize,RealComplex);
   NevenCarr = length(EvenCarriers);	%Number of even carriers, for duplicate symbol
   
   if PhaseType==-1
      EvenData = floor((rand(1,NevenCarr))*4);		%Generate random data 0 - 3, each word is 2 bits
      EvenIQ = sqrt(2)*ModMap(EvenData+1);			%Select the IQ vector for each data word
      % also boost the power by two since only every second subcarrier is used.
   else
      EvenIQ = sqrt(2)*genref(NevenCarr,PhaseType).';
   end
   EvenIQ = EvenIQ*(10.^(RefPowBoost/20));
   [DupSymbol, DupOverlap] = ofdmmod(EvenIQ,EvenCarriers, IFFTsize, Guard, RealComplex);
   
   %==========================
   %  Generate second symbol
   %==========================
   PNseq = floor(rand(1,NevenCarr)*4);
   Map = [1 i -1 -i];
   PNvect = Map(PNseq+1);
   
   %Differentially modulate the second symbol from the first, for the even carriers
   %if PhaseType == -1
   EvenIQ2 = EvenIQ.*PNvect/sqrt(2);
   %else
   %   EvenIQ2 = EvenIQ.*PNvect;
   %end
   
   AllCarriers =  mkcarriers(NumCarr,IFFTsize,RealComplex);
   %   OddCarriers = setxor(AllCarriers,EvenCarriers); %This reorders the carriers
   NumOddCarr = NumCarr-length(EvenCarriers);
   OddCarriers = mkcarriers([ceil(NumCarr/2),2,1],IFFTsize,RealComplex);
   NoddCarr = length(OddCarriers);
   
   OddData = floor((rand(1,NoddCarr))*4);		%Generate random data 0 - 3, each word is 2 bits
   OddIQ = ModMap(OddData+1);						%Select the IQ vector for each data word
   
   [Symbol2, SyncOverlap] = ofdmmod([EvenIQ2 OddIQ],[EvenCarriers OddCarriers], IFFTsize, Guard, RealComplex);
   if length(Guard)>1
      Overlap = Guard(3); 
   else 
      Overlap = 0;
   end
   
   IQs = zeros(NumCarr,1);
   IQs(1:2:NumCarr-1,1) = EvenIQ2.';
   IQs(2:2:NumCarr,1) = OddIQ.';
   %SyncOverlap = [SymbOverlap; zeros(size(Symbol2,1)-Overlap,1)];	%Make overlap symbol ready for adding to next symbol
   
   %Symbol2a = [Symbol2(1:Overlap)+DupOverlap; Symbol2(Overlap+1:end)];
   SyncSig = [DupSymbol Symbol2+DupOverlap];
   
   %========================================
   %  Insert Sync Symbols into Data Frames
   %========================================
   % Nsymb = SymbPerFrm*NFrms;		%Total number of data symbols
   
   %Generate random QAM data
   %   DataVect = (2*(rand(NumCarr,Nsymb)-0.5)+i*2*(rand(NumCarr,Nsymb)-0.5))/sqrt(2/3);
   
   %Calculate the timewaveform all the data symbols, in a vectored form
   %each column is one symbol
   %   DataSymbs = ofdmmod(DataVect, AllCarriers, IFFTsize, Guard, RealComplex);
   %Make Frames by inserting the synchronisation symbol in
   
   
   Output = zeros(SymbLength,TotSymb);
   DataOverlapPrev = zeros(SymbLength,1);	%This is for time overlapping for a Raised Cosine Guard Period
   IQ = zeros(NumCarr,SymbPerFrm+1,NFrms);
   for k = 1:NFrms
      %Generate random QAM data, no modulation data. (It is used to measure the effective SNR)
      DataVect = (2*(rand(NumCarr,SymbPerFrm)-0.5)+i*2*(rand(NumCarr,SymbPerFrm)-0.5))/sqrt(2/3);
      IQ(:,:,k) = [IQs DataVect];
      %Calculate the timewaveform all the data symbols, in a vectored form
      %each column is one symbol
      [DataSymbs, DataOverlap] = ofdmmod(DataVect, AllCarriers, IFFTsize, Guard, RealComplex);
      FrmStart = (k-1)*(TotSymbPerFrm)+1;
      DataInd = (k-1)*SymbPerFrm+1;
      Output(:,FrmStart) = SyncSig(:,1)+DataOverlapPrev;
      Output(:,FrmStart+1) = SyncSig(:,2);
      Output(:,FrmStart+2:(FrmStart+2+SymbPerFrm-1)) = DataSymbs; %(:,DataInd:(DataInd+SymbPerFrm-1));
      Output(:,FrmStart+2) = Output(:,FrmStart+2)+SyncOverlap;	%Add RC overlap
      DataOverlapPrev = DataOverlap;
   end
   Out2 = [Output(:); zeros(1,round(TailSig*FrmLength)).'];
   %#########################################################################
   %#####################       CHANNEL MODEL      ##########################
   %#########################################################################
   %===============================================
   %		Add clipping distortion to the signal
   %===============================================
   if ClipDistFlag    
      %disp('test')
      %max(abs(Out2))
      Out2 = clipdist(Out2,OutBackoffdB);
      %max(abs(Out2))
   end
   %===========================================
   %  Apply static multipath to the signal
   %===========================================
   if length(delspread) == 1
      if delspread > 0
         if strcmp(RealComplex,'complex')
            delpro = gensimpimp(Ntaps,delspread,'complex',dellist,decay);
         else
            delpro = gensimpimp(Ntaps,delspread,dellist,decay);
         end
         FilterFlag = 1;
         
      else
         FilterFlag = 0;
      end
      
   else
      if size(delspread,2)>1
         delpro = delspread(:,m).';
      else
         delpro = delspread.';
      end
      
     % disp('test')
     % plot(20*log10(abs(fft(delpro,512))))
     % pause
      FilterFlag = 1;
   end
   
   if FilterFlag
      DelPow(m,:) = 10*log10(cumsum(abs(delpro(end:-1:1)).^2));
      DelPow(m,:) = DelPow(m,end:-1:1);
      %figure(3)
      %plot(abs(delpro))
      %pause
      rmsds = rmsdelspread(delpro,1:length(delpro));	%Calc the delay spread of the impulse
      %      disp(['RMS delay spread : ' num2str(rmsds) ' samples'])
      Out2 = filter(delpro,1,Out2);      
   end
   %============================================================
   %		Add Time Offset to the signal (i.e. Time Sync Error)
   %============================================================
   if TimeRandFlag 
      TimeOffset(m) = rand*MaxTimeOffset;
   else
      TimeOffset(m) = MaxTimeOffset;
   end
   if TimeOffSymbScaleFlag
      TimeOff = round(TimeOffset(m)*(SymbLength));
   else
      TimeOff = TimeOffset(m);
   end
   
   if TimeOff < 0
      Out2 = [zeros(1,abs(TimeOff)) Out2.'].'; %(1:end-abs(TimeOff)).'].';
   end
   if TimeOff > 0
      Out2 = [Out2(TimeOff+1:end).' zeros(1,TimeOff)].';
   end
   %======================================
   %		Add AWGN to the signal
   %======================================
   %If the modulation is real, then the effective bandwidth of the 
   %OFDM spectrum is 2*the number of carriers.
   %This is done to calculate the correct amount of noise to add
   if strcmp(RealComplex,'real')
      BWscale = 2*NumCarr/IFFTsize;
   else
      BWscale = NumCarr/IFFTsize;
   end
   [Out2, noise] = addnoise(Out2,SNRdB,BWscale);
   %===========================================
   %  Apply a frequency offset to the signal
   %===========================================
   Out2 = freqoff(Out2,freqoffset);
   %#########################################################################
   %#####################       RECEIVER           ##########################
   %#########################################################################
   %=========================================
   %  Time Synchronise with the signal
   %=========================================
   %Frame Synchronisation
   if (EnableTimeLockFlag==1)|(EnableTimeLockFlag==2)
      [T1,T2,T3,o] = tcorr(Out2,IFFTsize/2,IFFTsize/2,0,NAvg,FrmLength-IFFTsize/2);
      if SymbAvg > 0
         %Symbol Synchronisation
         [T1a,T2a,T3a,o2] = tcorr(Out2,IFFTsize,GuardPeriod,0,SymbAvg,IFFTsize);
      end
      T = [T1,T2,T3];
      Ta = [T1a, T2a, T3a];
      
      %=======================================
      % Calc Time offset based on Frame Sync
      %=======================================
      Err = (FrmLength - TimeOff-T+GuardPeriod/2);
      %Bound the timing error to +- half a frame
      ind = find(Err< -FrmLength/2);
      Err(ind) = Err(ind)+FrmLength;
      ind = find(Err> FrmLength/2);
      Err(ind) = Err(ind)-FrmLength;
      TimeErr(m,:) = Err;
      
      %================================================================
      % Calc Time offset based on combined Frame Sync and Symbol Sync
      %================================================================
      SymbOffset = rem(Ta,SymbLength);
      SymbFrmOffset = (floor(T./SymbLength))+SymbOffset/SymbLength;
      ind = find((SymbFrmOffset-(T./SymbLength))>0.5);
      SymbFrmOffset(ind) = SymbFrmOffset(ind)-1;
      ind = find((SymbFrmOffset-(T./SymbLength))<-0.5);
      SymbFrmOffset(ind) = SymbFrmOffset(ind)+1;
      SymbFrmOffset2 = SymbFrmOffset*SymbLength;
      
      ErrS = (FrmLength - TimeOff-SymbFrmOffset2); %+GuardPeriod/2);
      %Bound the timing error to +- half a frame
      ind = find(ErrS< -FrmLength/2);
      ErrS(ind) = ErrS(ind)+FrmLength;
      ind = find(ErrS> FrmLength/2);
      ErrS(ind) = ErrS(ind)-FrmLength;
      TimeErrS(m,:) = ErrS;
      %Choose a time offset for time synchronisation, make minimum time = 1
      SyncTimeOffset(m,:) = max(round([SymbFrmOffset2 T] -min(IFFTsize/8,GuardPeriod/2)),1);
      if (EnableTimeLockFlag==2)
         SyncTimeOffset(m,:) = [TimeOff TimeOff TimeOff TimeOff TimeOff TimeOff]+1;
      end
      
   end
   if EnableFreqLockFlag
      PhConst = 2*(IFFTsize+GuardPeriod)/IFFTsize;
      %Column 1 is the frequency estimate from looking at the symbol sync
      %waveform, using the combined symbol and frame sync time offset.
      %Column 2 is the frequency estimate from looking at the frame sync
      %waveform, using the frame sync time offset.
      %Column 3 is the frequency estimate from looking at the frame sync
      %waveform using the combined symbol and frame sync time offset.
      MeasFreq(m,1) = angle(o2(round(SymbFrmOffset2(TimeSyncLock))))/(-2*pi);
      MeasFreq(m,2) = angle(o(round(T(2))))/-pi;
      MeasFreq(m,3) = angle(o(round(SymbFrmOffset2(TimeSyncLock))))/-pi;
      
      %===========================================================
      %   Frequency Correct the signal before OFDM demodulation
      %===========================================================
      % Perform Rough Frequency Synchronisation. This is needed to
      % prevent phase wrapping of the fine frequency locking.
      RxSig1 = freqoff(Out2,-MeasFreq(m,FineFreqLock)/IFFTsize);
      
      if EnableSuperFineFreqLock 
         %===========================================
         %  Calculate Super fine frequency locking
         %===========================================
         %Super fine frequency locking is achieved by measuring the phase rotation
         %from one frame sync to the next frame sync. This calculation is done
         %in the time domain to prevent the need for performing FFTs. This could
         %have been done by looking at the phase differents in the frequency domain.
         
         %Use moving average correlator time synchroniser to pick out the matching
         %frame to frame syncs. This in theory could be optimised. In stead of applying
         %a moving average, then picking the phase from the frame sync, we could have
         %just calculated the mean correlation at the correct time. We can do this as
         %we already know the time synchronisation. But since the moving average is 
         %efficient (two operations per sample) its overhead is not that large.
         %Only perform averaging over one frame difference. This is so that the system
         %can potentially track frequency changes. This simulation does however not
         %do this. It just uses the average frequency measured from all frames
         %simulated.
         %
         % This algorithm breaks down when the fine frequency error is greater than
         % 1/(2*(IFFTsize+GuardPeriod)/IFFTsize*N), where N is the number of symbols between frames. For example
         % for N = 10; and GuardPeriod = 1/4*IFFTsize, the maximum error allowed is 1/25 = 0.04 = 4%
         % Above this the superfine locking wraps causing errors.
         
         ov = tmsyncds(RxSig1,FrmLength,IFFTsize+GuardPeriod,0,1,0); %IFFTsize+GuardPeriod+64
         
         %Calculate the starting time of each frame, based on the TimeOffset
         FrameTimes = SyncTimeOffset(m,TimeSyncLock)+(0:NFrms-1)*FrmLength+SymbLength/2;
         %Get the angle at the sync times from ov, and calculate the freq error from each
         %   angle(ov(FrameTimes))
         %(-2.5*TotSymbPerFrm*pi)
         %MeasFreq(2)
         if max(FrameTimes) > length(ov)
            disp('Frame Time exceeds sample set, probably due to no lock on first frame')
         end
         
         %      warning('Try increasing 
         
         FreqEst = MeasFreq(m,FineFreqLock)+angle(ov(min(FrameTimes,length(ov))))/(-PhConst*TotSymbPerFrm*pi);
         
         %Average all the results. Estimate the absolute frequency offset
         %in units of carrier spacings
         
         BlockFreqEst(m) = mean(FreqEst(1:end-1));
         if abs(MeasFreq(m,FineFreqLock)-freqoffset*IFFTsize)>(1/(PhConst*TotSymbPerFrm))
            disp('Frequency Error exceeded for Superfine lock, will have wrapping errors')
            
         end
         
         %Apply the super fine frequency locking before OFDM demod.
         RxSig1 = freqoff(Out2,-BlockFreqEst(m)/IFFTsize);
      else
         BlockFreqEst(m) = MeasFreq(m,FineFreqLock);
      end
      
      
      if (Nsamp+SyncTimeOffset(m,TimeSyncLock)-1)>length(RxSig1)
         disp('Number of samples too small, can''t get required samples for OFDM block with')
         error('calculated time offset. Try making TailSig larger')
      end
   else
      RxSig1= Out2;
   end
   
   
   if (EnableTimeLockFlag==1)|(EnableTimeLockFlag==2)   
      
      outsig = RxSig1(SyncTimeOffset(m,TimeSyncLock):Nsamp+SyncTimeOffset(m,TimeSyncLock)-1);	%This will give Nfrms-1 frames of data
   else
      outsig = Out2(1:Nsamp);
   end
   
   
   %Change the time domain data into matrix form, one symbol per column.
   outsig = reshape(outsig,(SymbLength),length(outsig)/(SymbLength));        
   %==========================================               
   %		Demodulate the OFDM signal
   %==========================================
   %Strip off the guardperiod
   %This will be the lower rows of the matrix. Each column is a symbol
   %This simulation assumes perfect time synchronization
   outsig = outsig(GuardPeriod+(1:IFFTsize),:);
   %Apply the FFT
   fftdata = fft(outsig);
   %Now keep the carriers which were used
   
   carrierSNRlin = zeros(NumCarr,NFrms);
   TimeSNR = zeros(DataSymbPerFrm,NFrms);
   IQrefL = zeros(length(EvenCarriers),NFrms);
   for nf = 1:NFrms
      FrmOff = (nf-1)*(TotSymbPerFrm)+1;
      IQref = fftdata(EvenCarriers,FrmOff);
      IQrx = fftdata(AllCarriers,FrmOff+1:FrmOff+DataSymbPerFrm);          
      IQrefL(:,nf) = IQref;
      %=========================================
      %	Perform channel characterisation
      %=========================================
      %From the pilot symbols at the start of the transmission
      %if NumRefSymb > 1
      %   ChannResp = (mean(IQrx(:,1:NumRefSymb)')')./(mean(IQ2(:,1:NumRefSymb)')');
      %else(IQref.')./EvenIQ
      ChannResp = (IQref.')./EvenIQ;
      
      %Need to interpolate the channel response as only every second carrier
      %has been characterised
      
      %Simple Linear interpolation
      %This doesn't work because the frequency characterisation is done on every
      %second carrier
      %ChannResp2 = zeros(1,NumCarr);
      %ChannResp2(1:2:NumCarr-1) = ChannResp;
      %ChannResp2(2:2:NumCarr) = [(ChannResp(2:end)+ChannResp(1:end-1))/2 ChannResp(end)];
      
      
      %==================================================
      %   Interpolate to get Channel Response
      %==================================================
      % Because the characterisation is done only every second carrier
      % interpolation is needed for the other carriers. However time
      % offsets, such as positioning the start half way through the
      % guard period, result in a phase rotation of the carriers. This
      % wouldn't normally cause any problems, but since we don't know
      % the phase offset for the unknown carriers it is a problem.
      % The phase difference between neighbouring carriers due to a time
      % offset is ph = (2*pi*t/IFFT)*N, where t is the time offset in samples
      % IFFT size is the size of the IFFT used to generate the OFDM signal
      % and N is the gap between the carriers, in this case N = 2;
      %
      % This phase trend effectively adds a high frequency component phase verse
      % carrier frequency making interpolation difficult. If the time offset 
      % is IFFT/4 this corresponds to a nyquist tone.
      %
      % As well as this, in a multipath environment, the channel response is
      % added to the time offset signal.
      %
      % To get around this problem, remove the time offset from the characterisation
      % by detrending the phase of the response. Perform the channel interpolation
      % then add the trend back in again. However if the time offset if >= IFFT/4
      % phase changes by >= pi per carrier reference, causing problems
      %
      % This algorithm fails if the time offset is more than IFFT/4-1 in samples,
      % regardless of the length of the guard period.
      
      %Detrend the phase data to compensate for time offset
      x = 1:2:NumCarr-1;
      P = polyfit(x,unwrap(angle(ChannResp)),1);
      CTrend = polyval(P,x);
      
      Ang = angle(ChannResp)-CTrend;
      Mag = abs(ChannResp);
      [Xc, Yc] = pol2cart(Ang,Mag);
      Cdetrend = Xc+i*Yc;
      %Use Cubic Interpolation
      ChannResp2a = interp1(x,Cdetrend,1:NumCarr,'cubic');
      ChannResp2a(NumCarr) = ChannResp2a(NumCarr-1);
      %Now add phase trend back again
      Ang2 = angle(ChannResp2a)+polyval(P,1:NumCarr);
      [Xc2,Yc2] = pol2cart(Ang2,abs(ChannResp2a));
      ChannResp2= [Xc2+i*Yc2];
      
      IQrx2 = IQrx./repmat(ChannResp2.',1,size(IQrx,2));
      IQerr = (IQrx2-IQ(:,:,nf));
      carrierSNRlin(:,nf) = (mean((abs(IQ(:,:,nf)).^2).')./mean((abs(IQerr).^2).')).';
      TimeSNR(:,nf) = (mean((abs(IQ(:,:,nf)).^2))./mean((abs(IQerr).^2))).';
   end
   CarrierSNR(:,m) = 10*log10(mean(carrierSNRlin.')).';
   SymbolSNR(:,m) = 10*log10(mean(TimeSNR.')).';
   if rem(m,5)==0
      disp([num2str(m) ' of ' num2str(Trials)])
      drawnow
   end
   
end