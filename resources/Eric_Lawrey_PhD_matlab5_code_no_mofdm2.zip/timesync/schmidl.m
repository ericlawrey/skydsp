%Simulate 
%Timothy M. Schmidl and Donald C. Cox, "Robust Frequency and Timing Synchronization for OFDM",
%IEEE Transactions on Communications, Vol. 45, No. 12, December 1997

%Construct the synchronisation block of two symbols. First symbol only uses every
%even carrier, resulting in duplicate 1st and 2nd half of the symbol. Second symbol
%also transmits of the odd carriers with a separate PN sequence.

%This script is called by other scripts containing the constant setups. I did this
%so that I could setup multiple simulations easily

%TimeRandFlag -  (1) used random time offset, upto a maximum of MaxTimeOffset
%                (0) just use the value in MaxTimeOffset. Default = 1
%MaxTimeOffset - Sets the amount of time offset. If TimeRandFlag is set than
%                the time offset will be random up to a maximum of TimeOffset.
%                If not set the time offset will correspond to the value set
%                by MaxTimeOffset. The units of MaxTimeOffset are in symbols
%                Default = SymbPerFrm.

%Legacy compatibility. Set defaults for new variables added to the simulation
if ~exist('NAvg','var')
   NAvg = 1;
end
if ~exist('SymbAvg','var')
   SymbAvg = 0;
end

if ~exist('dellist','var')
   dellist = 1;
end
if ~exist('decay','var')
   decay = Inf;
end
if ~exist('TimeRandFlag','var')
   TimeRandFlag = 1;
end
if ~exist('MaxTimeOffset','var')
   MaxTimeOffset = SymbPerFrm;
end


TimeErr = zeros(Trials,3);			%Matrix of measured time error, 
%                                 column 1, peak search
%                                 column 2, mean of Threshold fraction of peak 
%                                           to Threshold fraction of peak
%                                 column 3, centre of mass between 90% to 90%
TimeErrS = zeros(Trials,3);		%Matrix of measured time error, Symbol Corr
%                                 column 1, peak search
%                                 column 2, mean of Threshold fraction of peak 
%                                           to Threshold fraction of peak
%                                 column 3, centre of mass between 90% to 90%
MeasFreq = zeros(Trials,2);
GuardPeriod = Guard(1)+Guard(2)*2-Guard(3);
for m = 1:Trials
   if TimeRandFlag 
      TimeOffset = rand*MaxTimeOffset;
   else
      TimeOffset = MaxTimeOffset;
   end
   
   
   
   
   ModMap=data2iqmap('QPSK');			%Generate IQ vector table
   DataCarriers = mkcarriers(NumCarr,IFFTsize,RealComplex);
   
   %==================================================================
   %  Generate Timing Symbol, which has duplicate 1st and 2nd half
   %==================================================================
   %NumCarr = [Number of Carriers, Spacing between carriers, Offset];
   EvenCarriers = mkcarriers([ceil(NumCarr/2),2,0],IFFTsize,RealComplex);
   NevenCarr = length(EvenCarriers);	%Number of even carriers, for duplicate symbol
   
   if PhaseType==-1
      EvenData = floor((rand(1,NevenCarr))*4);		%Generate random data 0 - 3, each word is 2 bits
      EvenIQ = sqrt(2)*ModMap(EvenData+1);			%Select the IQ vector for each data word
      % also boost the power by two since only every second subcarrier is used.
   else
      EvenIQ = sqrt(2)*genref(NevenCarr,PhaseType).';
   end
   
   [DupSymbol, DupOverlap] = ofdmmod(EvenIQ,EvenCarriers, IFFTsize, Guard, RealComplex);
   
   %==========================
   %  Generate second symbol
   %==========================
   PNseq = floor(rand(1,NevenCarr)*4);
   Map = [1 i -1 -i];
   PNvect = Map(PNseq+1);
   
   %Differentially modulate the second symbol from the first, for the even carriers
   %if PhaseType == -1
   EvenIQ2 = EvenIQ.*PNvect/sqrt(2);
   %else
   %   EvenIQ2 = EvenIQ.*PNvect;
   %end
   
   AllCarriers =  mkcarriers(NumCarr,IFFTsize,RealComplex);
   OddCarriers = setxor(AllCarriers,EvenCarriers);
   NoddCarr = length(OddCarriers);
   
   OddData = floor((rand(1,NoddCarr))*4);		%Generate random data 0 - 3, each word is 2 bits
   OddIQ = ModMap(OddData+1);						%Select the IQ vector for each data word
   
   [Symbol2, SyncOverlap] = ofdmmod([EvenIQ2 OddIQ],[EvenCarriers OddCarriers], IFFTsize, Guard, RealComplex);
   Overlap = Guard(3); 
   %SyncOverlap = [SymbOverlap; zeros(size(Symbol2,1)-Overlap,1)];	%Make overlap symbol ready for adding to next symbol
   
   %Symbol2a = [Symbol2(1:Overlap)+DupOverlap; Symbol2(Overlap+1:end)];
   SyncSig = [DupSymbol Symbol2+DupOverlap];
   
   %========================================
   %  Insert Sync Symbols into Data Frames
   %========================================
        % Nsymb = SymbPerFrm*NFrms;		%Total number of data symbols
      
      %Generate random QAM data
   %   DataVect = (2*(rand(NumCarr,Nsymb)-0.5)+i*2*(rand(NumCarr,Nsymb)-0.5))/sqrt(2/3);
      
      %Calculate the timewaveform all the data symbols, in a vectored form
      %each column is one symbol
   %   DataSymbs = ofdmmod(DataVect, AllCarriers, IFFTsize, Guard, RealComplex);
   %Make Frames by inserting the synchronisation symbol in
   TotSymb = NFrms*(SymbPerFrm+2);	%Total Number of symbols
   SampPerSymb = IFFTsize+GuardPeriod;
   Output = zeros(SampPerSymb,TotSymb);
   DataOverlapPrev = zeros(SampPerSymb,1);
   for k = 1:NFrms
      
     % Nsymb = SymbPerFrm*NFrms;		%Total number of data symbols
      
      %Generate random QAM data
      DataVect = (2*(rand(NumCarr,SymbPerFrm)-0.5)+i*2*(rand(NumCarr,SymbPerFrm)-0.5))/sqrt(2/3);
      
      %Calculate the timewaveform all the data symbols, in a vectored form
      %each column is one symbol
      [DataSymbs, DataOverlap] = ofdmmod(DataVect, AllCarriers, IFFTsize, Guard, RealComplex);
      FrmStart = (k-1)*(SymbPerFrm+2)+1;
      DataInd = (k-1)*SymbPerFrm+1;
      Output(:,FrmStart) = SyncSig(:,1)+DataOverlapPrev;
      Output(:,FrmStart+1) = SyncSig(:,2);
      Output(:,FrmStart+2:(FrmStart+2+SymbPerFrm-1)) = DataSymbs; %(:,DataInd:(DataInd+SymbPerFrm-1));
      Output(:,FrmStart+2) = Output(:,FrmStart+2)+SyncOverlap;	%Add RC overlap
      DataOverlapPrev = DataOverlap;
   end
   Out2 = Output(:);
   
   %===========================================
   %  Apply static multipath to the signal
   %===========================================
   if delspread > 0
      if strcmp(RealComplex,'complex')
         delpro = gensimpimp(Ntaps,delspread,'complex',dellist,decay);
      else
         delpro = gensimpimp(Ntaps,delspread,dellist,decay);
      end
      figure(3)
      plot(abs(delpro))
      %pause
      rmsds = rmsdelspread(delpro,1:length(delpro));	%Calc the delay spread of the impulse
      %      disp(['RMS delay spread : ' num2str(rmsds) ' samples'])
      Out2 = filter(delpro,1,Out2);
   end
   %======================================
   %		Add AWGN to the signal
   %======================================
   %If the modulation is real, then the effective bandwidth of the 
   %OFDM spectrum is 2*the number of carriers.
   %This is done to calculate the correct amount of noise to add
   if strcmp(RealComplex,'real')
      BWscale = 2*NumCarr/IFFTsize;
   else
      BWscale = NumCarr/IFFTsize;
   end
   [Out2, noise] = addnoise(Out2,SNRdB,BWscale);
   
   %===========================================
   %  Apply a frequency offset to the signal
   %===========================================
   Out2 = freqoff(Out2,freqoffset);
   
   %============================================================
   %		Add Time Offset to the signal (i.e. Time Sync Error)
   %============================================================
   if TimeOffSymbScaleFlag
      TimeOff = round(TimeOffset*(IFFTsize+GuardPeriod));
   else
      TimeOff = TimeOffset;
   end
   
   if TimeOffset < 0
      Out2 = [zeros(1,abs(TimeOff)) Out2(1:end-abs(TimeOff)).'].';
   end
   if TimeOffset > 0
      Out2 = [Out2(TimeOff+1:end).' zeros(1,TimeOff)].';
   end
   %===============================
   % Trim the number of samples
   %===============================
   %Out2 = Out2(1:FrmCrop*(SymbPerFrm+2)*(IFFTsize+GuardPeriod));
   %=========================================
   %  Time Synchronise with the signal
   %=========================================
   FrmLength = (SymbPerFrm+2)*(IFFTsize+GuardPeriod);
   [T1,T2,T3,o] = tcorr(Out2,IFFTsize/2,IFFTsize/2,0,NAvg,FrmLength-IFFTsize/2);
   
   %o = tmsyncds(Out2,IFFTsize/2,IFFTsize/2,0,NAvg,FrmLength-IFFTsize/2);
   if SymbAvg > 0
      [T1a,T2a,T3a,o2] = tcorr(Out2,IFFTsize,GuardPeriod,0,SymbAvg,IFFTsize);
      %os = tmsyncds(Out2,IFFTsize,GuardPeriod,0,SymbAvg,IFFTsize);
      %plot(abs(os))
      %pause
      %===============================
      % Trim the number of samples
      %===============================
      %o2 = o2(1:FrmCrop*(IFFTsize+GuardPeriod));
   end
   
   SymbLength = IFFTsize+GuardPeriod;
   T = [T1,T2,T3];
   Ta = [T1a, T2a, T3a];
   SymbOffset = rem(Ta,SymbLength);
   %ind = find(SymbOffset< -SymbLength/2);
   %SymbOffset(ind) = SymbOffset(ind)+SymbLength;
   %ind = find(SymbOffset> SymbLength/2);
   %SymbOffset(ind) = SymbOffset(ind)-SymbLength;
   %   *SymbLength
   %=======================================
   % Calc Time offset based on Frame Sync
   %=======================================
   Err = (FrmLength - TimeOff-T+GuardPeriod/2);
   %Bound the timing error to +- half a frame
   ind = find(Err< -FrmLength/2);
   Err(ind) = Err(ind)+FrmLength;
   ind = find(Err> FrmLength/2);
   Err(ind) = Err(ind)-FrmLength;
   TimeErr(m,:) = Err;
   
   %================================================================
   % Calc Time offset based on combined Frame Sync and Symbol Sync
   %================================================================
   SymbFrmOffset = (floor(T./SymbLength))+SymbOffset/SymbLength;
   ind = find((SymbFrmOffset-(T./SymbLength))>0.5);
   SymbFrmOffset(ind) = SymbFrmOffset(ind)-1;
   ind = find((SymbFrmOffset-(T./SymbLength))<-0.5);
   SymbFrmOffset(ind) = SymbFrmOffset(ind)+1;
   SymbFrmOffset2 = SymbFrmOffset*SymbLength;
   
   ErrS = (FrmLength - TimeOff-SymbFrmOffset2); %+GuardPeriod/2);
   %Bound the timing error to +- half a frame
   ind = find(ErrS< -FrmLength/2);
   ErrS(ind) = ErrS(ind)+FrmLength;
   ind = find(ErrS> FrmLength/2);
   ErrS(ind) = ErrS(ind)-FrmLength;
   TimeErrS(m,:) = ErrS;
   
   MeasFreq(m,1) = angle(o2(round(SymbFrmOffset2(2))))/(-2*pi);
   MeasFreq(m,2) = angle(o(round(T(2))))/-pi;
   %if max(abs(ErrS)) > 50
   %   pause
   %end
   %if max(abs(Err)) > 100
   %   pause
   %end
   
   if rem(m,50)==0
      disp([num2str(m) ' of ' num2str(Trials)])
      drawnow
   end
   
end