function [T1,T2,T3,o3] = tcorr(x,N,M,SyncType,P,S);
%TCORR Perform OFDM time synchronisation using correlation
%[T1,T2,T3] = tcorr(x,N,M,SyncType,P,S)
% T1 - Time synchronisation found using peak detection
% T2 - Time Synchronisation found from mid point between 90% of 
% peak before peak to 90% of peak after peak.
% T3 - Use power weighted first moment from 90% to 90% of peak
%
% [T1,T2,T3,o] = tcorr(x,N,M,SyncType,P,S)
% o - Moving average of the time correlator. 
% TCORR only looks for the sync signal within the first 1.5 sync
% pulse spacings (S+N)*1.5
% TCORR will lock to the first sync signal in the signal x, if there
% are two sync pulses within the time window
% tcorr('help') displays a graphic showing the details of the
% synchroniser
if isstr(x)
   H = findobj('tag','diagram');
   if isempty(H)
      [A,M] = imread('tsync.tif');
      figure
      image(A);
      colormap(M);
      axis off
      set(gca,'units','n','position',[0 0 1 1]);
      set(gcf,'units','pixels','position',[30 50 size(A,2) size(A,1)],'menubar',...
         'none','tag','diagram','name','Diagram of Time Sync Algorithm');
      figure(gcf)
   else
      figure(H)
   end
else
   
   o2 = tmsyncds(x,N,M,SyncType,P,S);
   %===============================
   % Trim the number of samples
   %===============================
   o = o2(1:round((S+N)*1.5)); 
   SearchRange = M; 
   Threshold = 0.9;
   FirstSyncThresh = 0.80;	%If a sync is detected on the far right of a sample set, there is
   %                        a chance that there is another sync signal earlier in the sample set
   %                        so test the region where this sync signal should be, an use it if
   %                        its amplitude is with FirstSyncThresh*Peak of right sync.
   
   %FrmLength = (SymbPerFrm+2)*(IFFTsize+GuardPeriod)
   %SyncLength = IFFTsize/2;	%Moving average length used for detection
   %SyncGap = IFFTsize/2;		%Time different used to correlate
   
   %[StartTime, Times]= multisync(x,FrmLength,SyncFrms,SyncGap,...
   %   SyncLength,Nsegments,TimeTolScale,SyncType,SyncFrms,FrmSyncLength)
   
   %  plot(abs(o))
   %  pause
   %   Frmlength = (SymbPerFrm+2)*(IFFTsize+GuardPeriod);
   
   [Y,I] = max(abs(o));
   %If the time offset is such that there are two sync pulses in the window,
   %and the strongest is too close to the edge of the window, than the
   %weaker sync must be used. If the peak is too close to the boundary
   %than set sampe around the boundary to zero and try again
   %I
   %pause
   
   %We need a method for locking to the first synch pulse. Because the view
   %window !!!!!!!!
   %Sync Pulse width = 2*M
   %Spacing between sync centres is M+S
   %If the sync pulse is on the far right of the sample set, search the lower half
   %for another sync pulse.
   if I > 3*M+S
      [Yt,It] = max(abs(o(I-(M+S)-M:I-(M+S)+M)));
      %If the peak amplitude is with FirstSyncThresh of the right peak than use the
      %peak just found
      if Yt>= Y*FirstSyncThresh
         I = It+I-(M+S)-M-1;	%Adjust that index to compensate for the limited search region
         Y = Yt;
      end
   end
   
   if I<=SearchRange
      o  = [zeros(1,SearchRange)'; o(SearchRange-1:end)];
      [Y,I] = max(abs(o));
   end
   
   if I>=(length(o)-SearchRange)
      o  = [o(1:end-SearchRange+1); zeros(1,SearchRange)' ];
      [Y,I] = max(abs(o));
   end
   
   %Recheck the lower end as removing the upper spike may make it lock
   %to one that is close to the lower ends of the sample set. This tends
   %to occur mainly at very low SNRs
   if I<=SearchRange
      o  = [zeros(1,SearchRange)'; o(SearchRange-1:end)];
      [Y,I] = max(abs(o));
   end
   
   Im1 = min(find(abs(o(I-SearchRange:I))>=(Y*Threshold)));
   if isempty(Im1)
      Im1 = 1;
   end
   
   I1 =Im1+I-SearchRange-1;
   Im2 = min(find(abs(o(I:I+SearchRange))<=(Y*Threshold)));
   if isempty(Im2)
      Im2 = SearchRange;
   end
   T1 = I;
   I2 =Im2+I-1;
   T2 = (I1+I2)/2;
   T = I1:I2;
   Pt = sum(abs(o(T).').^2);			%Total Power
   T3 = sum(((abs(o(T).').^2)/Pt).*T);	%Calculate the the power weighted first moment
   if nargout > 3
      o3 = o2;
   end
   
end