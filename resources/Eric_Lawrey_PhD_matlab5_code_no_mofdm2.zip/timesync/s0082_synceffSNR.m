clear all
%======================================
%   List of plot types to be shown
%======================================
TimeSyncPlot = 1;		%Plot the time synchronisation waveforms
SpecGramFlag = 0;		%Plot spectrograph of simulated block of OFDM frames
%                     if NTrials > 1 it shows only the last simulated block
CarrierSNRFlag = 1;	%SNR of each carrier, averaged over all trials
SymbolSNRFlag = 1;	%SNR of each symbol over the OFDM block
FreqLockSNRFlag = 1; %  Frequency Locking Accuracy verses SNR
ChanCharFlag = 1;			%Channel Characterisation plot, comparing true and measured
SuperFinePhFlag = 1;	%Angle of the frame to frame correlation used for super fine frequency locking
Trials = 1;


IFFTsize = 128;                  %Size of IFFT to use, (complex waveform so IFFTsize>N)
NumCarr = 80; %round(IFFTsize*0.8);                   %Number of data OFDM subcarriers
%GuardPeriod = 0;						%Guard Period in Samples
%GuardPeriod = [constant guard period, raised cosine envelope, overlap];
Guard = [32, 0, 0];

RealComplex = 'complex';         %Generate complex OFDM signals
SymbPerFrm = 8;						%Number of data symbols per frame (not including sync)
NFrms = 10;								%Number of frames to simulate (needs to be at least 2 more
%                                 than Navg, as we need two good sync pulses to cope with
%                                 any time offset
NAvg = 4;								%Number of frames to average over for frame synchronisation
SymbAvg = 40; %NAvg*(SymbPerFrm+2); 	%Symbol synchronisation using correlation of the
%                                 Guard period. Number of symbols to average over.
%                                 The number here corresponds to the number of symbols
%                                 used in the frame synchronisation
TailSig = 1.5;							%Number of Frames of zero signal added to the end
EnableTimeLockFlag = 1;				%Flag to enable perfect timing. 
%                                 (0) - Don't perform any time locking, time error is
%                                 set by MaxTimeOffset
%                                 (1) - Use time sync from OFDM waveform. 
%                                 (2) - Perform time sync calculation from OFDM waveform. This allows
%                                 the frequency locking system to be enabled, but use perfect timing.
TimeRandFlag = 0;						%Flag to set whether the time offset is random (1) or not (0)
%                                 For (1) random time offset = rand*MaxTimeOffset
%                                 For (0) time offset = MaxTimeOffset
MaxTimeOffset = -4;					%Time offset in symbols (should be negative) to add zeros to start
%											If EnableTimeLockFlag = 1 than an offset is required for
%                                successful locking to the first frame.
TimeSyncLock = 2;					   % Sets the time locking method to use for final processing
%                                 'SyncTimeOffset' is a record of the performance of all the time
%                                 synchronisers
%                                 1-3 uses both the frame time sync signal and the symbol sync
%                                 to get a fine time lock. (Same method is used for both the
%                                 frame and symbol detection
%                                 1 - Uses Peak detection
%                                 2 - Uses mid way between 90% of peak to 90% of peak
%                                 3 - Uses RMS centre of mass between 90% of peak to 90% of peak
%                                 4-6 uses just the frame time sync signal (effectively course lock)
%                                 4 - Uses Peak detection
%                                 5 - Uses mid way between 90% of peak to 90% of peak
%                                 6 - Uses RMS centre of mass between 90% of peak to 90% of peak

NframesDisp =0.5;						%Number of frames to display must be less than Nfrms-NAvg

%FrmCrop = 1.5;						%Number of frames to crop to, allows trimming of the end of
%                                waveform after time offset has been applied
freqoffset = -0.13/IFFTsize;			%Frequency offset as fraction of sample rate
EnableFreqLockFlag = 1;				%Flag to enable or disable the frequency locking system
%                                 (1) - Use the frequency lock system.
%                                 (0) - Don't Do any frequency locking. The frequency error
%                                 will correspond to freqoffset
EnableSuperFineFreqLock=1;  			%(1) Enable superfine lock, (0) Use Fine Freq locking instead
%                                Enables Superfine frequency locking. This uses the frame
%                                sync symbols from neighbouring frames to estimate the frequency 
%                                accurately. This estimates the frequency to about 100 times the
%                                accuracy of the fine lock. Unfortuately it only locks provided
%                                the initial frequency accuracy is with in 1/N symbol in a frame
FineFreqLock  = 1;				   %1 - frequency estimate from looking at the symbol sync
%                                waveform, using the combined symbol and frame sync time offset.
%                                This is the best technique
%                                2 - frequency estimate from looking at the frame sync
%                                waveform, using the frame sync time offset.
%                                3 - is the frequency estimate from looking at the frame sync
%                                waveform using the combined symbol and frame sync time offset.


%SNRdB = 20;								%Signal to Noise Ration of channel (dB)

ClipDistFlag = 0;						%Flag to turn on clipping distortion
OutBackoffdB = 5;						%Clipping amount. Output of transmitter is clipped until
%		                           the crest factor of the signal matches OutBackoffdB. No 
%                                effect if ClipDistFlag = 0

Ntaps	 = 64;							%Number of filter taps for Static Multipath (samples)
dellist = [1];	%List of impulse responses (delay in samples)
decay = 500;		%Decay of overall impulse (see gensimpimp for description)
for k = 1:Trials
   delspread(:,k) = gensimpimp(Ntaps,8,'complex',dellist,decay).';
end

delspread = 0;							%Decay time constant for stativ multipath (samples)
%                                 To disable multipath set delspread to 0.
PhaseType = 1;	                  %Phase scheme used for the time synchronisation symbol
% Schmidl recommends using a PN sequence using QPSK modulation, however the phase
% scheme can be changed by setting PhaseType to the appropriate value.
% See GENREF for more detail
% -1  PN sequence from QPSK
% 0 - SN TN scheme
% 1 - GA optimised
% 2 - Random
% 3 - Spectral Flatness optimised
% 4 - Newmanns
% 5 - Shapiro-Rudin
RefPowBoost = 2;						%Amount of power boosting to apply to the synchronisation (dB)
%											symbol. If a low CF phasing scheme is used than the reference
%                                can be boosted by 3dB (RefPowBoost=2) while still maintaining 
%                                a peak power lower than most data symbols.


TimeOffSymbScaleFlag=1;				%Determines the units of TimeOffset
%                                 1 = TimeOffset in units of symbols
%                                 0 = TimeOffset in units of samples

%Threshold = 0.90;						%Take the timing from Threshold*Peak Value
%SearchRange  = 2*GuardPeriod;		%Number of samples to search above and
%                                 below the peak location to find the Threshold
%                                 boundaries
SNRdBList = [5:5:60];
%ErrBound = [0.9 0.99];				%Find the timing range for 90% of timing syncs, and 99%


%List of variables to set in each simulation
%LoopVariables = {}; %{'EnableSuperFineFreqLock','SymbPerFrm'};
LoopVariables = {'Guard','IFFTsize','NumCarr'};
%Value of each variable for each simulation
%LoopValues = {}; %{[0,0,1,1],[9 49,9,49]};
%LoopValues = {[4 8 16 32 64 64],[128 128 128 128 128 512], [100 100 100 100 100 400]};
LoopValues = {[64],[512], [400]};

if length(LoopValues)>=1
   Nvalues = length(LoopValues{1});
else
   Nvalues = 1;
end

%There is currently no course frequency locking
FreqFine = zeros(length(SNRdBList),3,Nvalues);
FreqSuperFine = zeros(length(SNRdBList),Nvalues);
EffSNR = zeros(length(SNRdBList),Nvalues);
%=================================================================
%    Simulate the signal
%=================================================================
for lp1 = 1:Nvalues
   for LV = 1:length(LoopVariables)
      eval([LoopVariables{LV} '=' num2str(LoopValues{LV}(lp1)) ';']);
   end
   disp(['Simulating Test: ' num2str(lp1) ' of ' num2str(Nvalues)]);
   for Sn = 1:length(SNRdBList)
      
      SNRdB = SNRdBList(Sn);
      disp(['SNR: ' num2str(SNRdB) 'dB']);
      schmidl2
      EffSNR(Sn,lp1) = mean(mean(CarrierSNR.'));
      FreqFine(Sn,:,lp1) = sqrt(mean((MeasFreq-freqoffset*IFFTsize).^2))*100;
      FreqSuperFine(Sn,lp1) = sqrt(mean((BlockFreqEst-freqoffset*IFFTsize).^2))*100;
   end 
end
%=================================================================
disp(['Frequency Estimation Error : ' num2str((BlockFreqEst(1)-freqoffset*IFFTsize)*100),...
      ' % carrier spacing']);
disp(['Time offset from symbol FFT section: ' num2str(SyncTimeOffset(1)+TimeOff)]);
Ncrop = round(FrmLength*NframesDisp);
if TimeOff > 0;
   ToffDisp = FrmLength - TimeOff;
else
   ToffDisp = -TimeOff;
end
if length(Guard)>1
   SymbStart = ToffDisp+Guard(1)+Guard(2);
else
   SymbStart = ToffDisp+Guard;
end
if TimeSyncPlot
   figure(1)
   clf
   subplot(3,1,1);
   plot(1:Ncrop,abs(o(1:Ncrop)))
   hold on; plot([ToffDisp, ToffDisp],ylim,'k',[SymbStart, SymbStart],ylim,'g'); hold off
   ylabel('Frame Sync');
   axis tight
   subplot(3,1,2);
   plot(1:Ncrop,abs(o2(1:Ncrop)),'r');
   hold on; plot([ToffDisp, ToffDisp],ylim,'k',[SymbStart, SymbStart],ylim,'g'); hold off
   
   ylabel('Symbol Sync');
   axis tight
   
   
   subplot(3,1,3)
   plot(abs(Out2(1:Ncrop)))
   hold on; plot([ToffDisp, ToffDisp],ylim,'k',[SymbStart, SymbStart],ylim,'g'); hold off
   axis tight
   ylabel('OFDM Pow')
   xlabel('Time (samples)');
   setplotstyle(1.5,1,15,0);
   
   figure(2)
   subplot(2,1,1)
   plot(1:Ncrop,abs(o2(1:Ncrop)));
   ylabel('Symbol Sync');
   axis tight
   subplot(2,1,2)
   plot(1:Ncrop,angle(o2(1:Ncrop)),[1 Ncrop],[1 1]*freqoffset*(-2*pi)*IFFTsize,'r')
   ylabel('Phase Sync Signal');
   axis tight
   ylim([-pi, pi])
   
   set(gca,'ytick',[-3:1:3])
   setplotstyle(1.5,1,15,0);
   
   figure(3)
   subplot(2,1,1)
   plot(1:Ncrop,abs(o(1:Ncrop)));
   axis tight
   ylabel('Frame Sync');
   subplot(2,1,2)
   plot(1:Ncrop,angle(o(1:Ncrop)),[1 Ncrop],[1 1]*freqoffset*(-pi)*IFFTsize,'r')
   ylabel('Phase Sync Signal');
   axis tight
   ylim([-pi, pi])
   set(gca,'ytick',[-3:1:3])
   setplotstyle(1.5,1,15,0);
   
end
%===================================================
%  SNR verses subcarrier number
%===================================================
if CarrierSNRFlag
   %Redraw over previous symbol SNR figure, or make new figure if doesn't exist
   Hs = findobj('tag','carriersnr');
   if ~isempty(Hs)
      figure(Hs)
   else
      figure;		%Make a new figure
   end
   if Trials==1
      plot(CarrierSNR)
   else
      plot(mean(CarrierSNR.'))
   end
   
   xlabel('Frequency (carrier spacing)')
   ylabel('Effective SNR (dB)');
   setplotstyle
   set(gcf,'tag','carriersnr');
end
%===================================================
%  SNR verses symbol number within a frame
%===================================================
if SymbolSNRFlag
   %Redraw over previous symbol SNR figure, or make new figure if doesn't exist
   Hs = findobj('tag','symbolsnr');
   if ~isempty(Hs)
      figure(Hs)
   else
      figure;		%Make a new figure
   end
   if Trials==1
      plot(SymbolSNR);
   else
      plot(mean(SymbolSNR.'));
   end
   
   xlabel('Time (Symbols within Frame)');
   ylabel('Effective SNR (dB)');
   setplotstyle
   set(gcf,'tag','symbolsnr');	
end
%===================================================
%  Spectrograpgh of the last simulated OFDM block
%===================================================
if SpecGramFlag
   %Redraw over previous specgram figure, or make new figure if doesn't exist
   Hs = findobj('tag','specgram');
   if ~isempty(Hs)
      figure(Hs)
   else
      figure;		%Make a new figure
   end
   
   [B,F,T] = specgram(Out2,IFFTsize,1,boxcar(IFFTsize),round(3/4*IFFTsize));
   %B([IFFTsize/2+1:end, 1:IFFTsize],:)
   imagesc(T,F,20*log10(abs(B([(IFFTsize/2+1):IFFTsize, 1:IFFTsize/2],:))))
   xlabel('Time (samples)');
   ylabel('Normalised Freq (1 = Sample Freq)');
   colormap(1-gray)
   caxis([-SNRdB 10])
   h = colorbar('vert');
   g = get(h,'ylabel');
   set(g,'string','Power (dB)')
   setplotstyle
   set(gca,'ydir','norm');
   set(gcf,'tag','specgram');	
end

%===================================================
%  Frequency Locking Accuracy verses SNR
%===================================================
if FreqLockSNRFlag
   %Redraw over previously used figure, or make new figure if doesn't exist
   Hs = findobj('tag','FreqLockSNR');
   if ~isempty(Hs)
      figure(Hs)
   else
      figure;		%Make a new figure
   end
   %semilogy(SNRdBList,FreqFine,)
   h = semilogy(SNRdBList,FreqFine(:,1),SNRdBList,FreqSuperFine(:,1));
   legend(h,'Angle(Symb), Symb Time','Angle(Frame), Frame Time','Angle(Frame), Symb Time','SuperFine Freq lock')
   xlabel('Signal to Noise Ratio (dB)');
   ylabel('RMS Freq Error (% of carrier spacing)');
   set(gcf,'tag','FreqLockSNR');
   setplotstyle
   grid on
end


%===================================================
%  Channel Characterisation
%===================================================
if ChanCharFlag
   %Redraw over previously used figure, or make new figure if doesn't exist
   Hs = findobj('tag','ChanChar');
   if ~isempty(Hs)
      figure(Hs)
   else
      figure;		%Make a new figure
   end
   MN = 4;
   if delspread>0
      h1 = plot(linspace(1,(IFFTsize+0.5),IFFTsize*MN),20*log10(abs(fft(delpro,MN*IFFTsize))));
      hold on
   end
   
   %ind = [NumCarr
   h2 = plot(EvenCarriers,20*log10(abs(Cdetrend)),'r')
   hold on
   h3 = plot(AllCarriers,20*log10(abs(ChannResp2a)),'g')
   hold off
   if delspread>0
      legend([h1,h2,h3],'True Response','Measured Even Carrs','Interpolated')
   else
      legend([h2,h3],'Measured Even Carrs','Interpolated')
   end
   
   setplotstyle
   set(gcf,'tag','ChanChar');
end

%=======================================================
%  Phase response of the super fine frequency locking
%=======================================================
if SuperFinePhFlag
   %Redraw over previously used figure, or make new figure if doesn't exist
   Hs = findobj('tag','SuperFinePh');
   if ~isempty(Hs)
      figure(Hs)
   else
      figure;		%Make a new figure
   end
   subplot(2,1,1)
   plot(1:Ncrop,abs(ov(1:Ncrop)));
   axis tight
   ylabel('Frame Sync');
   subplot(2,1,2)
   ExpectedPh = (freqoffset*IFFTsize-MeasFreq(m,FineFreqLock))*(-2.5*TotSymbPerFrm*pi);
   plot(1:Ncrop,angle(ov(1:Ncrop)),[1 Ncrop],[1 1]*ExpectedPh,'r')
   ylabel('Phase Sync Signal');
   axis tight
   ylim([-pi, pi])
   %set(gca,'ytick',[-3:1:3])
   setplotstyle(1.5,1,15,0);
   set(gcf,'tag','SuperFinePh');
end