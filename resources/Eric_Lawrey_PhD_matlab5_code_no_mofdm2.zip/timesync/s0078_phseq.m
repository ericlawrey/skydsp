%This script compares using a PN phase sequence for the time synchroniser
%as compared with the time spectral flatness phasing scheme. Results
%show that there is not much difference.

%Simulate 
%Timothy M. Schmidl and Donald C. Cox, "Robust Frequency and Timing Synchronization for OFDM",
%IEEE Transactions on Communications, Vol. 45, No. 12, December 1997

%Construct the synchronisation block of two symbols. First symbol only uses every
%even carrier, resulting in duplicate 1st and 2nd half of the symbol. Second symbol
%also transmits of the odd carriers with a separate PN sequence.

%Subcarrier modulation is chosen from QPSK, however the first symbol if boosted in
%amplitude by sqrt(2) to bring its total power up to the other symbols.
Trials = 2000;

NumCarr = 80;                    %Number of data OFDM subcarriers
IFFTsize = 128;                  %Size of IFFT to use, (complex waveform so IFFTsize>N)
%GuardPeriod = 0;						%Guard Period in Samples
%GuardPeriod = [constant guard period, raised cosine envelope, overlap];
Guard = [32, 0, 0];

RealComplex = 'complex';         %Generate complex OFDM signals
SymbPerFrm = 8;						%Number of data symbols per frame (not including sync)
NFrms = 3;								%Number of frames to simulate
FrmCrop = 1.5;							%Number of frames to crop to, allows trimming of the end of
%                                 waveform after time offset has been applied
freqoffset = 2.4/IFFTsize;			%Frequency offset as fraction of sample rate
SNRdB = 10;								%Signal to Noise Ration of channel (dB)
Ntaps	 = 10;							%Number of filter taps for Static Multipath (samples)
delspread = 2;							%Decay time constant for stativ multipath (samples)
%                                 To disable multipath set delspread to 0.
PhaseType = -1;	                  %Phase scheme used for the time synchronisation symbol
% Schmidl recommends using a PN sequence using QPSK modulation, however the phase
% scheme can be changed by setting PhaseType to the appropriate value.
% See GENREF for more detail
% -1  PN sequence from QPSK
% 0 - SN TN scheme
% 1 - GA optimised
% 2 - Random
% 3 - Spectral Flatness optimised
% 4 - Newmanns
% 5 - Shapiro-Rudin
TimeOffSymbScaleFlag=1;				%Determines the units of TimeOffset
%                                 1 = TimeOffset in units of symbols
%                                 0 = TimeOffset in units of samples
TimeErr = zeros(Trials,3);			%Matrix of measured time error, 
%                                 column 1, peak search
%                                 column 2, mean of Threshold fraction of peak 
%                                           to Threshold fraction of peak
%                                 column 3, centre of mass between 90% to 90%
Threshold = 0.90;						%Take the timing from Threshold*Peak Value
SearchRange  = 2*GuardPeriod;		%Number of samples to search above and
%                                 below the peak location to find the Threshold
%                                 boundaries

schmidl
TimeErr2 = TimeErr;
PhaseType = 3;
schmidl

[n,x] = hist(TimeErr(:,3),[-35:1:0]);
h1 = stairs(x,n/sum(n),'b');
[n,x] = hist(TimeErr2(:,3),[-35:1:0]);
hold on
h2 = stairs(x,n/sum(n),'r');
hold off
legend([h1, h2],'PN phase seq','Ph=3.6315*X^2')
xlabel('Time Offset from Start of Frame (samples)');
ylabel('Probability Distribution');
setplotstyle
plotm([h1,h2],10)
elcopyright
%savefig('s0078_phseq')

