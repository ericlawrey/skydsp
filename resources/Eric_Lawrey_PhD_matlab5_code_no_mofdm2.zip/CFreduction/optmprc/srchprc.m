function [minPRCdata, minPAPR] = srchprc(data, data_carriers, PRC_carriers, bitsHz_data, bitsHz_PRC,...
	Data_QAM_PSK, PRC_QAM_PSK, ifft_size, format,NullPRC,searchtype,...
	Nsearch)
%This function checks combinations of peak reduction carriers for
%a given data set, and carrier configuration. It returns the PRC data
%which gives the lowest Peak to Average Power Ratio (PAPR).
%NullPRC indicates whether to turn off the Peak Reduction carriers
%as part of the search. NullPRC = 1, search all combinations of data
%and turning off the carriers.
%searchtype = 1 check all possible combinations
%searchtype = 0 do a random search using Nsearch combinations

plotresult = 0;		%plotresult = 1 debug mode plots the symbol for each combination
			%plotresult = 0 don't plot anything;

NumPRC = length(PRC_carriers);

if (NullPRC == 1),
	if (searchtype == 1)
		codewords = 0:1:(2^bitsHz_PRC+1)^(NumPRC)-1;
	else
		codewords = floor(((2^bitsHz_PRC+1)^(NumPRC)-1)*rand(1,Nsearch));
	end
else
	if (searchtype == 1)
		codewords = 0:1:2^(NumPRC*bitsHz_PRC)-1;
	else
		codewords = floor((2^(NumPRC*bitsHz_PRC)-1)*rand(1,Nsearch));
	end
end

PAPR = zeros(1,length(codewords));
PRCList = zeros(length(codewords),NumPRC);

%Now sequentially check all possible PRC combinations
for k = 1:length(codewords)

	if (NullPRC == 1)
		%Add the PRC to the end of the data
		PRCList(k,:) = convbase(codewords(k),(2^bitsHz_PRC+1)^(NumPRC),(2^bitsHz_PRC)+1,1);
		index = find(PRCList(k,:) == 2^bitsHz_PRC);
		%index
		%size(PRCList)
		PRCList(k,index) = ones(1,length(index))*(-1);

		%error('stop');
	else
		%Add the PRC to the end of the data
		PRCList(k,:) = convbase(codewords(k),NumPRC*bitsHz_PRC,bitsHz_PRC);
	end
	PRCdata = PRCList(k,:);
	symbol = prcsymb(data, data_carriers, PRCdata, PRC_carriers, bitsHz_data, bitsHz_PRC,...
		Data_QAM_PSK, PRC_QAM_PSK, ifft_size, format);
	if (plotresult == 1)
		PRCdata
		figure(1);
		if (strcmp(format, 'complex') == 1) 
			plot(abs(symbol));
			figure(2);
			plot(20*log10(abs(fftshift(fft(symbol)))));
			zoom on
			figure(3);
			plot(360/(2*pi)*angle(fftshift(fft(symbol))));
			axis([125 134, -180 180]);
			hold on;
			plot(360/(2*pi)*angle(fftshift(fft(symbol))),'x');
			hold off;
			zoom on;
	
		else
			plot(symbol);
			figure(2);
			plot(20*log10(abs((fft(symbol)))));
			zoom on
			figure(3);
			plot(360/(2*pi)*angle((fft(symbol))));
			axis([min(data_carriers) max(PRC_carriers), -180 180]);
			hold on;
			plot(360/(2*pi)*angle((fft(symbol))),'x');
			hold off;
			zoom on;
		end
		pause	
	end
	PAPR(k) = 10*log10(max(abs(symbol).^2)/mean(abs(symbol).^2));
	%PAPR(k) = calcpapr(symbol);
	%if (rem(k,100)==0),
	%	disp(['codeword: ', int2str(k), ' of ', int2str(length(codewords))]);
	%end

end

cmin = PRCList(find(PAPR == min(PAPR)),:);
if (size(cmin,1) > 1),
	disp(['WARNING: duplicate optimal PRC bit found : ' ...
		mat2str(cmin) ]);
	cmin = cmin(1,:);
end;

minPRCdata = cmin;
minPAPR = min(PAPR);
