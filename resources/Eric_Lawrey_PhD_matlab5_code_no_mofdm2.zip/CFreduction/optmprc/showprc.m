rand('seed',6546216);
Ncarr = 10;
NPRC = 1;
CodeSrchType = 1;	%1 = all combinations, 0 random search
Ncodes = 1000;		%Number of codes for random search
Data_QAM_PSK = 0;
PRC_QAM_PSK = 0;
ifft_size = 256;
format = 'complex';
%format = 'real';
NullPRC = 1;
searchtype = 1;
Nsearch = 100;
CompName = 'showprc.txt';
HistPoints = 400;
updaterate = 1;
%write the header to a new file
header3



PRC_carriers = [1];
data_carriers = setxor([1:Ncarr+NPRC],PRC_carriers);

bitsHz_data = 1;
bitsHz_PRC = 1;
Position = 1;
runsetrand;

   