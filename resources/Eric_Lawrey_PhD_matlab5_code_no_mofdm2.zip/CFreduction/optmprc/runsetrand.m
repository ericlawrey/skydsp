data_carriers
PRC_carriers
tic

first = 1;
if length(PRC_carriers) == 0
	%Just the the results for no PRC carriers
	NumCarr = length(data_carriers);

	if (CodeSrchType == 1)
		codewords = 0:1:2^(NumCarr*bitsHz_data-1)-1;	%Only search half the code words
							%as the result is symmetrical
	else
		codewords = floor((2^(NumCarr*bitsHz_data)-1)*rand(1,Ncodes));
	end
	
	PAPR = zeros(1,length(codewords));	%No PRCs
	DataList = zeros(length(codewords),NumCarr);
	%Now sequentially check all possible PRC combinations
	for k = 1:length(codewords)
		DataList(k,:) = convbase(codewords(k),NumCarr*bitsHz_data,bitsHz_data);

		data = DataList(k,:);

		symbol = dmtsymb(data, data_carriers, bitsHz_data, Data_QAM_PSK, ifft_size, format);
		PAPR(k) = calcpapr(symbol);
		if (rem(k,updaterate) == 0)
			t = toc;
			if (first == 1)
				tpercode = t/updaterate;
				first = 0;
			end
			tpercode = tpercode*0.9+0.1*(t/updaterate);
			tfinish = ((length(codewords)-k)*tpercode)/60;
			tfinmin = floor(tfinish);
			tfinsec = round((tfinish-tfinmin)*60);
			disp([int2str(k), ' codes, ' sprintf('%4.1f',k/length(codewords)*100),...
				'%, ', int2str(length(PRC_carriers)), ' ',CompName ', ',int2str(tfinmin),':',sprintf('%2d',tfinsec),' min:sec']);
			tic;
		end
	end

	PAPRlinear = 10.^(PAPR/10);
	StdPAPR = 10*log10(std(PAPRlinear));
	AvgPAPR = 10*log10(mean(PAPRlinear));

	[N,X] = hist(PAPR,HistPoints);
	C = cumsum(N)/sum(N);
	T99P5 = X(min(find(C>0.995)));
	T99 = X(min(find(C>0.99)));
	T95 = X(min(find(C>0.95)));
	T90 = X(min(find(C>0.90)));
	T80 = X(min(find(C>0.80)));
	T70 = X(min(find(C>0.70)));
	T60 = X(min(find(C>0.60)));
	T50 = X(min(find(C>0.50)));
	T40 = X(min(find(C>0.40)));
	T30 = X(min(find(C>0.30)));
	T20 = X(min(find(C>0.20)));
	T10 = X(min(find(C>0.10)));
	T5 = X(min(find(C>0.05)));
	T1 = X(min(find(C>0.01)));
	T0P5 = X(min(find(C>0.005)));

	%========================
	%Save the results to file
	%========================
	fid = fopen(CompName,'a');
	fprintf(fid,'%10d, %10d, %10d, %10d, %10d',bitsHz_data,bitsHz_PRC,0,length(data_carriers), length(PRC_carriers));
	fprintf(fid,'%10.4f, %10.4f, %10.4f, %10.4f,', max(PAPR),AvgPAPR,StdPAPR,0);
	fprintf(fid,'%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,', T99P5,T99,T95,T90,T80,T70,T60,T50);
	fprintf(fid,'%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,', T40,T30,T20,T10,T5,T1,T0P5);
	fwrite(fid, 13, 'char');
	fwrite(fid, 10, 'char');
	fclose(fid);
	disp(['Max PAPR: ' num2str(max(PAPR)) 'dB, Average PAPR: ' num2str(mean(PAPR)) 'dB']);
	disp(['STD PAPR: ' num2str(StdPAPR) 'dB']);

else
%=====================================================================
	NumCarr = length(data_carriers);	
	
	if (CodeSrchType == 1)
		codewords = 0:1:2^(NumCarr*bitsHz_data-1)-1;	%Only search half the code words
								%as the result is symmetrical
	else
		codewords = floor((2^(NumCarr*bitsHz_data)-1)*rand(1,Ncodes));
	end
	
	PAPR_PRC = zeros(1,length(codewords));	%Peak to average power with peak reduction carriers
	PAPR = zeros(1,length(codewords));	%No PRCs
	PAPR_NOPRC = PAPR_PRC;	
	DataList = zeros(length(codewords),NumCarr);
	PRCList = zeros(length(codewords),length(PRC_carriers));
	%Now sequentially check all possible PRC combinations
	for k = 1:length(codewords)
	
		DataList(k,:) = convbase(codewords(k),NumCarr*bitsHz_data,bitsHz_data);
	
		data = DataList(k,:);
		[minPRCdata, minPAPR] = srchprc(data, data_carriers, PRC_carriers, bitsHz_data, bitsHz_PRC,...
		Data_QAM_PSK, PRC_QAM_PSK, ifft_size, format,NullPRC,searchtype,...
		Nsearch);
		PRCList(k,:) = minPRCdata;	
		PAPR_PRC(k) = minPAPR;

		symbol = dmtsymb(data, data_carriers, bitsHz_data, Data_QAM_PSK, ifft_size, format);
		PAPR_NOPRC(k) = calcpapr(symbol);

		if (rem(k,updaterate) == 0)
			t = toc;
			if (first == 1)
				tpercode = t/updaterate;
				first = 0;
			end
			tpercode = tpercode*0.9+0.1*(t/updaterate);
			tfinish = ((length(codewords)-k)*tpercode)/60;
			tfinmin = floor(tfinish);
			tfinsec = round((tfinish-tfinmin)*60);
			disp([int2str(k), ' codes, ' sprintf('%4.1f',k/length(codewords)*100), '%, Pos: ',sprintf('%4d',Position),...
				', ', int2str(length(PRC_carriers)), ' ',CompName ', ',int2str(tfinmin),':',sprintf('%2d',tfinsec),' min:sec']);
			tic;
		end
	end
		
	PAPR_PRClinear = 10.^(PAPR_PRC/10);
	StdPAPR_PRC = 10*log10(std(PAPR_PRClinear));
	AvgPAPR_PRC = 10*log10(mean(PAPR_PRClinear));
	AvrgCarriers = length(find(PRCList ~= -1))/length(codewords);
	[N,X] = hist(PAPR_PRC,HistPoints);
	C = cumsum(N)/sum(N);
	T99P5 = X(min(find(C>0.995)));
	T99 = X(min(find(C>0.99)));
	T95 = X(min(find(C>0.95)));
	T90 = X(min(find(C>0.90)));
	T80 = X(min(find(C>0.80)));
	T70 = X(min(find(C>0.70)));
	T60 = X(min(find(C>0.60)));
	T50 = X(min(find(C>0.50)));
	T40 = X(min(find(C>0.40)));
	T30 = X(min(find(C>0.30)));
	T20 = X(min(find(C>0.20)));
	T10 = X(min(find(C>0.10)));
	T5 = X(min(find(C>0.05)));
	T1 = X(min(find(C>0.01)));
	T0P5 = X(min(find(C>0.005)));
	%========================
	%Save the results to file
	%========================
	fid = fopen(CompName,'a');
	fprintf(fid,'%10d, %10d, %10d, %10d,',bitsHz_data,bitsHz_PRC,length(data_carriers), length(PRC_carriers));

	fprintf(fid,'%10.4f, %10.4f, %10.4f, %10.4f,', max(PAPR_PRC),AvgPAPR_PRC,StdPAPR_PRC,AvrgCarriers);
	fprintf(fid,'%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,', T99P5,T99,T95,T90,T80,T70,T60,T50);
	fprintf(fid,'%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,%8.4f,', T40,T30,T20,T10,T5,T1,T0P5);
	fprintf(fid,'%3i,', PRC_carriers);
	fprintf(fid,'%3i,', data_carriers);
	fwrite(fid, 13, 'char');
	fwrite(fid, 10, 'char');
	fclose(fid);
	disp(['Max PAPR_PRC: ' num2str(max(PAPR_PRC)) 'dB, Average PAPR_PRC: ' num2str(mean(PAPR_PRC)) 'dB']);
	disp(['STD PAPR_PRC: ' num2str(StdPAPR_PRC) 'dB']);
	disp(['Average number of PRC carriers: ' num2str(AvrgCarriers)]);
end