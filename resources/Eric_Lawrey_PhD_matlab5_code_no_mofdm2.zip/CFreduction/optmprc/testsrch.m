

CodeSrchType = 1;	%1 = all combinations, 0 random search
Ncodes = 100;		%Number of codes for random search
Data_QAM_PSK = 0;
PRC_QAM_PSK = 0;
ifft_size = 512;
format = 'complex';
%format = 'real';
NullPRC = 1;
searchtype = 1;
Nsearch = 100;
CompName = 'Comp1.txt';

%Write the header information to the file
fid = fopen(CompName,'w');
fprintf(fid,'BitsHzData,  BitsHzPRC,     NoData,     NoPRC,    MxPAPR,    AvgPAPR, Avg+Std PAPR, AvgNumPRC');
fwrite(fid, 13, 'char');
fwrite(fid, 10, 'char');
fclose(fid);


data_carriers = [ 1 2 3 4];
PRC_carriers = [5:11];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4];
PRC_carriers = [5:12];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset
data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7:8];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset
data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7:9];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset
data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7:10];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset
data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7:11];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7:12];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6];
PRC_carriers = [7:12];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [9];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [9:10];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [9:11];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [9:12];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [9:13];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [ 1 2 3 4 5 6 7 8];
PRC_carriers = [9:14];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [13];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [13:14];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [13:15];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [13:14];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [13:15];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset

data_carriers = [1:12];
PRC_carriers = [13:16];
bitsHz_data = 1;
bitsHz_PRC = 1;

runset