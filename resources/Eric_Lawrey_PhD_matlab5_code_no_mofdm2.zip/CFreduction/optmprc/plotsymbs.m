data = [1     0     1     1     0     1     0     1     1     0];
data_carriers = [1     2     3     5     6     7     8     9    11    14]+80;
PRCdata = [1     1     1     0];
PRC_carriers = [ 4    10    12    13]+80;
bitsHz_data = 1; bitsHz_PRC = 1;
Data_QAM_PSK = 0;
PRC_QAM_PSK = 0;
ifft_size = 1024;
format = 'real';

symbol1 = prcsymb(data, data_carriers, PRCdata, PRC_carriers, bitsHz_data, bitsHz_PRC,...
      Data_QAM_PSK, PRC_QAM_PSK, ifft_size, format);
symbol2 = prcsymb(data, data_carriers, [], [], bitsHz_data, bitsHz_PRC,...
   Data_QAM_PSK, PRC_QAM_PSK, ifft_size, format);
peak2 = max(abs(symbol2));
peak1 = max(abs(symbol1));
figure(1)
subplot(2,1,1);
plot(symbol1*peak2/peak1)
title([int2str(length(data)) ' Data Carriers, with ' int2str(length(PRC_carriers)) ' PRCs']);
xlabel('Time (samples)');
ylabel('Signal Level');
subplot(2,1,2);
plot(symbol2);
title([int2str(length(data)) ' Data Carriers, with no PRCs']);
xlabel('Time (samples)');
ylabel('Signal Level');