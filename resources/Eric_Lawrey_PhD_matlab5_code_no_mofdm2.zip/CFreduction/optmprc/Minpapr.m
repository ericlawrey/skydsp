function datamin = minpar(data,NumPRC,carriers,bitsHz,ifft_size, NullPRC,...
				searchtype,Nsearch,evaltype)
%datamin = minpar(data,NumPRC,carriers,bitsHz,ifft_size,searchtype,Nsearch)
%PRC => Peak Reduction Carrier
%searchtype = 1, checks every combination available (This is the default)
%searchtype = 0, does a random search
%evaltype = 0, Uses the base band time domain waveform to evaluate the Peak to average power ratio
%evaltype = 1, Uses the FFT of the input data to measure the peak to average power
%		of the envelope of the signal
%Nsearch is the number of random combinations to search

if (nargin < 7)
	searchtype = 1;
elseif (nargin < 8)
	Nsearch = 100;
elseif (nargin < 9)
	evaltype = 0;
end

NumCarriers = length(data)+NumPRC;

if (NullPRC == 1),
	if (searchtype == 1)
		codewords = 0:1:(bitsHz+2)^(NumPRC)-1;
	else
		codewords = floor(((bitsHz+2)^(NumPRC)-1)*rand(1,Nsearch));
	end
else
	if (searchtype == 1)
		codewords = 0:1:2^(NumPRC*bitsHz)-1;
	else
		codewords = floor((2^(NumPRC*bitsHz)-1)*rand(1,Nsearch));
	end
end

PAR = zeros(1,length(codewords));
PRCList = zeros(length(codewords),NumPRC);
%Now sequentially check all possible PRC combinations
for k = 1:length(codewords)

	if (NullPRC == 1)
		%Add the PRC to the end of the data
		PRCList(k,:) = convbase(codewords(k),(bitsHz+2)^(NumPRC),(2^bitsHz)+1,1);
		index = find(PRCList(k,:) == 2);
		%index
		%size(PRCList)
		PRCList(k,index) = ones(1,length(index))*(-1);

		%error('stop');
	else
		%Add the PRC to the end of the data
		PRCList(k,:) = convbase(codewords(k),NumPRC*bitsHz,bitsHz);
	end
	totdata = [data PRCList(k,:)];
	symbol = dmtsymb(totdata,carriers,bitsHz,0,ifft_size,'real');
	PAR(k) = calcpapr(symbol);
	%if (rem(k,100)==0),
	%	disp(['codeword: ', int2str(k), ' of ', int2str(length(codewords))]);
	%end

end

cmin = PRCList(find(PAR == min(PAR)),:);
if (size(cmin,1) > 1),
	disp(['WARNING: duplicate optimal PRC bit found : ' ...
		mat2str(cmin) ]);
	cmin = cmin(1,:);
end;
datamin = [data cmin];

