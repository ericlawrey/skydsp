function PAPR = calcPAPR(x)
%CALCPAPR Calculate the peak to average power ratio
%	PAPR = calcPAPR(x)
%	PAPR is the peak to average power ratio in dB
%	Peak to average power for a complex waveform is equal to:
%	PAPR = Pp/Pa;	Pp = Peak Power, Pa = Average Power
%	PAPR = max(Re^2+Im^2)/mean(Re^2+Im^2)

%Re = real(x);
%Im = imag(x);
%PAPR = 10*log10(max(Re.^2+Im.^2)/mean(Re.^2+Im.^2));
PAPR = 10*log10(max(abs(x).^2)/mean(abs(x).^2));