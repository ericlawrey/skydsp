%This simulation plots the Effective SNR of OFDM as a function of start
%time error. 
%
%===========================
%	Default Variabels
%===========================
Nsymbol = 400;				%Number of Symbols to simulate (default)
Ntrials = 8;				%Number of Trials to average the results over. Lowering Nsymbol
%								and increasing Ntrials can be used to minimise the memory useage
%								Memory useage ~(Nsymbol+NumRefSymb)*(IFFTsize+GuardPeriod)*8(bytes 
%								per number)*2(complex)*2(working memory) in Bytes
Ncarriers = 64;			%Number of carriers to use
IFFTsize = 128;			%Size of the IFFT used to generate the OFDM signal
RealComplex = 'complex';	%Whether to generate a 'real' or 'complex' OFDM signal
GuardPeriod = [20 20 20];			%Length of the guard period in samples
%								[constant guard period, raised cosine envelope, overlap]
fast_mode = 0;				%Enabling the fast mode in OFDMMOD (see help ofdmmod)
ClipDistFlag = 0;			%Whether to enable clipping distortion on the signal
OutBackoffdB = 10;			%Output power backoff in dB
TimeOffset = 0;			%Time Offset error in samples (integer)
SNRdB = 2000;				%Channel SNR for AWGN in dB
RefScheme = 0;				%Type of pilot symbol used
PilotPowBoost = 1;		%Power boosting of the pilot power
NumRefSymb = 8;			%Number of pilot symbols to use
SavePlotFlag = 1;			%(1) - Save the simulated plot, (0) - don't, (useful for testing)
xticks = [-60:10:30];
MarkerSpacing = 5;		%Spacing between the markers
plot_filename = 's0069_SNR_RCTimeError';	%File name of the plot generated
if length(GuardPeriod)==1
   title_text = ['Guard Period: ' num2str(GuardPeriod) ' samples, IFFT size:' num2str(IFFTsize)];
else
   title_text = ['Flat GP: ' num2str(GuardPeriod(1)) ', Raised Cos GP: ' num2str(GuardPeriod(2)), ...
         ', Overlap: ' num2str(GuardPeriod(3)) ', IFFT size:' num2str(IFFTsize)];
end
   
%=====================================
%	Loop Variables
%=====================================
%The loop variables overwrite the default values
LoopVariable = 'TimeOffset';		%X axis Loop Variable
LoopList = [-60:1:30];

LoopVariable2 = 'Ncarriers';
LoopList2 = [64];
LockVariables2 = {};				%This variable will also change with LoopVariable2
LockValues2 = {};					%These are the values the lock variables will take
%										the length of each array must match the LoopList length
axis_range = [-60 30 -5 60];	%Plot axis range
legend_flag = 0;					%Enable (1) or Disable plotting of the legend
legend_pos = 2;					%Position of legend, See help legend

s0051_effSNR