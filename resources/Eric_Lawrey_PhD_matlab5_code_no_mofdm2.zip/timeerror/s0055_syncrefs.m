%S055 This plots and save the different types of reference modulation schemes
%   0 - S. Narahashi and T. Nojima phasing scheme
%   1 - Use the low crest factor phasing scheme developed
%       using genetic algorithms. This algorithm only allows
%       for carrier numbers which have been simulated and stored
%       in s0019_low_CF_DMT_phase_table.mat.
%   2 - Use random phase angles
%	 3 - Spectral Flatness Optimised using simulations
%       Phase = 0.425*X.^2
%    4 - Newmanns phasing scheme
%        Ph = (pi*(k-1)^2)/N
%        S. Boyd, "Multitone signals with low crest factor", IEEE Trans.
%        Circuits Syst., Vol. CAS-33, pp. 1018-1022, Oct. 1986
%    5 - Shapiro-Rudin Phase scheme
%        #Tones, Phase Sequence
%          2      1, 1
%          4      1, 1, 1,-1
%          8      1, 1, 1,-1, 1, 1,-1, 1
%          16     1, 1, 1,-1, 1, 1,-1, 1, 1, 1, 1,-1,-1,-1, 1,-1
% 			etc
%        where -1 maps to 0 radians and +1 corresponds to pi radians.
%        Non-power of two number of tones truncates the sequence.
%   This simulation takes approximately 6 sec

titles = {'S. Narahashi and T. Nojima phasing scheme','GA developed low CF phasing scheme',...
      'Random Phase Angles','Time Spectral Flatness Optimised, Ph=3.6315*X^2','Newmanns phasing scheme',...
      'Shapiro-Rudin Phase scheme'};
legendstr = {'S.N. T.N','G.A. optimised','Random','Flatness Optimised','Newmann','Shapiro-Rudin'};
filenames = {'s0055_SNTN','s0055_GAlowCF','s0055_Random','s0055_Flat_Optim','s0055_Newmann',...
      's0055_ShapiroRudin'};

NumCarr = 224;
ifft_size_time = 2.^(nextpow2(NumCarr*4));
ifft_size_powdist = 2.^(nextpow2(NumCarr*32));
ifft_size_specgram = 2.^(nextpow2(NumCarr));
SaveFlag = 1;			%1=Save plots to the files, 0 = don't save the plots
s = [];
x = [];
for k = 0:5
   %===================================
   %   RF carrier envelope
   %===================================
   data_vector = genref(NumCarr,k);
   RealComplex = 'complex';
   carriers = mkcarriers(NumCarr,ifft_size_time,RealComplex);
   outsymbol_T = ofdmmod(data_vector,carriers, ifft_size_time, 0, RealComplex);
   figure(1)
   clf
   T = linspace(0,1,length(outsymbol_T));
   plot(T,abs(outsymbol_T));
   xlabel('Time (Normalised to Symbol Length)')
   ylabel('Power Envelope (linear)')
   axis tight;
   title(titles{k+1})
   ylim([0 0.04])
   %   title(['Reference Symbol, ', num2str(NumCarr) ,' Carriers, ' RefString]);
   setplotstyle
   if SaveFlag
      savefig([filenames{k+1} '_T'])
   end
   
   %==================================
   %    Spectrograph of the signal
   %==================================
   carriers = mkcarriers(NumCarr,ifft_size_specgram,RealComplex);
   outsymbol = ofdmmod(data_vector,carriers, ifft_size_specgram, 0, RealComplex);   
   figure(2)
   N = 1;
   M = 4;
   I = round(sqrt(ifft_size_specgram))*2;
   [B,F,T] = specgram(outsymbol,ifft_size_specgram*N,ifft_size_specgram,kaiser2(I,'width',1.8),...
      round(I-(sqrt(I)/M)));
   T = linspace(0,1,size(B,2));
   SFFT = size(B,1);
   B2 = [B(SFFT/2+1:end,:); B(1:SFFT/2,:)];
   F = linspace(-(SFFT/2+1),SFFT/2,SFFT);
   imagesc(T,F,20*log10(abs(B2)));
   colormap(hot)
   xlabel('Time (Normalised to Symbol Length)')
   ylabel('Frequency (Norm. to Carrier Spacing)')
   title(titles{k+1})
   caxis([-40 -3])
   h_colour = colorbar('vert');
   h_ylb = get(h_colour,'ylabel');
   set(h_ylb,'string','Power (dB)')
   setplotstyle
   if SaveFlag
      savefig(filenames{k+1},'jpg')
   end
   
   %Calculate the signal power distribution over 8 symbols. This is
   %to improve the accuracy of the random phase symbol response. All
   %the other phasing schemes will be identical over all symbols. However
   %perform the calculations over multiple symbols for all phasing schemes
   %so that the distribution sizes is the same, to make storing the results
   %and plotting easier.
   data_vector = [];
   for l = 1:8
      data_vector = [data_vector genref(NumCarr,k)];
   end
   
   RealComplex = 'complex';
   carriers = mkcarriers(NumCarr,ifft_size_powdist,RealComplex);
   outsymbol_T = ofdmmod(data_vector,carriers, ifft_size_powdist, 0, RealComplex);
   outsymbol_T = outsymbol_T(:);
   s(:,k+1) = sort(abs(outsymbol_T).^2);
   mp = mean((abs(outsymbol_T)).^2);
   x(:,k+1) = 10*log10(s(:,k+1)/mp);
end

   %====================================
   %     Amplitude distribution
   %====================================
   %   sort(abs(outsymbol_T));
   figure(3)
   
   h = plot(x,cumsum(s)/sum(s));
   xlim([-3 8])
   set(gca,'xtick',[-10:1:10]);
   set(gca,'ytick',[0:0.1:1]);
   grid on
   xlabel('Signal Power (dB above mean symbol power)')
   ylabel('Cumulative Power (fraction of total power)')
   title(['Number of tones: ' num2str(NumCarr)]);
   setplotstyle
   legend(h,legendstr,4)
   ylim([0,1])
   plotm(h,NumCarr*60)
   if SaveFlag
      savefig('s0055_powdist')
   end