%MEASFITNESS This script measures the fitness of the evolved sequences
%It calculates a Fitness vector which is a measure of how good each 
%sequence is.
%SeqData is a matrix of all the sequences. Each sequence is one column

%Custom Variables:


%Phase = 1/(N-S1)*(S2*k^2+S3*k+S4)
fast_mode = 0;
K = repmat((1:Ncarriers)',1,size(SeqData,2));
rows = Ncarriers;
S = SeqData;
Phase = zeros(size(K));
for si = 2:size(S,1)
   Phase = Phase+repmat(S(si,:),rows,1).*K.^(size(S,1)-si);
end
%Phase = 2.*Phase./(Ncarriers.^2-repmat(S(1,:),rows,1));

%size(Phase)
%size(K)
%Phase = 1./(Ncarriers-repmat(S(1,:),rows,1)).*(repmat(S(2,:),rows,1).*K.^2+...
%   repmat(S(3,:),rows,1).*K+repmat(S(4,:),rows,1));
%SeqData
Mag = ones(size(K));
[x,y] = pol2cart(Phase,Mag);
data_vector = x+i*y;
data_carriers = mkcarriers(Ncarriers,ifft_size,real_complex);
outsymbol = ofdmmod(data_vector,data_carriers, ifft_size, guard_period,... 
   real_complex, fast_mode);
CF = max((abs(outsymbol).^2))./(mean(abs(outsymbol).^2));
%Fitness = 1./(specflat(outsymbol, data_carriers, ifft_size));
Fitness = (specflat(outsymbol, data_carriers, ifft_size));
%Fitness = 1./CF;


