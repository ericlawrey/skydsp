%This script searches for a good equation which will give pilot reference
%symbols which are flat spectrally (i.e. not a frequency sweep), and also
%have a low crest factor.
%The phase formula is tested over a range of number of carriers to verify
%that it works.
NcarriersList = [intlogspace(16,2048,400)];	%Number of carriers to test
ifft_size_list = [2.^(ceil(log2(NcarriersList+1)+1))];
guard_period = 0;
fast_mode = 0;
real_complex = 'complex';

%Equation coefficients.
S = [0 0 0];
Index = 1;
N = 1;

CoeffList = 3.6315;%linspace(3.6305,3.6335,N);
SeqData = repmat(S',1,N);
Nc = length(NcarriersList);
Flat = zeros(N,Nc);
CF2 = zeros(N,Nc);
%PK99 = CF2;
%CF99 = CF2;
SubSectionList = [2 4 8 16];
for Ncarr = 1:length(NcarriersList)
   Ncarriers = NcarriersList(Ncarr);
   ifft_size = ifft_size_list(Ncarr);
   SeqData(Index,:) = CoeffList;
   
   %=========================================
   %	Measure the spectral flatness and CF
   %=========================================
   fast_mode = 0;
   K = repmat((1:Ncarriers)',1,size(SeqData,2));
   rows = Ncarriers;
   S = SeqData;
   Phase = zeros(size(K));
   for si = 1:size(S,1)
      Phase = Phase+repmat(S(si,:),rows,1).*K.^(size(S,1)-si);
   end
   Mag = ones(size(K));
   [x,y] = pol2cart(Phase,Mag);
   data_vector = x+i*y;
   data_carriers = mkcarriers(Ncarriers,ifft_size,real_complex);
   outsymbol = ofdmmod(data_vector,data_carriers, ifft_size, guard_period,... 
      real_complex, fast_mode);
%   Pow = sort(abs(outsymbol).^2);
%   plot(Pow);
%   pause
%   Ind99 =round(0.99*length(Pow));
   
%   CF99(:,Ncarr) = (Pow(Ind99,:)./(mean(abs(outsymbol).^2)))';
	CF2(:,Ncarr) = (max((abs(outsymbol).^2))./(mean(abs(outsymbol).^2)))';
	for sec = 1:length(SubSectionList)
      Flat(:,Ncarr) = max(Flat(:,Ncarr),specflat(outsymbol, data_carriers, ifft_size, SubSectionList(sec))');
   end
%   Flat(:,Ncarr) = Flat(:,Ncarr)/length(SubSectionList);
      
   
 %  PK99(:,Ncarr) = PK';
     
   %=========================================
   disp(['Ncarriers : ' num2str(Ncarriers)])
end
figure(1)
plot(CoeffList,10*log10(Flat))
xlabel('Phase Equation Coeff. A, Ph = A*X^2')
ylabel('Time Spectral Flatness (dB)');
title(['Measured for ' num2str(length(NcarriersList)) ' different carrier sizes, from ',...
      num2str(min(NcarriersList)) ' to ' num2str(max(NcarriersList))]);
setplotstyle(0.5)
axis tight
%savefig('s0056_flatness');
figure(2)
plot(CoeffList,10*log10(CF2))
title(['Measured for ' num2str(length(NcarriersList)) ' different carrier sizes, from ',...
      num2str(min(NcarriersList)) ' to ' num2str(max(NcarriersList))]);
xlabel('Phase Equation Coeff. A, Ph = A*X^2')
ylabel('Crest Factor (dB)');
axis tight
setplotstyle(0.5)
%savefig('s0056_CF');
figure(3)
C = CF2/4+Flat;
plot(CoeffList,10*log10(mean(C')))
title(['Mean Fitness for ' num2str(length(NcarriersList)) ' different carrier sizes, from ',...
      num2str(min(NcarriersList)) ' to ' num2str(max(NcarriersList))]);
xlabel('Phase Equation Coeff. A, Ph = A*X^2')
ylabel('Fitness (lower is better) 10log_1_0(CF/4+Flat)');
setplotstyle(0.5)
axis tight
%savefig('s0056_Fitness_sm2');
figure(4)
%plot(CoeffList,10*log10(CF2/2+PK99))
%xlabel('Phase Equation Coeff. A, Ph = A*X^2')
%ylabel('Peak 99% (CF2/2+PK99) (dB)');
%setplotstyle(0.5)
%figure(5)
%plot(CoeffList,10*log10(CF99))
%xlabel('Phase Equation Coeff. A, Ph = A*X^2')
%ylabel('Crest Factor 99% (dB)');
%setplotstyle(0.5)