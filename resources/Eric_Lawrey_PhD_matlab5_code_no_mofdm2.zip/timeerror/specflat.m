function [CF,PK99] = specflat(outsig, carriers, IFFTsize, SubSections)
%size(outsig,1)
%fftsize = round(sqrt(size(outsig,1)));
fftsize = IFFTsize/SubSections;
N = 4;			%Frequency Domain interpolation
T = 4;			%Time Domain Interpolation
CF = zeros(1,size(outsig,2));
PK99 = zeros(1,size(outsig,2));
wind = kaiser2(fftsize,-60);
index = unique(ceil(N*carriers/IFFTsize*fftsize));
for k = 1:size(outsig,2)
	w = specgram(outsig(:,k)',fftsize*N,1,wind,fftsize*(1-1/T)); %round(fftsize-N));
   %imagesc(20*log10(abs(w)));
   %pause
   %plot(s)
   
   %pause
   %carriers
   %fftsize*N
	
%min(index)
%max(index)

	sig = w(index,:);
	if nargout > 1
   	s = sort(abs(sig(:)));
   	Ind99 = min(round(0.99*length(s)),length(s));
   	Peak99 = s(Ind99);
   	PK99(k) = (Peak99.^2)./mean(mean(abs(sig).^2));
   end
   %imagesc(20*log10(abs(sig)))
   %pause
   CF(k) = (max(max(abs(sig))).^2./mean(mean(abs(sig).^2)));
   
end