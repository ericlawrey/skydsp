%This script plots the CF of different phasing schemes as a function of the 
%number of tones

Ntones = intlogspace(2,2000, 1000);
Titles = {'S. Narahashi and T. Nojima phasing scheme', 'Newmanns phasing scheme',...
      'Shapiro-Rudin Phase scheme' };
Filenames = {'s0067_SNTN','s0067_Newmann','s0067_Shapiro'};
PhaseType = [0 4 5];
CF = zeros(length(PhaseType),length(Ntones));
for l = 1:length(PhaseType)
   for k = 1:length(Ntones)
      [IQ,CF1] = genref(Ntones(k),PhaseType(l));	%S. Narahashi and T. Nojima phasing scheme
      CF(l,k) = CF1;
      if rem(k,25)==0
         disp([ num2str(k) ' of ' num2str(length(Ntones)) ', for ' Titles{l}]);
      end
      
   end
   semilogx(Ntones,CF(l,:));
   title(Titles{l});
   xlabel('Number of Tones');
   ylabel('Crest Factor (dB)');
   setplotstyle
   axis tight
   ylim([2 6])
   grid on
   savefig(Filenames{l})
   %pause
end

