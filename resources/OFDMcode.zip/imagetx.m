%IMAGETX This script produces a wav file of a COFDM frame suitable for
%	a playing as a COFDM signal generator.
%	It generates a signal which consists of a number of frames, each
%	separated by a frame guard time of one symbol period. The signal is
%	zero during this period.
%	The Data used in the frames sent is identical (i.e. all frames have the
%	same data).
%
%	Ths data used is from a bmp image.
%
%	Copyright (c) July 1997 Eric Lawrey

%================
%	Modified:
%	29/7/97	11:00am	cofdmwav.m
%	Modified simtxrx.m so that it would just generate the output of the
%	COFDM transmitter, and store the result in a wav file.
%
%	29/7/97	11:30am cofdmwav.m
%	Changed it so that a wav file of multiple frames could be generated.
%	31/7/97	8:44am	rdimage.m
%	Modified cofdmwav.m so that it now uses a bmp file as it data source
%
%	3/8/97	2:00pm imagetx.m
%	Added the option of compressing the contrast of the picture
%	to help prevent roll over of intensity when sending 8bits/word.
%	Also added data averaging, allowing duplicates of data to
%	be sent and recombined to reduce the phase error. This works,
%	except for it giving errors for black pixels.
%
%	12/8/97	10:30pm imagetx.m
%	Made many major changes to the software so that multiple data
%	types can be transmitted. Including random data, pictures, and
%	general binary files. Also a common setting script is now used
%	for both the transmitter and receiver. This is settings.m.
%
%	17/8/97 2:00 pm imagetx.m
%	Moved the calculation of the carriers to use into the settings
%	script.

%======================================================
%	External functions required to run this script:
%	settings.m
%	rddatatx.m
%	channel.m
%	wavwr.m		(from the Matlab web site)
%	transmit.m
%	rdimage.m
%	rddatatx.m		(Script to read in the data to transmit)

clear all;
flops(0);
tic;			%Measure the time it takes to run the simulation
settings		%Initialize all the setting required

rddatatx	%read in the data to transmit. This could be random data, an image
		%or a general binary file.


FrameSig = zeros(1,FrameGuard);		%Generate the blank period between frames
TimeSignal = [];
if SymbPerFrame ~= 0,
	f = 0.25;	%Frequency 0.5 = nyquist rate
	N = (ifftsize+guardtime)*8;
	Header = sin(0:f*2*pi:f*2*pi*(N-1));
	f = 0.117;
	Header = Header + sin(0:f*2*pi:f*2*pi*(N-1));
	TimeSignal = [];
	NumCarr = length(carriers);
	NoDataWords = length(Datatx)*DataAvg;
	numbsymb = ceil(NoDataWords/NumCarr);

	if numbsymb > SymbPerFrame,
		Dataleft = Datatx;
		while length(Dataleft) > 1,

			AmountData = min(SymbPerFrame*NumCarr/...
				DataAvg,length(Dataleft));
			FrameData = Dataleft(1:AmountData);
			Dataleft = Dataleft(AmountData+1:length(Dataleft));
			%===========================================================
			%Generate one frame of the COFDM signal from data to be sent
			%===========================================================
			BaseSignal = transmit(FrameData,ifftsize,carriers,...
 		 		wordsize,guardtype,guardtime,windowtype,DataAvg);
			TimeSignal = [TimeSignal FrameSig BaseSignal];
		end
		SigPow = std(BaseSignal);
		TimeSignal = [SigPow*Header TimeSignal FrameSig SigPow*Header];
	else
		BaseSignal = transmit(Datatx,ifftsize,carriers,...
	 		wordsize,guardtype,guardtime,windowtype,DataAvg);
		SigPow = std(BaseSignal);
		Header = SigPow*Header;
		TimeSignal = [Header FrameSig BaseSignal FrameSig Header];
	end
else
	BaseSignal = transmit(Datatx,ifftsize,carriers,...
	 		wordsize,guardtype,guardtime,windowtype,DataAvg);
	%Concatenate all the frames together
	for k = 1:NoFrames,
		TimeSignal = [TimeSignal BaseSignal FrameSig];
	end
end
Multi = zeros(Delay,1);
Multi(1) = 1;
Multi(Delay) = MultiMag;
TimeSignal = channel(TimeSignal, Comp, SNR, Multi);

%==============================
%Save the signal as a .WAV file
%==============================
wavwr(TimeSignal,Fs,res,1,txwavfile);

%======================
% Display some results
%======================
MaxSig = max(TimeSignal(N:length(TimeSignal)-N));
RMSSig = std(TimeSignal(N:length(TimeSignal)-N));
disp(['Max Signal Level: ' num2str(MaxSig)]);
disp(['RMS Signal Level: ' num2str(RMSSig)]);
disp(['Peak to RMS power ratio : ' num2str(20*log10(MaxSig/RMSSig)) 'dB']);
disp(['Total Time: ' num2str(toc) 'sec']);
disp(['Total FLOPS: ' num2str(flops)]);
disp(['Process Speed : ' num2str(flops/toc) ' flops/sec']);


